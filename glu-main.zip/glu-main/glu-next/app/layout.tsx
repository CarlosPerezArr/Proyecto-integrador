import '@/app/globals.css';
import { ReactQueryProvider } from './react-query-provider';
import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import local from 'next/font/local';

import Header from '@/app/components/Header';
import Sidebar from '@/app/components/Sidebar';

const fraktion = local({
  src: [
    {
      path: '../public/fonts/Fraktion.Sans/Regular.ttf',
      weight: 'normal',
      style: 'normal'
    },
    {
      path: '../public/fonts/Fraktion.Sans/Bold.ttf',
      weight: 'bold',
      style: 'normal'
    }
  ],
  variable: '--font-fraktion',
  display: 'swap'
});

const inter = Inter({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700'],
  variable: '--font-inter',
  display: 'swap'
});

export const metadata: Metadata = {
  title: 'Glue Studio',
  description: 'Automated testing for IoT devices'
};

export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      suppressHydrationWarning
      className={`${inter.variable} ${fraktion.variable} theme-dark`}
      data-theme="dark"
    >
      <body>
        <ReactQueryProvider>
          <Header />
          <Sidebar>{children}</Sidebar>
        </ReactQueryProvider>
        {process.env.NODE_ENV === 'development' && (
          <div className="fixed bottom-0 left-0 w-full h-4 bg-red-500"></div>
        )}
      </body>
    </html>
  );
}
