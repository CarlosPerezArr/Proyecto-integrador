'use client';

import React from 'react';
import { QueryClientProvider, QueryClient, QueryCache } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { useRouter } from 'next/navigation';

export function ReactQueryProvider({ children }: React.PropsWithChildren) {
  const router = useRouter();
  const [client] = React.useState(
    new QueryClient({
      defaultOptions: {
        queries: {
          retry: (failureCount: number, error: any) => {
            if (error.status === 401) {
              return false;
            }
            return failureCount < 2;
          }
        }
      },
      queryCache: new QueryCache({
        onError: (error: any) => {
          if (error.status === 401) {
            router.push('/api/auth/login');
          }
        }
      })
    })
  );

  return (
    <QueryClientProvider client={client}>
      {children}
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
  );
}
