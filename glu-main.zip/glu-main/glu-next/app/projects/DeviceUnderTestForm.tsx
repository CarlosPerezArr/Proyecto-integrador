import React, { useState, FormEvent } from 'react';
import { DeviceUnderTestCreate, DeviceUnderTest } from '@/app/client';
import { UnderTestService } from '@/app/client';

import { CheckIcon } from '@heroicons/react/24/solid';

interface DeviceUnderTestFormProps {
  device?: DeviceUnderTest;
  onSuccess: (device: DeviceUnderTest) => void;
}

const DeviceUnderTestForm: React.FC<DeviceUnderTestFormProps> = ({ device, onSuccess }) => {
  const [name, setName] = useState(device?.name || '');
  const [manufacturer, setManufacturer] = useState(device?.manufacturer || '');
  const [description, setDescription] = useState(device?.description || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);

    if (device) {
      const deviceUnderTest = { name, manufacturer, description } as DeviceUnderTest;
      deviceUnderTest.id = device.id;
      UnderTestService.updateDeviceUnderTestUnderTestDevicesDeviceIdPut({
        deviceId: deviceUnderTest.id as number,
        requestBody: deviceUnderTest
      })
        .then((res) => {
          setLoading(false);
          onSuccess(res as DeviceUnderTest);
        })
        .catch((_err) => {
          setError(true);
          setLoading(false);
          setTimeout(() => setError(false), 5000);
        });
    } else {
      UnderTestService.createDeviceUnderTestUnderTestDevicesPost({
        requestBody: { name, manufacturer, description } as DeviceUnderTestCreate
      })
        .then((res) => {
          setLoading(false);
          onSuccess(res as DeviceUnderTest);
        })
        .catch((_err) => {
          setError(true);
          setLoading(false);
          setTimeout(() => setError(false), 5000);
        });
    }
  };

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <div className="flex flex-col">
        <label htmlFor="name" className="mb-2">
          Name:
        </label>
        <input
          type="text"
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="input input-bordered w-1/2"
          placeholder=""
          required
        />
      </div>

      <div className="flex flex-col">
        <label htmlFor="manufacturer" className="mb-2">
          Manufacturer:
        </label>
        <input
          type="text"
          id="manufacturer"
          value={manufacturer}
          onChange={(e) => setManufacturer(e.target.value)}
          className="input input-bordered w-1/2"
          placeholder=""
          required
        />
      </div>

      <div className="flex flex-col">
        <label htmlFor="description" className="mb-2">
          Description:
        </label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="textarea textarea-bordered h-48 w-2/3"
          placeholder=""
          required
        ></textarea>
      </div>

      <div className="flex mt-6 w-2/3">
        <div className="w-1/2">
          {error && <p className="text-red-500">Error {device ? 'updating' : 'creating'} device</p>}
        </div>
        <div className="flex justify-end w-1/2">
          {loading ? (
            <button className="btn btn-sm btn-secondary" disabled>
              {device ? 'Updating...' : 'Creating...'}
            </button>
          ) : (
            <button type="submit" className="btn btn-sm btn-secondary">
              <CheckIcon className="size-4 mb-[2px]" />
              {device ? 'Update' : 'Create'}
            </button>
          )}
        </div>
      </div>
    </form>
  );
};

export default DeviceUnderTestForm;
