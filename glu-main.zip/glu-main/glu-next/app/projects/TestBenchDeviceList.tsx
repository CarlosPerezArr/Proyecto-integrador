import React from 'react';
import { TestBenchDeviceRead } from '@/app/client';

interface TestBenchDeviceProps {
  testBenchDevices: TestBenchDeviceRead[];
  loading: boolean;
}

const TestBenchDevice: React.FC<TestBenchDeviceProps> = ({ testBenchDevices, loading }) => {
  return (
    <div className={`mb-8 ${loading ? 'opacity-20 pointer-events-none z-1' : ''}`}>
      <ul className="ml-4">
        {testBenchDevices.map((device, index) => (
          <li key={index} className="mb-4">
            <strong className="font-semibold mb-2">
              {device.manufacturer}
              <br></br>
              {device.name}
            </strong>
            <p className="text-xs ml-2 italic text-gray-500">
              - {device.category}, {device.description || 'no description'}
            </p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default TestBenchDevice;
