import React, { useEffect, useState } from 'react';
import { useQueryClient, useQuery } from '@tanstack/react-query';

import Image from 'next/image';
import { TrashIcon } from '@heroicons/react/24/solid';

import DateComponent from '@/app/components/Date';
import Spinner from '../components/Spinner';
import ConfirmDialog from '@/app/components/ConfirmDialog';

import { UnderTestService, TestingService, TestPlanRead } from '@/app/client';

interface TestPlanListProps {
  functionSpecId: number;
  testPlan?: TestPlanRead;
  onLoaded?: (testPlans: TestPlanRead[]) => void;
  onClick?: (testPlan: TestPlanRead) => void;
  onDeleted?: (testPlan: TestPlanRead) => void;
  onError?: (error: any) => void;
}

const TestPlanList: React.FC<TestPlanListProps> = ({
  functionSpecId,
  testPlan,
  onLoaded,
  onClick,
  onDeleted,
  onError
}) => {
  const [confirmOpen, setConfirmOpen] = useState<boolean>(false);
  const [testPlanToDelete, setTestPlanToDelete] = useState<TestPlanRead | null>(null);
  const [deleteInProgress, setDeleteInProgress] = useState<boolean>(false);

  const queryClient = useQueryClient();
  const testPlansQueryKey = ['testPlans', functionSpecId];

  // get test plans
  const { data, isFetching, isLoading, isError, isPending, error } = useQuery({
    queryKey: testPlansQueryKey,
    queryFn: () =>
      UnderTestService.getTestPlansForFunctionSpecUnderTestFunctionSpecsFunctionSpecIdTestPlansGet({
        functionSpecId: functionSpecId
      }),
    staleTime: Infinity
  });

  useEffect(() => {
    if (data && onLoaded) {
      onLoaded(data);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  // function deleteTestPlan() {
  //   if (!testPlanToDelete) return;
  //   setDeleteInProgress(true);
  //   TestingService.deleteTestPlanTestingPlansTestPlanIdDelete({
  //     testPlanId: testPlanToDelete.id
  //   })
  //     .then(() => {
  //       queryClient.invalidateQueries({ queryKey: testPlansQueryKey });
  //       if (onDeleted) {
  //         onDeleted(testPlanToDelete);
  //       }
  //     })
  //     .catch((error) => {
  //       if (onError) {
  //         onError(error);
  //       }
  //     })
  //     .finally(() => {
  //       setDeleteInProgress(false);
  //     });
  // }

  useEffect(() => {
    if (error && onError) {
      onError(error);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [error]);

  if (isError) {
    return <h2>{error.message}</h2>;
  }

  return (
    <div
      className={`${
        isFetching || deleteInProgress ? 'opacity-50 pointer-events-none z-1' : ''
      } relative  w-full mt-4`}
    >
      {/* {isLoading && <Spinner className="mt-8">Loading previous test plan versions...</Spinner>} */}
      {((!isLoading && isFetching) || deleteInProgress) && (
        <div className="absolute h-full w-full flex justify-center items-center">
          <Spinner className="mt-4" />
        </div>
      )}
      {!isPending && data && data.length > 0 && (
        <>
          <h2>TEST PLANS</h2>
          <table className={`w-full table-auto`}>
            <thead>
              <tr className="border-b border-white font-semibold text-left">
                <th className="w-full pr-2">VERSION (created_at)</th>
                <th className="text-right pr-16">LAST UPDATED</th>
                <th className="whitespace-nowrap text-right"></th>
              </tr>
            </thead>
            <tbody>
              {data.toReversed().map((plan, index) => (
                <tr
                  key={index}
                  className={`${
                    testPlan?.id === plan.id ? 'text-primary' : ''
                  } group cursor-pointer hover:bg-black hover:text-primary border-b border-white`}
                  onClick={() => {
                    if (onClick) onClick(plan);
                  }}
                >
                  <td className="py-4 pr-2 flex flex-row">
                    <Image
                      className="mr-2"
                      src="/icon-folder.svg"
                      alt="projects"
                      width="20"
                      height="20"
                    />
                    <DateComponent dateString={plan.created_at as string} />
                  </td>
                  <td className="text-right whitespace-nowrap pr-16">
                    {plan.updated_at ? (
                      <DateComponent dateString={plan.updated_at as string} />
                    ) : (
                      <DateComponent dateString={plan.created_at as string} />
                    )}
                  </td>
                  {/* <td className="block w-6 text-right text-xs whitespace-nowrap">
                    <a
                      className="hidden group-hover:flex hover:text-error align-center w-5 h-5 text-base-content/75"
                      aria-label="delete"
                      onClick={(e) => {
                        setConfirmOpen(true);
                        setTestPlanToDelete(plan);
                        e.stopPropagation();
                      }}
                    >
                      <TrashIcon />
                    </a>
                  </td> */}
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
      {!isLoading && !isPending && data && data.length === 0 && <p>No previous versions.</p>}
      {/* <ConfirmDialog
        title="Delete Test Plan?"
        open={confirmOpen}
        onClose={() => {
          setConfirmOpen(false);
          setTestPlanToDelete(null);
        }}
        onConfirm={deleteTestPlan}
      >
        Are you sure you want to delete this test plan?
      </ConfirmDialog> */}
    </div>
  );
};

export default TestPlanList;
