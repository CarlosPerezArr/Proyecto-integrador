import React, { useEffect, useState } from 'react';
import { useQueryClient, useQuery } from '@tanstack/react-query';

import Image from 'next/image';
import { TrashIcon } from '@heroicons/react/24/solid';

import DateComponent from '@/app/components/Date';
import Spinner from '../components/Spinner';
import ConfirmDialog from '@/app/components/ConfirmDialog';

import { TestingService, TestBenchReadWithDeviceInfo, LabBenchService } from '@/app/client';
import LoadingSpinner from '../components/LoadingSpinner';

interface TestBenchListProps {
  testPlanId: number;
  functionSpecId: number;
  testBench?: TestBenchReadWithDeviceInfo;
  onLoaded?: (testBenches: TestBenchReadWithDeviceInfo[]) => void;
  onClick?: (testBench: TestBenchReadWithDeviceInfo) => void;
  onDeleted?: (testBench: TestBenchReadWithDeviceInfo) => void;
  onError?: (error: any) => void;
}

const TestBenchList: React.FC<TestBenchListProps> = ({
  testPlanId,
  functionSpecId,
  testBench,
  onLoaded,
  onClick,
  onDeleted,
  onError
}) => {
  const [confirmOpen, setConfirmOpen] = useState<boolean>(false);
  const [testBenchToDelete, setTestBenchToDelete] = useState<TestBenchReadWithDeviceInfo | null>(
    null
  );
  const [deleteInProgress, setDeleteInProgress] = useState<boolean>(false);

  const queryClient = useQueryClient();
  const testBenchesQueryKey = ['testBenches', functionSpecId];

  // get test benches
  const { data, isFetching, isLoading, isError, isPending, error } = useQuery({
    queryKey: testBenchesQueryKey,
    queryFn: () =>
      TestingService.listTestBenchesForTestPlanTestingTestPlansTestPlanIdTestBenchesGet({
        testPlanId: testPlanId
      }),
    staleTime: Infinity
  });

  useEffect(() => {
    if (data && onLoaded) {
      onLoaded(data);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  function deleteTestBench() {
    if (!testBenchToDelete) return;
    setDeleteInProgress(true);
    LabBenchService.deleteTestBenchLabBenchTestBenchesBenchIdDelete({
      benchId: testBenchToDelete.id
    })
      .then(() => {
        queryClient.invalidateQueries({ queryKey: testBenchesQueryKey });
        if (onDeleted) {
          onDeleted(testBenchToDelete);
        }
      })
      .catch((error) => {
        if (onError) {
          onError(error);
        }
      })
      .finally(() => {
        setDeleteInProgress(false);
      });
  }

  useEffect(() => {
    if (error && onError) {
      onError(error);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [error]);

  if (isError) {
    return <h2>{error.message}</h2>;
  }

  return (
    <div
      className={`${
        isFetching || deleteInProgress ? 'opacity-50 pointer-events-none z-1' : ''
      } relative  w-full mt-4`}
    >
      {/* {isLoading && <Spinner className="mt-8">Loading previous test plan versions...</Spinner>} */}
      {((!isLoading && isFetching) || deleteInProgress) && <LoadingSpinner />}
      {!isPending && data && data.length > 0 && (
        <>
          <h2>TEST BENCHES</h2>
          <table className={`w-full table-auto`}>
            <thead>
              <tr className="border-b border-white font-semibold text-left">
                <th className="w-full pr-2">VERSION (created_at)</th>
                <th className="text-right pr-16">LAST UPDATED</th>
                <th className="whitespace-nowrap text-right"></th>
              </tr>
            </thead>
            <tbody>
              {data.toReversed().map((bench, index) => (
                <tr
                  key={index}
                  className={`${
                    testBench?.id === bench.id ? 'text-primary' : ''
                  } group cursor-pointer hover:bg-black hover:text-primary border-b border-white`}
                  onClick={() => {
                    if (onClick) onClick(bench);
                  }}
                >
                  <td className="py-4 pr-2 flex flex-row">
                    <Image
                      className="mr-2"
                      src="/icon-folder.svg"
                      alt="projects"
                      width="20"
                      height="20"
                    />
                    <DateComponent dateString={bench.created_at as string} />
                  </td>
                  <td className="text-right whitespace-nowrap pr-16">
                    {bench.updated_at ? (
                      <DateComponent dateString={bench.updated_at as string} />
                    ) : (
                      <DateComponent dateString={bench.created_at as string} />
                    )}
                  </td>
                  <td className="block w-6 text-right text-xs whitespace-nowrap">
                    <a
                      className="hidden group-hover:flex hover:text-error align-center w-5 h-5 text-base-content/75"
                      aria-label="delete"
                      onClick={(e) => {
                        setConfirmOpen(true);
                        setTestBenchToDelete(bench);
                        e.stopPropagation();
                      }}
                    >
                      <TrashIcon />
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}
      {!isLoading && !isPending && data && data.length === 0 && (
        <p>No previous Test Bench versions.</p>
      )}
      <ConfirmDialog
        title="Delete Test Bench?"
        open={confirmOpen}
        onClose={() => {
          setConfirmOpen(false);
          setTestBenchToDelete(null);
        }}
        onConfirm={deleteTestBench}
      >
        Are you sure you want to delete this test bench?
      </ConfirmDialog>
    </div>
  );
};

export default TestBenchList;
