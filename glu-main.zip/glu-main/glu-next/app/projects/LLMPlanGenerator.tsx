'use client';

import React, { useState, useEffect, forwardRef, useRef, useMemo, useCallback } from 'react';
import { TestPlanRead } from '@/app/client';
import { CheckIcon, ArrowPathIcon, ArrowUturnLeftIcon } from '@heroicons/react/24/solid';
import { MarkdownEditorRef } from './LLMMarkdown';
import { PlanGeneratorWebsocket, PlanReviserWebsocket } from '@/app/lib/llm-websocket';

interface LLMPlanGeneratorProps {
  webSocket: PlanReviserWebsocket | PlanGeneratorWebsocket | null;
  testPlan?: TestPlanRead | null;
  inProgress?: boolean;
  onGenerate?: () => void;
  onGenerated?: (fullText: string) => void;
  onPersisted?: (testPlan: TestPlanRead) => void;
  onRevise?: (response: string) => void;
  onError?: () => void;
  onCancel?: () => void;
  markdown: React.ReactNode;
}

const LLMPlanGenerator = forwardRef<MarkdownEditorRef, LLMPlanGeneratorProps>(
  (
    {
      webSocket,
      testPlan,
      inProgress,
      onGenerate,
      onGenerated,
      onPersisted,
      onRevise,
      onError,
      onCancel,
      markdown
    },
    ref
  ) => {
    const markdownEditorRef = useRef<MarkdownEditorRef | null>(null);
    const [markdownContent, setMarkdownContent] = useState<string>('');

    React.useImperativeHandle(ref, () => ({
      exportAnnotations: () => {
        return markdownEditorRef.current?.exportAnnotations() || '';
      }
    }));

    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<boolean>(false);
    const [errorCode, setErrorCode] = useState<number | null>(null);
    const [webSocketState, setWebSocketState] = useState<string>('CLOSED');
    const [connectionError, setConnectionError] = useState<boolean>(false);
    const [testPlanGenerated, setTestPlanGenerated] = useState<boolean>(false);
    const [markdownTitle] = useState<string>('Generate Testing Steps');
    const [humanText, setHumanText] = useState<string>('');
    const [conversationMessage, setConversationMessage] = useState<any | null>(null);
    const [conversation, setConversation] = useState<string[]>([]);

    const handleMessagePayload = useCallback(
      (payload: any) => {
        console.log('Handling message payload');
        if (payload.event_type) {
          switch (payload.event_type) {
            case 'steps_generated':
              console.log('Message payload: Event - Test Plan steps generated');
              setConversationMessage({
                type: 'success',
                source: 'llm',
                content: `Test Plan steps ${testPlan ? 'revised' : 'generated'}.`
              });
              setTestPlanGenerated(true);
              setLoading(false);
              break;
            case 'steps_persisted':
              console.log('Message payload: Event - Test Plan steps persisted');
              setConversation([]);
              onPersisted && onPersisted(payload.test_plan);
              break;
            default:
              break;
          }
          return;
        }
        if (payload.full_text) {
          let fullText;
          if (Array.isArray(payload.full_text)) {
            fullText = payload.full_text.join('\n');
          } else {
            fullText = payload.full_text;
          }
          setMarkdownContent(fullText);
          onGenerated && onGenerated(fullText);
        }
      },
      [testPlan, onPersisted, onGenerated]
    );

    const handleConnectionOpen = useCallback(() => {
      console.log('Connection opened');
      setWebSocketState('OPEN');
      setConversationMessage({
        type: 'notice',
        source: 'llm',
        content: `Connected. ${testPlan ? 'Revising' : 'Generating'} test plan...`
      });
    }, [testPlan]);

    const handleConnectionClose = useCallback(() => {
      console.log('Connection closed');
      setLoading(false);
      setWebSocketState('CLOSED');
      setConversationMessage({
        type: 'notice',
        source: 'llm',
        content: `Server connection closed.`
      });
    }, []);

    const handleConnectionError = useCallback(
      (event: Event) => {
        setError(true);
        if (webSocketState === 'CLOSED') {
          setConnectionError(true);
        }
        setTimeout(() => {
          setError(false);
          if (onError) onError();
        }, 5000);
      },
      [webSocketState, onError]
    );

    const handleCancel = useCallback(() => {
      if (webSocket) {
        webSocket.disconnect();
      }
      setConnectionError(false);
      setError(false);
      setTestPlanGenerated(false);
      setHumanText('');
      setConversationMessage(null);
      setConversation([]);
      setMarkdownContent('');
      if (onCancel) onCancel();
    }, [webSocket, onCancel]);

    const generateTestPlan = useCallback(() => {
      setLoading(true);
      setError(false);
      setTestPlanGenerated(false);
      setHumanText('');
      setConversationMessage(null);
      setConversation([]);
      setMarkdownContent('');

      if (webSocket) {
        if (webSocket.isConnected()) {
          webSocket.disconnect();
        }
        webSocket.connect();
      }
      if (onGenerate) onGenerate();
    }, [webSocket, onGenerate]);

    const handleTestPlanSaved = useCallback(() => {
      if (webSocket) {
        setConversationMessage({
          type: 'success',
          source: 'user',
          content: 'Test Plan steps ACCEPTED.'
        });
        webSocket.send({
          event_type: 'steps_accepted'
        });
      }
    }, [webSocket]);

    const handleTestPlanRevise = useCallback(() => {
      setLoading(true);
      setConversationMessage({ type: 'warn', source: 'user', content: `REVISE: ${humanText}` });
      setTestPlanGenerated(false);
      setHumanText('');
      console.log('Sending revise message');
      const annotations = markdownEditorRef.current?.exportAnnotations() || '';

      if (webSocket) {
        webSocket.send({
          event_type: 'steps_retry',
          user_feedback: humanText,
          user_annotations: annotations
        });
      }
      if (onRevise) onRevise(humanText);
    }, [webSocket, humanText, onRevise]);

    // Memoize the markdown editor to prevent unnecessary rerenders
    const memoizedMarkdown = useMemo(() => {
      if (!webSocket && !testPlan) return markdown;

      if (React.isValidElement(markdown)) {
        return React.cloneElement(markdown as React.ReactElement, {
          ...markdown.props,
          ref: markdownEditorRef,
          content: markdownContent || markdown.props.content
        });
      }
      return markdown;
    }, [webSocket, testPlan, markdown, markdownContent]);

    useEffect(() => {
      if (conversationMessage) {
        console.log('Adding message to conversation:', conversationMessage);
        const messages = conversation;
        messages.push(conversationMessage);
        setConversation(messages);
        setConversationMessage(null);
      }
    }, [conversationMessage, conversation]);

    useEffect(() => {
      if (inProgress) return;
      if (!webSocket) return;

      webSocket.payloadFn = handleMessagePayload;
      webSocket.openFn = handleConnectionOpen;
      webSocket.closeFn = handleConnectionClose;
      webSocket.errorFn = handleConnectionError;

      if (testPlan) {
        console.log('Socket updated: Test Plan loaded');
      } else {
        console.log('Socket updated: No Test Plan');
        generateTestPlan();
      }
    }, [
      testPlan,
      webSocket,
      inProgress,
      handleMessagePayload,
      handleConnectionOpen,
      handleConnectionClose,
      handleConnectionError,
      generateTestPlan
    ]);

    return (
      <div className="py-8">
        <div className="absolute top-8 right-8 z-50">
          {conversation.length > 0 && (
            <div
              className={`rounded text-gray-300 mb-4 text-xs shadow-lg bg-black border-[1px] border-gray-500 p-4 pb-2 w-100 max-w-sm ${
                loading ? '' : ''
              }`}
            >
              <p className="font-semibold mb-2">DEBUG LOG:</p>
              {conversation.map((message: any, index: number) => (
                <div
                  key={index}
                  className={`${
                    message.source === 'llm' ? 'text-primary' : 'text-warning'
                  } mb-2 font-normal`}
                >
                  <span>
                    <span className="">
                      {message.source === 'llm' ? 'GLUE' : message.source.toUpperCase()}:
                    </span>{' '}
                    {message.content}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="mb-4 flex justify-between">
          <h3 className="font-mono">{markdownTitle}</h3>
          {!testPlan && loading && (
            <div className="flex justify-end">
              <button className="btn btn-xs btn-outline btn-warning" onClick={handleCancel}>
                <ArrowUturnLeftIcon className="size-3 mb-[2px]" />
                {'Cancel'}
              </button>
            </div>
          )}
        </div>

        {memoizedMarkdown}

        {(connectionError || error) && (
          <div className="text-red-500">
            {connectionError ? (
              <p>
                Error connecting to server.{' '}
                <button className="ml-4 mb-4 btn btn-sm btn-warning" onClick={generateTestPlan}>
                  Retry
                </button>
              </p>
            ) : (
              <p>Server error occurred. {errorCode} </p>
            )}
          </div>
        )}

        {(inProgress || loading || testPlanGenerated || testPlan) && (
          <div className={`mb-4 ${loading ? 'opacity-50 pointer-events-none' : ''}`}>
            <div className="mb-4 flex-row flex">
              <button
                onClick={handleTestPlanRevise}
                className={`btn btn-warning btn-outline btn-sm mr-2 ${
                  !humanText ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                <ArrowPathIcon className="size-4 mb-[2px]" />
                Revise Test Steps
              </button>
              <input
                className="px-2 text-sm text-neutral-500 border rounded w-full"
                placeholder={`${loading ? '' : 'Enter a response, or press enter to proceed...'}`}
                value={humanText}
                onChange={(e) => setHumanText(e.target.value)}
                onKeyUp={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    if (humanText || (!testPlan && humanText)) handleTestPlanRevise();
                  }
                }}
              />
            </div>
            {webSocket && (
              <div className="mb-4">
                <button
                  onClick={handleTestPlanSaved}
                  className={`btn btn-success btn-sm ${
                    !testPlanGenerated ? 'opacity-50 pointer-events-none' : ''
                  }`}
                >
                  <CheckIcon className="size-4 mb-[2px]" />
                  {testPlan ? 'Save Test Steps Version' : 'Save Test Steps'}
                </button>
              </div>
            )}
          </div>
        )}

        {!connectionError && webSocket && webSocket.isDisconnected() && !testPlan && (
          <div className="flex flex-row mb-4 items-center">
            <em>Server connection closed.</em>
            <button className="ml-4 btn btn-sm btn-warning" onClick={generateTestPlan}>
              Retry
            </button>
          </div>
        )}
      </div>
    );
  }
);

LLMPlanGenerator.displayName = 'LLMPlanGenerator';

export default LLMPlanGenerator;
