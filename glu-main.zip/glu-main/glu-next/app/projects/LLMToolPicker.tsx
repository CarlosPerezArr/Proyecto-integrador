'use client';

import React, { useState, useEffect } from 'react';
import { CheckIcon, ArrowPathIcon, ArrowUturnLeftIcon } from '@heroicons/react/24/solid';
import DateComponent from '@/app/components/Date';
import Markdown, { Components } from 'react-markdown';
import ReactMarkdown from 'react-markdown';
import SyntaxHighlighter from 'react-syntax-highlighter';
import { dracula } from 'react-syntax-highlighter/dist/esm/styles/hljs';
import {
  TestBenchDevice,
  TestBenchDeviceRead,
  TestBenchRead,
  TestBenchReadWithDeviceInfo
} from '../client';
import { ToolPickerWebsocket } from '../lib/llm-websocket';
import LoadingSpinner from '../components/LoadingSpinner';

// Props interface for the main LLMToolPicker component
interface LLMToolPickerProps {
  webSocket?: ToolPickerWebsocket | null; // WebSocket connection for real-time communication
  testPlanId: number; // ID of the current test plan
  testBench?: TestBenchReadWithDeviceInfo | null; // Current test bench data if it exists
  inProgress?: boolean; // Whether a suggestion is in progress
  onSuggest?: () => void; // Callback when suggestion starts
  onSuggested?: (testBenchDevices: TestBenchDevice[] | TestBenchDeviceRead[]) => void; // Callback when devices are suggested
  onPersisted?: (testBench: TestBenchRead | TestBenchReadWithDeviceInfo) => void; // Callback when test bench is saved
  onRevise?: () => void; // Callback when revision is requested
  onError?: () => void; // Callback when error occurs
  onCancel?: () => void; // Callback when process is cancelled
}

// Interface for the complete tool suggestion response from the server
interface ToolSuggestionResponse {
  event_type: string; // Type of event (e.g., 'tools_suggested')
  description: string; // Analysis description/explanation
  present_tools: TestBenchDevice[]; // List of available tools
  missing_tools: TestBenchDevice[]; // List of recommended but unavailable tools
}

// Component to display a list of test bench devices
const TestBenchDeviceList: React.FC<{
  devices: TestBenchDeviceRead[] | TestBenchDevice[] | undefined;
  title: string;
  loading?: boolean;
}> = ({ devices, title, loading }) => (
  <div className="mb-6">
    <h3 className="text-lg font-semibold mb-3 text-gray-200">{title}</h3>
    <div className="space-y-4">
      {devices &&
        devices.map((device: TestBenchDevice | TestBenchDeviceRead, index) => (
          <div key={index} className="bg-gray-800 p-4 rounded-lg border border-gray-700">
            {/* Device header section with name and category */}
            <div className="flex justify-between items-start">
              <div className="flex-1">
                <h4 className="font-medium text-gray-200">
                  {device.name || 'Tool Recommendation'}
                </h4>
                {device.description && (
                  <p className="text-sm text-gray-400 mt-1">{device.description}</p>
                )}
                {device.manufacturer && (
                  <p className="text-sm text-gray-500 mt-1">Manufacturer: {device.manufacturer}</p>
                )}
              </div>
              {device.category && (
                <span className="text-blue-200 text-xs px-2 py-1 rounded">{device.category}</span>
              )}
            </div>
            {/* Device details section with reason and purpose */}
            {device && 'reason' in device && 'purpose' in device && (
              <div className="mt-3 space-y-2">
                <div className="p-3 rounded border border-gray-700">
                  <p className="text-sm text-gray-300">
                    <span className="font-medium">Reason:</span>{' '}
                    {(device as { reason: string }).reason}
                  </p>
                </div>
                <div className="p-3 rounded border border-gray-700">
                  <p className="text-sm text-gray-300">
                    <span className="font-medium">Purpose:</span>{' '}
                    {(device as { purpose: string }).purpose}
                  </p>
                </div>
              </div>
            )}
          </div>
        ))}
    </div>
  </div>
);

// Main component for tool suggestion and management
const LLMToolPicker: React.FC<LLMToolPickerProps> = ({
  webSocket,
  testPlanId,
  testBench,
  inProgress,
  onSuggest,
  onSuggested,
  onPersisted,
  onRevise,
  onError,
  onCancel
}) => {
  // State management for component
  const [loading, setLoading] = useState<boolean>(false);
  const [webSocketState, setWebSocketState] = useState<string>('CLOSED');
  const [error, setError] = useState<boolean>(false);
  const [connectionError, setConnectionError] = useState<boolean>(false);
  const [humanText, setHumanText] = useState<string>('');
  const [conversationMessage, setConversationMessage] = useState<any | null>(null);
  const [conversation, setConversation] = useState<string[]>([]);
  const [suggestionResponse, setSuggestionResponse] = useState<ToolSuggestionResponse | null>(null);
  const [benchSuggested, setBenchSuggested] = useState<boolean>(false);
  const [description, setDescription] = useState<string>('');

  // Function to initiate new test bench suggestion
  function suggestTestBench() {
    console.log('Suggesting new test bench...');
    // Reset all states to initial values
    setLoading(true);
    setError(false);
    setBenchSuggested(false);
    setConversationMessage(null);
    setConversation([]);
    setSuggestionResponse(null);

    // Handle WebSocket connection
    if (webSocket) {
      if (webSocket.isConnected()) {
        webSocket.disconnect();
      }
      webSocket.connect();
    }
    if (onSuggest) onSuggest();
  }

  // Handler for WebSocket messages
  function handleMessagePayload(payload: any) {
    console.log('Handling message payload:', payload);
    if (payload.event_type) {
      switch (payload.event_type) {
        case 'tools_suggested':
          // Handle new tool suggestions
          console.log('Message payload: Event - Test Bench suggested');
          setConversationMessage({
            type: 'success',
            source: 'llm',
            content: `Test bench suggested.`
          });
          setBenchSuggested(true);
          setLoading(false);
          setSuggestionResponse(payload);
          setDescription(payload.description);
          if (onSuggested && payload.present_tools) {
            onSuggested(payload.present_tools);
          }
          break;
        case 'test_bench_persisted':
          // Handle successful save of test bench
          console.log('Message payload: Event - Test Bench persisted');
          setConversation([]);
          onPersisted && onPersisted(payload.test_bench);
          break;
        default:
          break;
      }
    }
  }

  // Function to handle bench revision requests
  function handleBenchRevise() {
    setConversationMessage({
      type: 'warn',
      source: 'user',
      content: `REVISE: ${humanText}`
    });

    if (webSocket) {
      webSocket.send(
        JSON.stringify({
          event_type: 'tools_retry',
          user_feedback: humanText
        })
      );
      setBenchSuggested(false);
      setHumanText('');
      if (onRevise) onRevise();
    }
  }

  // Function to handle bench acceptance
  function handleBenchAccept() {
    if (webSocket) {
      webSocket.send(
        JSON.stringify({
          event_type: 'tools_accepted'
        })
      );
    }
  }

  // Function to handle cancellation
  function handleCancel() {
    if (webSocket) {
      webSocket.disconnect();
    }
    setConnectionError(false);
    setError(false);
    setBenchSuggested(false);
    setHumanText('');
    setConversationMessage(null);
    setConversation([]);
    if (onCancel) onCancel();
  }

  // WebSocket event handlers
  function handleConnectionOpen() {
    console.log('Connection opened');
    setWebSocketState('OPEN');
    setConversationMessage({
      type: 'notice',
      source: 'llm',
      content: `Connected. ${
        suggestionResponse ? 'Revising test bench suggestion' : 'Suggesting test bench'
      }...`
    });
  }

  function handleConnectionClose() {
    console.log('Connection closed');
    setLoading(false);
    setWebSocketState('CLOSED');
  }

  function handleConnectionError(event: Event) {
    setError(true);
    if (webSocketState === 'CLOSED') {
      setConnectionError(true);
    }
    setTimeout(() => {
      setError(false);
      if (onError) onError();
    }, 5000);
  }

  // Effect to handle conversation messages
  useEffect(() => {
    if (conversationMessage) {
      console.log('Adding message to conversation:', conversationMessage);
      const messages = conversation;
      messages.push(conversationMessage);
      setConversation(messages);
      setConversationMessage(null);
    }
  }, [conversationMessage, conversation]);

  // Effect to handle WebSocket setup and initial test bench suggestion
  useEffect(() => {
    if (inProgress) return;
    if (!webSocket) return;

    // Set up WebSocket event handlers
    webSocket.payloadFn = handleMessagePayload;
    webSocket.openFn = handleConnectionOpen;
    webSocket.closeFn = handleConnectionClose;
    webSocket.errorFn = handleConnectionError;

    // Initiate suggestion if no test bench exists
    if (!testBench) {
      console.log('No test bench, suggesting...');
      suggestTestBench();
    }
  }, [testBench, webSocket, inProgress]);

  const customComponents: Components = {
    code: ({ className, children, ...props }) => {
      const match = /language-(\w+)/.exec(className || '');
      return match ? (
        <SyntaxHighlighter
          style={dracula as any}
          language={match[1]}
          PreTag="div"
          {...(props as any)}
        >
          {String(children)}
        </SyntaxHighlighter>
      ) : (
        <code className={className} {...props}>
          {children}
        </code>
      );
    }
  };

  return (
    <div className="py-8">
      {/* Debug Log Section */}
      <div className="absolute top-8 right-8 z-50">
        {conversation.length > 0 && (
          <div className="rounded text-gray-300 mb-4 text-xs shadow-lg bg-black border-[1px] border-gray-700 p-4 pb-2 w-100 max-w-sm">
            <p className="font-semibold mb-2">DEBUG LOG:</p>
            {conversation.map((message: any, index: number) => (
              <div
                key={index}
                className={`${
                  message.source === 'llm' ? 'text-blue-400' : 'text-yellow-400'
                } mb-2 font-normal`}
              >
                <span>
                  <span>{message.source === 'llm' ? 'GLUE' : message.source.toUpperCase()}:</span>{' '}
                  {message.content}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Connection Status */}
      {!connectionError && webSocket && webSocket.isDisconnected() && !testBench && (
        <div className="flex flex-row mb-4 items-center text-gray-400">
          <em>Server connection closed.</em>
          <button
            className="ml-4 px-3 py-1 text-sm rounded border border-yellow-600 text-yellow-400 hover:bg-yellow-900/30 transition-colors"
            onClick={suggestTestBench}
          >
            Retry
          </button>
        </div>
      )}
      {/* Cancel Button */}
      {!testBench && loading && (
        <div className="flex flex-col space-y-4 w-full">
          <div className="flex justify-end w-full">
            <button
              className="px-3 py-1 text-sm rounded border border-yellow-600 text-yellow-400 hover:bg-yellow-900/30 transition-colors"
              onClick={handleCancel}
            >
              <ArrowUturnLeftIcon className="size-3 mb-[2px] inline mr-1" />
              Cancel
            </button>
          </div>
          <div className="w-full">
            <LoadingSpinner title="Creating test bench" />
          </div>
        </div>
      )}

      {/* Tool Suggestion Display */}
      {suggestionResponse && (
        <div className="mb-6">
          {/* Analysis Description */}
          <div className="bg-gray-800 p-4 rounded-lg border border-gray-700 mb-6">
            <h3 className="text-lg font-semibold mb-3 text-gray-200">Overview</h3>
            <ReactMarkdown
              key={description} // Add this
              className="markdown-content prose prose-invert max-w-none"
              skipHtml={true}
              components={customComponents}
            >
              {description}
            </ReactMarkdown>
          </div>

          {/* Present Tools List */}
          {suggestionResponse.present_tools.length > 0 && (
            <TestBenchDeviceList
              devices={suggestionResponse.present_tools}
              title="Present Tools"
              loading={loading}
            />
          )}

          {/* Missing Tools List */}
          {suggestionResponse.missing_tools.length > 0 && (
            <TestBenchDeviceList
              devices={suggestionResponse.missing_tools}
              title="Missing Tools"
              loading={loading}
            />
          )}
        </div>
      )}

      {/* Existing Test Bench Display */}
      {testBench && (
        <div>
          <p className="mb-2 text-gray-400">
            Test bench version:{' '}
            <DateComponent dateString={testBench.updated_at || (testBench.created_at as string)} />
          </p>
          <TestBenchDeviceList
            devices={testBench.test_bench_devices}
            title="Current Test Bench"
            loading={loading}
          />
        </div>
      )}

      {/* Error States */}
      {(connectionError || error) && (
        <div className="text-red-400">
          {connectionError ? (
            <p>
              Error connecting to server.{' '}
              <button
                className="ml-4 mb-4 px-3 py-1 text-sm rounded border border-yellow-600 text-yellow-400 hover:bg-yellow-900/30 transition-colors"
                onClick={suggestTestBench}
              >
                Retry
              </button>
            </p>
          ) : (
            <p>Server error occurred.</p>
          )}
        </div>
      )}

      {/* Input and Action Buttons */}
      {(benchSuggested || suggestionResponse) && (
        <div className={`mb-4 ${loading ? 'opacity-50 pointer-events-none' : ''}`}>
          {/* Revision Input Section */}
          <div className="mb-4 flex-row flex">
            <button
              onClick={handleBenchRevise}
              className={`px-3 py-1 text-sm rounded border border-yellow-600 text-yellow-400 hover:bg-yellow-900/30 transition-colors mr-2 ${
                !humanText ? 'opacity-50 pointer-events-none' : ''
              }`}
            >
              <ArrowPathIcon className="size-4 mb-[2px] inline mr-1" />
              Revise Bench
            </button>
            <input
              className="px-2 text-sm bg-gray-800 text-gray-300 border border-gray-700 rounded w-full focus:outline-none focus:border-gray-600 focus:ring-1 focus:ring-gray-600"
              value={humanText}
              placeholder={loading ? '' : 'Enter a response, or press enter to proceed...'}
              onChange={(e) => setHumanText(e.target.value)}
              onKeyUp={(e) => {
                if (e.key === 'Enter' && humanText) {
                  handleBenchRevise();
                }
              }}
            />
          </div>

          {/* Save Button */}
          {/*{webSocket && (
            <div className="mb-4">
              <button
                onClick={handleBenchAccept}
                className={`px-3 py-1 text-sm rounded border border-green-600 text-green-400 hover:bg-green-900/30 transition-colors ${
                  !benchSuggested ? 'opacity-50 pointer-events-none' : ''
                }`}
              >
                <CheckIcon className="size-4 mb-[2px] inline mr-1" />
                Save Bench
              </button>
            </div>
          )}*/}
        </div>
      )}
    </div>
  );
};

export default LLMToolPicker;
