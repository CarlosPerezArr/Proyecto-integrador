'use client';

import React, { useState } from 'react';
import PageCard from 'app/components/PageCard';
import DeviceUnderTestList from './DeviceUnderTestList';
import TabBar, { TabProps } from 'app/components/TabBar';
import { PlusIcon } from '@heroicons/react/24/solid';

const tabsOpts: TabProps[] = [
  {
    title: 'Active',
    name: 'active'
  }
  // {
  //   title: 'Archived',
  //   name: 'archived'
  // }
];

const Page: React.FC = () => {
  const [tabs, setTabs] = useState<TabProps[]>(tabsOpts);
  const [activeTab, setActiveTab] = useState<TabProps>(tabs[0]);

  function setTabCount(name: string, total: number) {
    let updated = false;
    const newTabs = tabs.map((tab) => {
      if (tab.name === name && !tab.count) {
        tab.count = total;
        updated = true;
      }
      return tab;
    });

    if (updated) {
      console.log('setTabCount', name, total);
      setTabs(newTabs);
    }
  }

  return (
    <div>
      {activeTab && (
        <PageCard
          title="Projects"
          headerNodes={[
            <a className="btn-sm btn btn-primary" href="/projects/new" key="0">
              <PlusIcon className="mb-0.5 size-4" />
              New Project
            </a>
          ]}
        >
          {<TabBar tabs={tabs} selectedTab={activeTab} onClick={setActiveTab} />}
          {activeTab.name === 'active' && (
            <DeviceUnderTestList type="active" onLoad={setTabCount} />
          )}
          {activeTab.name === 'archived' && (
            <DeviceUnderTestList type="archived" onLoad={setTabCount} />
          )}
        </PageCard>
      )}
    </div>
  );
};

export default Page;
