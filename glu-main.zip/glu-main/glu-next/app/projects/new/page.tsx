'use client';

import { useQuery, useQueryClient } from '@tanstack/react-query';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';

import PageCard from 'app/components/PageCard';
import DeviceUnderTestForm from '../DeviceUnderTestForm';
import DeviceSpecUploader from '../DeviceSpecUploader';
import Features from '../Features';
import ProgressLine from 'app/components/ProgressLine';

import { UnderTestService, DeviceUnderTest, FunctionSpecRead } from '@/app/client';
import LoadingSpinner from '@/app/components/LoadingSpinner';

export interface StepProps {
  step_number: number;
  action: string;
  title: string;
  subTitle: string;
}

const stepsOpts: StepProps[] = [
  {
    step_number: 1,
    action: 'create',
    title: 'Project Details',
    subTitle:
      'Project details are filled in based on the specification document. Edit the information as needed to match your requirements.'
  },
  {
    step_number: 2,
    action: 'upload-specs',
    title: 'Upload Specifications and Additional Documents',
    subTitle: "Let's get your documents uploaded."
  },
  {
    step_number: 2,
    action: 'load-specs',
    title: 'Processing Documents',
    subTitle: "Let's get your documents uploaded."
  },
  {
    step_number: 3,
    action: 'review-specs',
    title: 'Review Feature Specifications',
    subTitle: 'Review the features and functions found in the specifications.'
  },
  {
    step_number: 4,
    action: 'testing-bench',
    title: 'Testing Bench',
    subTitle: 'Select your testing bench for this project. These can always be edited later.'
  }
];

const Page: React.FC = () => {
  const router = useRouter();
  const queryClient = useQueryClient();
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [error, _setError] = useState<boolean>(false);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [steps, _setSteps] = useState<StepProps[]>(stepsOpts);
  const [activeStep, setActiveStep] = useState<StepProps>(steps[0]);

  const [device, setDevice] = useState<DeviceUnderTest | null>(null);
  const [deviceSpecId, setDeviceSpecId] = useState<number | null>(null);

  const [specsConfirmed, setSpecsConfirmed] = useState<boolean>(false);

  const { data: functionSpecs, isLoading: functionSpecsAreLoading } = useQuery({
    queryKey: ['functionSpecs', deviceSpecId],
    queryFn: () =>
      UnderTestService.listFunctionSpecsForDeviceSpecUnderTestDeviceSpecsDeviceSpecIdFunctionSpecsGet(
        { deviceSpecId: deviceSpecId as number, limit: 499 }
      ),
    enabled: !!deviceSpecId
  });

  const { data: testBenchTools } = useQuery({
    queryKey: ['testBenchTools', deviceSpecId],
    queryFn: () => ['tool1', 'tool2', 'tool3'],
    enabled: !!specsConfirmed
  });

  const handleCreateSuccess = (device: DeviceUnderTest) => {
    console.log('Device created:', device);
    setDevice(device);
    setActiveStep(steps.find((s) => s.action === 'upload-specs') || steps[0]);
  };

  const handleUploadSubmit = () => {
    setActiveStep(steps.find((s) => s.action === 'load-specs') || steps[0]);
  };

  const handleUploadError = () => {
    setActiveStep(steps.find((s) => s.action === 'upload-specs') || steps[0]);
  };

  const handleUploadComplete = (deviceSpecId: number, functionSpecs?: FunctionSpecRead[]) => {
    console.log('Upload complete');
    setDeviceSpecId(deviceSpecId);
    setActiveStep(steps.find((s) => s.action === 'review-specs') || steps[0]);
    if (functionSpecs) {
      console.log('Setting function specs:', functionSpecs);
      queryClient.setQueryData(['functionSpecs', deviceSpecId], functionSpecs);
    }
  };

  const handleFeaturesConfirm = () => {
    setSpecsConfirmed(true);
    if (device) {
      router.push(`/projects/${device.id}`);
    } else {
      router.push(`/projects`);
    }
  };

  const handleFeaturesRetry = async () => {
    setSpecsConfirmed(false);
    console.log('Features retry');
    setActiveStep(steps.find((s) => s.action === 'load-specs') || steps[0]);
    // queryClient.invalidateQueries({ queryKey: ['functionSpecs', deviceSpecId] });
  };

  return (
    <div>
      <PageCard
        title={
          <div className="">
            <ProgressLine
              key={0}
              currentStep={activeStep.step_number}
              totalSteps={Math.max(...steps.map((s) => s.step_number))}
            ></ProgressLine>
            <div className="text-lg font-mono font-normal">{activeStep.title}</div>
          </div>
        }
        subTitle={activeStep.subTitle}
        headerNodes={[]}
      >
        <div className="mt-8">
          {activeStep.action === 'create' &&
            (error ? (
              <div>Error creating new project, please try again.</div>
            ) : (
              <DeviceUnderTestForm onSuccess={handleCreateSuccess} />
            ))}
          {['upload-specs', 'load-specs'].includes(activeStep.action) &&
            (error ? (
              <div>Error uploading device spec document, please try again.</div>
            ) : (
              <DeviceSpecUploader
                device={device!}
                deviceSpecId={deviceSpecId!}
                onSubmit={handleUploadSubmit}
                onError={handleUploadError}
                onComplete={handleUploadComplete}
              />
            ))}
          {activeStep.action === 'review-specs' &&
            (functionSpecsAreLoading ? (
              <LoadingSpinner title="Loading features..." />
            ) : (
              <div>
                <Features
                  functionSpecs={functionSpecs || []}
                  onConfirm={handleFeaturesConfirm}
                  onRetry={handleFeaturesRetry}
                />
              </div>
            ))}
          {activeStep.action === 'testing-bench' &&
            (!testBenchTools ? (
              <LoadingSpinner title="Loading recommended testing tools..." />
            ) : (
              <div>{testBenchTools}</div>
            ))}
        </div>
      </PageCard>
    </div>
  );
};

export default Page;
