import { useEffect } from 'react';
import { FunctionSpecRead } from '@/app/client';
import { CheckIcon, ArrowPathIcon } from '@heroicons/react/24/solid';

interface FeaturesProps {
  onConfirm: () => void;
  onRetry: () => void;
  functionSpecs: FunctionSpecRead[];
}

const Features: React.FC<FeaturesProps> = ({ onConfirm, onRetry, functionSpecs }) => {
  // In a real-world scenario, the features list would be fetched from an API or passed down as props.
  // const features = ['DC Voltage Function', 'Square Wave Function', 'Overload Pulse'];

  useEffect(() => {
    console.log('functionSpecs:', functionSpecs);
  }, [functionSpecs]);
  // Placeholder function to render the list of features.
  const renderFeatureList = () => {
    if (functionSpecs.length === 0) {
      return <div>No features available</div>;
    } else {
      return functionSpecs.map((functionSpec, index) => (
        <div
          key={index}
          className="flex text-xs bg-black items-center justify-between border-b border-1 border-gray-500 py-2"
        >
          {functionSpec.name}
        </div>
      ));
    }
  };

  return (
    <div>
      {/* <h2 className="mt- text-xl">Device Features Available to Test</h2> */}
      <div className="mb-6 border-t border-1 border-gray-500">{renderFeatureList()}</div>
      <div className="flex justibetween">
        <button onClick={onConfirm} className="btn btn-sm btn-success mr-8">
          <CheckIcon className="size-4 mb-[2px]" />
          Confirm
        </button>
        <button onClick={onRetry} className="btn btn-sm btn-outline btn-warning">
          <ArrowPathIcon className="size-4 mb-[2px]" />
          Retry
        </button>
      </div>
    </div>
  );
};

export default Features;
