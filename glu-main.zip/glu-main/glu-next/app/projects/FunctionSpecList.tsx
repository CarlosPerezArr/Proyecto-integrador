import React, { useState } from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';

import Image from 'next/image';

import PageButtons from '@/app/components/PageButtons';
import DateComponent from '@/app/components/Date';
import Spinner from '../components/Spinner';

import {
  UnderTestService,
  DeviceUnderTestRead,
  DeviceSpecRead,
  CursorPage__T_Customized_FunctionSpecRead_
} from '@/app/client';
import LoadingSpinner from '../components/LoadingSpinner';

interface FunctionSpecListProps {
  deviceUnderTest: DeviceUnderTestRead;
  deviceSpec: DeviceSpecRead;
}

const pageSize = 20;

const FunctionSpecList: React.FC<FunctionSpecListProps> = ({ deviceUnderTest, deviceSpec }) => {
  const router = useRouter();
  const [cursor, setCursor] = useState<string>('default');
  const [pageNumber, setPageNumber] = useState<number>(1);

  const { isPending, isError, error, data, isFetching, isPlaceholderData } = useQuery({
    queryKey: [
      'deviceUnderTest',
      deviceUnderTest.id,
      'deviceSpec',
      deviceSpec.id,
      'functionSpecs',
      pageNumber
    ],
    queryFn: () =>
      UnderTestService.listFunctionSpecsForDeviceUnderTestDevicesDeviceIdDeviceSpecsDeviceSpecIdFunctionSpecsGet(
        {
          size: pageSize,
          deviceId: deviceUnderTest.id,
          deviceSpecId: deviceSpec.id,
          cursor: cursor === 'default' ? undefined : cursor
        }
      ),
    placeholderData: keepPreviousData,
    staleTime: Infinity
  });

  // if (isPending) {
  //   return <h2>Loading device features to test...</h2>;
  // }

  if (isError) {
    return <h2>{error.message}</h2>;
  }

  function onPage(pageCursor: string, pageNumber: number) {
    setPageNumber(pageNumber);
    setCursor(pageCursor);
  }

  return (
    <div className="">
      {isPending && <LoadingSpinner title="Loading available tests" />}
      {!isPending && data && data.items!.length > 0 && (
        <div>
          <table
            className={`table-auto w-fll font-mono text-sm ${
              isFetching || isPlaceholderData ? 'opacity-50 pointer-events-none	' : ''
            }`}
          >
            <thead>
              <tr className="border-b border-white font-semibold text-left">
                <th className="w-full pr-2">FUNCTION/FEATURE</th>
                <th className="text-center whitespace-nowrap px-8">TEST STEPS</th>
                <th className="text-center pr-16">AUTOMATION</th>
                <th className="whitespace-nowrap text-right">LAST EDITED</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((functionSpec, index) => {
                const hasTestPlan = functionSpec.test_plan?.id;
                const hasTestScript = functionSpec.test_script?.id;

                return (
                  <tr
                    key={index}
                    className="cursor-pointer hover:bg-black hover:text-primary border-b border-white"
                    onClick={() =>
                      router.push(
                        `/projects/${deviceUnderTest.id}/features/${functionSpec.id}/test`
                      )
                    }
                  >
                    <td className="py-4 pr-2 flex flex-row">
                      <Image
                        className="mr-2"
                        src="/icon-folder.svg"
                        alt="projects"
                        width="20"
                        height="20"
                      />
                      <span>{functionSpec.name}</span>
                    </td>
                    <td className="text-center whitespace-nowrap px-8">
                      <span
                        className={`inline-block px-1 rounded-sm text-xs h-6 leading-[26px] ${
                          hasTestPlan
                            ? 'text-base-100 bg-primary'
                            : 'text-neutral-content bg-neutral'
                        }`}
                      >
                        {hasTestPlan ? 'DONE' : 'TO DO'}
                      </span>
                    </td>
                    <td className="text-center whitespace-nowrap pr-16">
                      <span
                        className={`inline-block px-1 rounded-sm text-xs h-6 leading-[26px] ${
                          hasTestScript
                            ? 'text-base-100 bg-primary'
                            : 'text-neutral-content bg-neutral'
                        }`}
                      >
                        {hasTestScript ? 'DONE' : 'TO DO'}
                      </span>
                    </td>
                    <td className="text-right text-xs whitespace-nowrap">
                      <DateComponent
                        dateString={(functionSpec.updated_at || functionSpec.created_at) as string}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          <PageButtons
            data={data as CursorPage__T_Customized_FunctionSpecRead_}
            pageSize={pageSize}
            disabled={isFetching || isPlaceholderData}
            onClick={onPage}
          />
        </div>
      )}

      {data && data.items.length === 0 && <div>No tests found for the selected Spec Document.</div>}
    </div>
  );
};

export default FunctionSpecList;
