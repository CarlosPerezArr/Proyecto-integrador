'use client';

import React, { useEffect, useRef, forwardRef } from 'react';
import MarkdownInlineEditor from '../components/MarkdownInlineEditor';

interface LLMMarkdownProps {
  markdownHeader?: any;
  markdownFooter?: any;
  markdownText?: string;
  loading: boolean;
  error: boolean;
  shouldScroll: boolean;
}

export type MarkdownEditorRef = {
  exportAnnotations: () => string;
};

const LLMMarkdown = forwardRef<MarkdownEditorRef, LLMMarkdownProps>(
  ({ markdownHeader, markdownFooter, markdownText = '', loading, shouldScroll }, ref) => {
    // console.log('LLMMarkdown render with text:', markdownText); // Debug log
    const markdownRef = useRef<HTMLDivElement>(null);

    // Scroll handling
    useEffect(() => {
      if (markdownRef.current && shouldScroll) {
        markdownRef.current.scrollTop = markdownRef.current.scrollHeight;
      }
    }, [shouldScroll, markdownText]); // Add markdownText as dependency to scroll on content updates

    return (
      <div className="">
        {markdownText && (
          <div
            ref={markdownRef}
            className={`${loading ? 'opacity-50 pointer-events-none' : ''} w-full mb-8 bg-base-100`}
          >
            {markdownHeader}

            <div
              className={`${markdownFooter ? 'h-[60vh]' : 'h-[80vh]'} px-8 py-4 rounded-lg ${
                markdownFooter ? 'rounded-t-none rounded-b-none' : 'rounded-t-none'
              } overflow-y-scroll scrollbar border-[1px] ${
                markdownFooter ? 'border-y-0' : 'border-t-0'
              } border-gray-500`}
            >
              <MarkdownInlineEditor ref={ref} className="markdown-content" text={markdownText} />
            </div>

            {markdownFooter}
          </div>
        )}
      </div>
    );
  }
);

LLMMarkdown.displayName = 'LLMMarkdown';

export default LLMMarkdown;
