import React, { useState, useEffect } from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { UnderTestService, CursorPage__T_Customized_DeviceUnderTestRead_ } from '@/app/client';
import { useRouter } from 'next/navigation';

import PageButtons from '@/app/components/PageButtons';
import DateComponent from '@/app/components/Date';
import Spinner from '@/app/components/Spinner';

import Image from 'next/image';
import LoadingSpinner from '../components/LoadingSpinner';

interface DeviceUnderTestListProps {
  type: string;
  onLoad?: (type: string, total: number) => void;
}

const pageSize = 10;

const DeviceUnderTestList: React.FC<DeviceUnderTestListProps> = ({ type, onLoad }) => {
  const [cursor, setCursor] = useState<string>('default');
  const [pageNumber, setPageNumber] = useState<number>(1);

  const router = useRouter();

  const { isPending, isError, data, isFetching, isPlaceholderData } = useQuery({
    queryKey: ['devicesUnderTest', type, pageNumber],
    queryFn: () =>
      UnderTestService.listDevicesUnderTestUnderTestDevicesGet({
        size: pageSize,
        cursor: cursor === 'default' ? undefined : cursor
      }),
    placeholderData: keepPreviousData,
    staleTime: Infinity
  });

  function onPage(pageCursor: string, pageNumber: number) {
    setPageNumber(pageNumber);
    setCursor(pageCursor);
  }

  useEffect(() => {
    if (data) {
      if (onLoad) {
        onLoad(type, data.total!);
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [data]);

  return (
    <div className="w-full py-8">
      {isError && (
        <div className="mt-8 w-full flex justify-center">
          Error loading projects, please try again later.
        </div>
      )}
      {isPending && <LoadingSpinner title="Loading projects..." />}

      {data && data.items!.length === 0 && (
        <div className="mt-8 w-full flex justify-center">No projects found.</div>
      )}

      {data && data.items!.length > 0 && (
        <div>
          <table
            className={`table-auto w-fll font-mono text-sm ${
              isFetching || isPlaceholderData ? 'opacity-50 pointer-events-none	' : ''
            }`}
          >
            <thead>
              <tr className="border-b border-white font-semibold text-left">
                <th className="w-full pr-2">PROJECT</th>
                <th className="pr-16 text-center">STATUS</th>
                <th className="text-right">LAST EDITED</th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((device, index) => (
                <tr
                  key={index}
                  className="cursor-pointer hover:bg-black hover:text-primary border-b border-white"
                  onClick={() => router.push(`/projects/${device.id}`)}
                >
                  <td className="py-4 pr-2 flex flex-row">
                    <Image
                      className="mr-2"
                      src="/icon-folder.svg"
                      alt="projects"
                      width="20"
                      height="20"
                    />
                    {device.manufacturer} {device.name}
                  </td>
                  {/* <td className="p-4">{device.manufacturer}</td> */}
                  <td className="pr-16 text-center">
                    <span className="p-1.5 rounded-sm text-2xs bg-neutral font-semibold text-neutral-content">
                      TO DO
                    </span>
                  </td>
                  <td className="text-right text-xs whitespace-nowrap">
                    {(device.updated_at || device.created_at) && (
                      <DateComponent
                        dateString={(device.updated_at || device.created_at) as string}
                      />
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <PageButtons
            data={data as CursorPage__T_Customized_DeviceUnderTestRead_}
            pageSize={pageSize}
            disabled={isFetching || isPlaceholderData}
            onClick={onPage}
          />
        </div>
      )}
    </div>
  );
};

export default DeviceUnderTestList;
