'use client';

import React, { useEffect, useState, useRef, use } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';

import { AlertObject } from '@/app/lib/definitions';
import TabBar, { TabProps } from 'app/components/TabBar';
import PageCard from 'app/components/PageCard';
import Breadcrumb from 'app/components/Breadcrumb';
import Link from 'next/link';
import Spinner from '@/app/components/Spinner';
import MarkdownHeader from '@/app/components/MarkdownHeader';
import MarkdownFooter from '@/app/components/MarkdownFooter';
import DateComponent from '@/app/components/Date';
import CopyButton from 'app/components/CopyButton';
import { addRecentTest } from '@/app/utils/localStorageUtils';

import {
  PlanGeneratorWebsocket,
  PlanReviserWebsocket,
  ToolPickerWebsocket
} from '@/app/lib/llm-websocket';

import LLMToolPicker from 'app/projects/LLMToolPicker';
import LLMPlanGenerator from 'app/projects/LLMPlanGenerator';
import LLMMarkdown, { MarkdownEditorRef } from 'app/projects/LLMMarkdown';
import TestPlanList from 'app/projects/TestPlanList';
import TestBenchList from 'app/projects/TestBenchList';

import {
  TestBenchReadWithDeviceInfo,
  TestBenchDeviceRead,
  TestPlanRead,
  TestBenchDevice
} from '@/app/client';
import { UnderTestService } from '@/app/client';

import { PlusIcon } from '@heroicons/react/24/solid';
import LoadingSpinner from '@/app/components/LoadingSpinner';

const tabsOpts: TabProps[] = [
  {
    title: 'Steps',
    name: 'plan',
    flag: { inProgress: true, done: false },
    disabled: false
  },
  {
    title: 'Bench',
    name: 'bench',
    flag: { inProgress: false, done: false },
    disabled: true
  }
  // {
  //   title: 'Automation',
  //   name: 'script',
  //   flag: { inProgress: false, done: false }
  //   disabled: true,
  // }
];

const Page: React.FC<{ params: Promise<{ id: number; functionSpecId: number }> }> = (props) => {
  const params = use(props.params);
  const [loading, setLoading] = useState<boolean>(false);
  const [alert, setAlert] = useState<AlertObject | null>(null);
  const [showTestPlanList, setShowTestPlanList] = useState<boolean>(true);
  const [showTestBenchList, setShowTestBenchList] = useState<boolean>(true);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [scrollMarkdown, setScrollMarkdown] = useState<boolean>(false);
  const [testPlanText, setTestPlanText] = useState<string | null>(null);
  const [markdownHeader, setMarkdownHeader] = useState<React.ReactNode | null>(null);
  const [markdownFooter, setMarkdownFooter] = useState<React.ReactNode | null>(null);
  const [tabs, setTabs] = useState<TabProps[]>(tabsOpts);
  const [activeTab, setActiveTab] = useState<TabProps | null>(null);

  const [testPlan, setTestPlan] = useState<TestPlanRead | null>(null);
  const [plansLoaded, setPlansLoaded] = useState<boolean>(false);
  const [planGenerating, setPlanGenerating] = useState<boolean>(false);

  const [testBench, setTestBench] = useState<TestBenchReadWithDeviceInfo | null>(null);
  const [benchesLoaded, setBenchesLoaded] = useState<boolean>(false);
  const [benchSuggesting, setBenchSuggesting] = useState<boolean>(false);

  const [key, setKey] = useState(0); // Add key for forcing remount

  const queryClient = useQueryClient();
  const markdownRef = useRef<MarkdownEditorRef>(null);

  const testPlansQueryKey = ['testPlans', params.functionSpecId];
  const cachedTestPlansQuery = queryClient.getQueryCache().find({ queryKey: testPlansQueryKey });
  const cachedTestPlans = cachedTestPlansQuery?.state?.data as TestPlanRead[];

  const testBenchesQueryKey = ['testBenches', params.functionSpecId];

  const [planWebsocket, setPlanWebsocket] = useState<
    PlanGeneratorWebsocket | PlanReviserWebsocket | null
  >(null);

  const [benchWebsocket, setBenchWebsocket] = useState<ToolPickerWebsocket | null>(null);

  let tabsLoaded = false;
  // get the device
  const { data: device } = useQuery({
    queryKey: ['deviceUnderTest', params.id],
    queryFn: () =>
      UnderTestService.viewDeviceUnderTestUnderTestDevicesDeviceIdGet({ deviceId: params.id }),
    staleTime: Infinity
  });

  const { data: functionSpec } = useQuery({
    queryKey: ['functionSpec', params.functionSpecId],
    queryFn: () =>
      UnderTestService.viewFunctionSpecUnderTestFunctionSpecsFunctionSpecIdGet({
        functionSpecId: params.functionSpecId
      }),
    staleTime: Infinity
  });

  const markdownFooterMap = {
    plan: (
      <MarkdownFooter
        content={
          <div>
            <CopyButton enabled={true} textToCopy={testPlanText as string} />
          </div>
        }
      />
    ),
    bench: (
      <MarkdownFooter
        content={
          <div>
            <p>
              <span className="font-semibold">Bench Footer:</span>
            </p>
          </div>
        }
      />
    ),
    script: (
      <MarkdownFooter
        content={
          <div>
            <p>
              <span className="font-semibold">Script Footer:</span>
            </p>
          </div>
        }
      />
    )
  };

  function handleGeneratorCancel() {
    setPlanGenerating(false);
    setLoading(false);
    setShowTestPlanList(true);
    setTestPlan(null);
    setTestPlanText(null);
    setAlert(null);
  }

  function handleGeneratorError() {
    setAlert({
      type: 'error',
      message: 'ERROR! Please try again.',
      onClick: () => setAlert(null)
    });
  }

  function generateTestPlan() {
    console.log('Generating new plan, setting NEW websocket');
    setLoading(true);
    setPlanGenerating(false);
    setShowTestPlanList(false);

    if (planWebsocket && planWebsocket.isConnected()) {
      planWebsocket.disconnect();
    }
    setPlanWebsocket(new PlanGeneratorWebsocket(params.functionSpecId));
    setMarkdownHeader(<MarkdownHeader busy={true} content="Generating test steps..." />);

    console.log('setting test plan text');
    setTestPlanText('...');
    setTestPlan(null);
  }

  function handlePlanGenerated(fullText: string) {
    setLoading(false);
    console.log(fullText);
    setTestPlanText(fullText);
    setKey((prev) => prev + 1); // Force remount when plan is generated
    setMarkdownHeader(
      <MarkdownHeader
        busy={false}
        content={`${testPlan ? 'Regenerated' : 'Generated new'} test steps.`}
      />
    );
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  function handlePlanRevise(humanText: string) {
    setLoading(true);
    setMarkdownHeader(<MarkdownHeader busy={true} content="Regenerating test steps..." />);
  }

  function handlePlanPersisted(newTestPlan: TestPlanRead) {
    setLoading(false);
    setPlanGenerating(false);
    setShowTestPlanList(true);
    setTestPlan(newTestPlan);
    setTestPlanText(newTestPlan.full_text);
    setKey((prev) => prev + 1); // Force remount when plan is persisted
    queryClient.invalidateQueries({ queryKey: testPlansQueryKey });
    addRecentTest(
      functionSpec?.id.toString() || '',
      functionSpec?.name || 'Untitled Test Plan',
      device?.id.toString() || ''
    );
    setAlert({
      type: 'success',
      message: 'New test plan version created.',
      onClick: () => setAlert(null)
    });
    setMarkdownHeader(
      <MarkdownHeader
        busy={false}
        content={
          <span>
            Saved New Version:&nbsp;
            <DateComponent
              dateString={newTestPlan.updated_at || (newTestPlan.created_at as string)}
            />
          </span>
        }
      />
    );
    updateTabStates();
  }

  function handleTestPlanSelected(selectedTestPlan: TestPlanRead) {
    console.log('Plan selected, setting revise websocket');
    setPlanWebsocket(new PlanReviserWebsocket(selectedTestPlan.id));
    setLoading(false);
    setPlanGenerating(false);
    setTestPlan(selectedTestPlan);
    setTestPlanText(selectedTestPlan.full_text);
    setKey((prev) => prev + 1); // Force remount when plan is selected
    addRecentTest(
      functionSpec?.id.toString() || '',
      functionSpec?.name || 'Untitled Test Plan',
      device?.id.toString() || ''
    );
    setMarkdownHeader(
      <MarkdownHeader
        busy={false}
        content={
          <span>
            Version:&nbsp;
            <DateComponent
              dateString={selectedTestPlan.updated_at || (selectedTestPlan.created_at as string)}
            />
          </span>
        }
      />
    );
  }

  function handleTestPlanDeleted(deletedTestPlan: TestPlanRead) {
    setAlert({
      type: 'success',
      message: 'Test plan deleted.',
      onClick: () => setAlert(null)
    } as AlertObject);
    if (deletedTestPlan.id === testPlan?.id) {
      setTestPlan(null);
      setTestPlanText(null);
    }
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  function handleTestPlanError(error: any) {
    setAlert({
      type: 'error',
      message: 'ERROR! Please try again.',
      onClick: () => setAlert(null)
    } as AlertObject);
  }

  function suggestTestBench() {
    console.log('Suggesting new bench');
    setLoading(true);
    setBenchSuggesting(false);
    setShowTestBenchList(false);

    if (benchWebsocket && benchWebsocket.isConnected()) {
      benchWebsocket.disconnect();
    }
    setBenchWebsocket(new ToolPickerWebsocket(testPlan!.id));

    setTestBench(null);
  }

  function handleBenchSuggested(testBenchDevices: TestBenchDeviceRead[] | TestBenchDevice[]) {
    setLoading(false);
    console.log(testBenchDevices);
    setKey((prev) => prev + 1); // Force remount when plan is generated
  }

  function handleBenchPersisted(newTestBench: TestBenchReadWithDeviceInfo) {
    setLoading(false);
    setBenchSuggesting(false);
    setShowTestBenchList(true);
    setTestBench(newTestBench);
    setKey((prev) => prev + 1); // Force remount when bench is persisted
    queryClient.invalidateQueries({ queryKey: testBenchesQueryKey });
    setAlert({
      type: 'success',
      message: 'New test bench created.',
      onClick: () => setAlert(null)
    });
    updateTabStates();
  }

  function handleTestBenchesLoaded(testBenches: TestBenchReadWithDeviceInfo[]) {
    console.log('Test Benches loaded');
    if (testBenches.length > 0) {
      handleTestBenchSelected(testBenches[testBenches.length - 1]);
    }
    setBenchesLoaded(true);
  }

  function handleTestBenchSelected(selectedTestBench: TestBenchReadWithDeviceInfo) {
    console.log('Bench selected');
    setLoading(false);
    setBenchSuggesting(false);
    setTestBench(selectedTestBench);
    setKey((prev) => prev + 1); // Force remount when plan is selected
  }

  function handleTestBenchDeleted(deletedTestBench: TestBenchReadWithDeviceInfo) {
    setAlert({
      type: 'success',
      message: 'Test bench deleted.',
      onClick: () => setAlert(null)
    } as AlertObject);
    if (deletedTestBench.id === testBench?.id) {
      setTestBench(null);
    }
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  function handleTestBenchError(error: any) {
    setAlert({
      type: 'error',
      message: 'ERROR! Please try again.',
      onClick: () => setAlert(null)
    } as AlertObject);
  }

  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  function updatedTab(tab: TabProps, currentTab: TabProps, index: number) {
    let objectRel, disabled;
    switch (tab.name) {
      case 'plan': {
        objectRel = testPlan;
        disabled = false;
        break;
      }
      case 'bench': {
        objectRel = testBench;
        disabled = !testPlan;
        break;
      }
      case 'script': {
        objectRel = null;
        disabled = !testPlan;
        break;
      }
      default: {
        objectRel = null;
        disabled = true;
        break;
      }
    }

    const isSelected = currentTab?.name === tab.name;
    const done = Array.isArray(objectRel) ? objectRel.length > 0 : objectRel !== null;
    const inProgress = !done && isSelected;

    return {
      ...tab,
      flag: {
        ...tab.flag,
        inProgress: inProgress,
        done: done
      },
      disabled: disabled
    };
  }

  function updateTabStates(newTab?: TabProps) {
    console.log('updateTabStates');
    setTabs((prevTabs) =>
      prevTabs.map((pt, i) => updatedTab(pt, (newTab || activeTab) as TabProps, i))
    );
  }

  function handleTabChange(tab: TabProps) {
    console.log('handleTabChange', tab);
    setActiveTab(tab);
    setMarkdownFooter(markdownFooterMap[tab.name as keyof typeof markdownFooterMap]);
    updateTabStates(tab);
    setLoading(false);

    if (tab.name === 'plan') {
      setShowTestPlanList(true);
      setShowTestBenchList(false);

      if (testPlan) {
        console.log('switched and there IS a test plan');
      } else {
        console.log("switched and there's NO test plan");
      }
    }

    if (tab.name === 'bench') {
      setShowTestBenchList(true);
      setShowTestPlanList(false);
      setLoading(false);

      if (testPlan) {
        // TODO: reset websocket????
        if (benchWebsocket && benchWebsocket.isConnected()) {
          benchWebsocket.disconnect();
        }
        setBenchWebsocket(new ToolPickerWebsocket(testPlan.id));
      }
    }
  }

  useEffect(() => {
    if (tabsLoaded) return;
    // eslint-disable-next-line react-hooks/exhaustive-deps
    tabsLoaded = true;
    if (tabs) {
      handleTabChange(tabs[0]);
    }
  }, []);

  // on initial load of previously generated plan list,
  // get the latest one and put it in the editor
  useEffect(() => {
    if (cachedTestPlans) {
      if (testPlan) return;

      if (cachedTestPlans.length > 0) {
        console.log('found recent testPlan');
        handleTestPlanSelected(cachedTestPlans[cachedTestPlans.length - 1]);
      } else {
        console.log('NO recent testPlan');
        generateTestPlan();
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cachedTestPlans]);

  useEffect(() => {
    if (testPlan) {
      updateTabStates();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [testPlan]);

  return (
    <div>
      <PageCard
        title={
          device && functionSpec ? (
            <Breadcrumb
              trail={[
                <Link className="hover:underline" href="/projects" key="0">
                  Projects
                </Link>,
                <Link className="hover:underline" href={`/projects/${device.id}`} key="1">
                  {device.name}
                </Link>,
                <span className="text-primary" key="2">
                  {functionSpec.name}
                </span>
              ]}
            />
          ) : (
            ''
          )
        }
        alert={alert}
        headerNodes={
          activeTab?.name === 'plan' && plansLoaded && testPlan
            ? [
                <button key="0" className="btn btn-sm btn-success" onClick={generateTestPlan}>
                  <PlusIcon className="mb-0.5 size-4" /> Generate new Test Plan
                </button>
              ]
            : activeTab?.name === 'bench' && benchesLoaded && testBench
              ? [
                  <button key="0" className="btn btn-sm btn-success" onClick={suggestTestBench}>
                    <PlusIcon className="mb-0.5 size-4" /> Suggest new Test Bench
                  </button>
                ]
              : []
        }
      >
        <div className="mt-2 mb-4">
          {functionSpec ? (
            <h1 className="text-2xl font-bold">{functionSpec?.name}</h1>
          ) : (
            <div className="flex flex-column mb-7">
              <h1 className="text-2xl font-bold">
                <Spinner>Loading device and function to test...</Spinner>
              </h1>
            </div>
          )}
        </div>

        <TabBar tabs={tabs} selectedTab={activeTab} onClick={handleTabChange} progressive={true} />

        {activeTab?.name === 'plan' && (
          <div>
            {!testPlan && !plansLoaded && (
              <Spinner className="mt-8">Loading most recent test plan version...</Spinner>
            )}

            {plansLoaded && (
              <LLMPlanGenerator
                webSocket={planWebsocket}
                testPlan={testPlan}
                inProgress={planGenerating}
                onGenerate={() => setPlanGenerating(true)}
                onGenerated={handlePlanGenerated}
                onRevise={handlePlanRevise}
                onPersisted={handlePlanPersisted}
                onCancel={handleGeneratorCancel}
                onError={handleGeneratorError}
                markdown={
                  <LLMMarkdown
                    key={key}
                    ref={markdownRef}
                    markdownHeader={markdownHeader as string}
                    markdownFooter={markdownFooter as string}
                    markdownText={testPlanText as string}
                    loading={loading}
                    error={false}
                    shouldScroll={scrollMarkdown}
                  />
                }
              />
            )}

            {showTestPlanList && (
              <TestPlanList
                functionSpecId={params.functionSpecId}
                testPlan={testPlan!}
                onLoaded={() => setPlansLoaded(true)}
                onClick={handleTestPlanSelected}
                onDeleted={handleTestPlanDeleted}
                onError={handleTestPlanError}
              />
            )}
          </div>
        )}

        {activeTab?.name === 'bench' && testPlan && (
          <div>
            {!testBench && !benchesLoaded && (
              <LoadingSpinner title="Loading most recent test bench version..." />
            )}

            {benchesLoaded && (
              <LLMToolPicker
                webSocket={benchWebsocket}
                testPlanId={testPlan.id}
                testBench={testBench}
                inProgress={benchSuggesting}
                onSuggest={() => setBenchSuggesting(true)}
                onSuggested={handleBenchSuggested}
                onPersisted={handleBenchPersisted}
                onRevise={() => setLoading(true)}
              />
            )}

            {showTestBenchList && (
              <TestBenchList
                testPlanId={testPlan.id}
                functionSpecId={params.functionSpecId}
                testBench={testBench!}
                onLoaded={handleTestBenchesLoaded}
                onClick={handleTestBenchSelected}
                onDeleted={handleTestBenchDeleted}
                onError={handleTestBenchError}
              />
            )}
          </div>
        )}

        {activeTab?.name === 'script' && <div>Script</div>}
      </PageCard>
    </div>
  );
};

export default Page;
