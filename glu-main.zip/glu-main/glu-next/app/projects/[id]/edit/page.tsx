'use client';

import React, { useState, use } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import PageCard from 'app/components/PageCard';
import ConfirmDialog from 'app/components/ConfirmDialog';
import DeviceUnderTestForm from '../../DeviceUnderTestForm';
import Breadcrumb from 'app/components/Breadcrumb';
import Link from 'next/link';
import { ArrowUturnLeftIcon, XCircleIcon } from '@heroicons/react/24/solid';

import { DeviceUnderTest } from '@/app/client';
import { UnderTestService } from '@/app/client';

const Page: React.FC<{ params: Promise<{ id: number }> }> = (props) => {
  const params = use(props.params);
  const [deleteInProgress, setDeleteInProgress] = useState<boolean>(false);
  const [confirmOpen, setConfirmOpen] = useState<boolean>(false);

  const router = useRouter();

  const { data: device, isLoading: deviceIsLoading } = useQuery({
    queryKey: ['deviceUnderTest', params.id],
    queryFn: () =>
      UnderTestService.viewDeviceUnderTestUnderTestDevicesDeviceIdGet({ deviceId: params.id }),
    staleTime: 10000,
    refetchOnWindowFocus: false
  });

  const handleSuccess = (device: DeviceUnderTest) => {
    router.push(`/projects/${device.id}`);
  };

  const deleteProject = () => {
    setDeleteInProgress(true);
    UnderTestService.deleteDeviceUnderTestUnderTestDevicesDeviceIdDelete({
      deviceId: params.id
    })
      .then(() => {
        router.push(`/projects`);
      })
      .finally(() => {
        setDeleteInProgress(false);
      });
  };

  return (
    <div className="flex flex-col w-full">
      <PageCard
        title={
          device && (
            <Breadcrumb
              trail={[
                <Link className="hover:underline" href="/projects" key="0">
                  Projects
                </Link>,
                <Link className="hover:underline" href={`/projects/${device.id}`} key="1">
                  {device.manufacturer} {device.name}
                </Link>,
                <span className="text-primary" key="2">
                  Edit
                </span>
              ]}
            />
          )
        }
        headerNodes={[
          <a className="btn-sm btn" href={`/projects/${device?.id}`} key="0">
            <ArrowUturnLeftIcon className="size-4 mb-[2px]" />
            Back
          </a>,
          <div key="1">
            <a
              className="btn-sm btn btn-outline btn-error ml-4"
              aria-label="delete"
              onClick={() => setConfirmOpen(true)}
            >
              <XCircleIcon className="size-4 mb-[2px]" />
              Delete Project
            </a>
            <ConfirmDialog
              title="Delete Project?"
              open={confirmOpen}
              onClose={() => setConfirmOpen(false)}
              onConfirm={deleteProject}
            >
              Are you sure you want to delete this project?
            </ConfirmDialog>
          </div>
        ]}
      >
        <div className="p-4">
          {deleteInProgress && (
            <div className="flex-1 flex flex-row">
              <span className="loading loading-spinner text-primary loading-md mr-2"></span>
              Deleting project...
            </div>
          )}
          {deviceIsLoading && (
            <div className="flex-1 flex flex-row">
              <span className="loading loading-spinner text-primary loading-md mr-2"></span>
              Loading project...
            </div>
          )}
          {!deviceIsLoading && <DeviceUnderTestForm device={device} onSuccess={handleSuccess} />}
        </div>
      </PageCard>
    </div>
  );
};

export default Page;
