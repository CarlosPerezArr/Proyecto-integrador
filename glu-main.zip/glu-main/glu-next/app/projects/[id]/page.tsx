'use client';

import { useQuery, useQueryClient } from '@tanstack/react-query';
import React, { useState, useEffect, use } from 'react';
import { trackUser, trackEvent } from '@/app/lib/mixpanel';

import { ArrowUturnLeftIcon, PencilSquareIcon, PlusIcon } from '@heroicons/react/24/solid';
import { CheckCircleIcon, ExclamationCircleIcon } from '@heroicons/react/24/outline';

import Link from 'next/link';
import PageCard from '@/app/components/PageCard';
import TabBar, { TabProps } from '@/app/components/TabBar';
import Breadcrumb from 'app/components/Breadcrumb';
import DateComponent from '@/app/components/Date';
import Spinner from '@/app/components/Spinner';

import DeviceSpecList from '../DeviceSpecList';
import FunctionSpecList from '../FunctionSpecList';
import DeviceSpecUploader from '../DeviceSpecUploader';

import { AlertObject } from '@/app/lib/definitions';
import { InfoService } from '@/app/client';
import { DeviceSpecRead, UnderTestService } from '@/app/client';
import { addRecentItem } from '@/app/utils/localStorageUtils';

const tabsOpts: TabProps[] = [
  {
    title: 'Tests',
    name: 'tests'
  },
  {
    title: 'Bench',
    name: 'bench'
  },
  {
    title: 'Documents',
    name: 'specs'
  }
];

const Page: React.FC<{ params: Promise<{ id: number }> }> = (props) => {
  const params = use(props.params);
  const queryClient = useQueryClient();
  const [alert, setAlert] = useState<AlertObject | null>(null);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [tabs, setTabs] = useState<TabProps[]>(tabsOpts);
  const [activeTab, setActiveTab] = useState<TabProps>(tabs[0]);
  const [showUpload, setShowUpload] = useState<boolean>(false);
  const [uploading, setUploading] = useState<boolean>(false);
  const [deviceSpec, setDeviceSpec] = useState<DeviceSpecRead | null>(null);
  const [specIsLatestVersion, setSpecIsLatestVersion] = useState<boolean>(true);

  const { data: user } = useQuery({
    queryKey: ['userRead'],
    queryFn: () => InfoService.getUserInfoUserInfoGet(),
    staleTime: Infinity
  });

  if (user) {
    trackUser(user);
  }

  const {
    data: device,
    isLoading: deviceIsLoading,
    isError: deviceIsError
  } = useQuery({
    queryKey: ['deviceUnderTest', params.id],
    queryFn: () =>
      UnderTestService.viewDeviceUnderTestUnderTestDevicesDeviceIdGet({ deviceId: params.id }),
    staleTime: Infinity,
    refetchOnWindowFocus: false
  });

  // Save project to local storage when it's loaded
  useEffect(() => {
    if (device) {
      addRecentItem({
        id: device.id.toString(),
        type: 'project',
        name: device.name,
        timestamp: Date.now()
      });
    }
  }, [device]);

  const handleUploadComplete = (newDeviceSpecId: number) => {
    queryClient.invalidateQueries({ queryKey: ['deviceUnderTest', params.id] });
    setActiveTab(tabs.find((t) => t.name === 'tests') || tabs[0]);
    setShowUpload(false);
    setUploading(false);
    setAlert({
      type: 'success',
      message: 'Document uploaded successfully.',
      onClick: () => setAlert(null)
    } as AlertObject);
    trackEvent('Document Upload', user!.email, { deviceSpecId: newDeviceSpecId });
  };

  useEffect(() => {
    if (device && device.device_specs && device.device_specs.length > 0) {
      const newDeviceSpec = device.device_specs[device.device_specs.length - 1];
      setDeviceSpec(newDeviceSpec);
    }
  }, [device]);

  function updateDeviceSpec(spec: DeviceSpecRead, isLatestVersion: boolean) {
    setDeviceSpec(spec);
    setSpecIsLatestVersion(isLatestVersion);
    setActiveTab(tabs.find((t) => t.name === 'tests') || tabs[0]);
    queryClient.setQueryData(['deviceUnderTest', params.id, 'deviceSpec'], spec);
  }

  function handleDeleteDeviceSpec(spec: DeviceSpecRead) {
    setAlert({
      type: 'success',
      message: 'Document deleted.',
      onClick: () => setAlert(null)
    } as AlertObject);

    const currentDevice = device;
    if (currentDevice?.device_specs) {
      currentDevice.device_specs = currentDevice.device_specs.filter((s) => s.id !== spec.id);
      queryClient.setQueryData(['deviceUnderTest', params.id], currentDevice);
      if (spec.id === deviceSpec?.id) {
        setDeviceSpec(currentDevice.device_specs[0]);
        updateDeviceSpec(currentDevice.device_specs[0], true);
      }
    }
  }

  function handleDeleteDeviceSpecError() {
    setAlert({
      type: 'error',
      message: 'ERROR! Please try again.',
      onClick: () => setAlert(null)
    } as AlertObject);
  }

  return (
    <div>
      {tabs && activeTab && (
        <PageCard
          title={
            device && (
              <Breadcrumb
                trail={[
                  <Link className="hover:underline" href="/projects" key="0">
                    Projects
                  </Link>,
                  <span className="text-primary" key="1">
                    {device.manufacturer} {device.name}
                  </span>
                ]}
              />
            )
          }
          alert={alert}
          headerNodes={
            device
              ? [
                  <a
                    className="btn-sm btn btn-primary flex items-center"
                    href={`/projects/${device?.id}/edit`}
                    key="1"
                  >
                    <PencilSquareIcon className="size-4 mb-[2px]" />
                    Edit Project
                  </a>
                ]
              : []
          }
        >
          <h1 className="text-3xl">
            <strong>
              {device?.manufacturer} {device?.name}
            </strong>
          </h1>

          {device && <TabBar tabs={tabs} selectedTab={activeTab} onClick={setActiveTab} />}
          {device && (
            <div className="my-4 flex justify-between items-center min-h-8">
              {!showUpload && deviceSpec && (
                <div className="flex items-center">
                  <span className="font-mono font-semibold mr-2">DOCUMENT VERSION:</span>
                  <span className="">
                    <DateComponent
                      dateString={(deviceSpec.updated_at || deviceSpec.created_at) as string}
                    />
                  </span>
                  {specIsLatestVersion && (
                    <div
                      className="tooltip tooltip-right tooltip-secondary"
                      data-tip="Latest version"
                    >
                      <CheckCircleIcon className="ml-2 text-secondary size-6" />
                    </div>
                  )}
                  {!specIsLatestVersion && (
                    <div
                      className="tooltip tooltip-right tooltip-error"
                      data-tip="Newer version available"
                    >
                      <ExclamationCircleIcon className="ml-2 text-error size-6" />
                    </div>
                  )}
                </div>
              )}
              {activeTab.name === 'specs' && !showUpload && device && (
                <div className="flex justify-end">
                  <a className="btn-sm btn btn-secondary" onClick={() => setShowUpload(true)}>
                    <PlusIcon className="mb-0.5 size-4" />
                    Upload New Document
                  </a>
                </div>
              )}
              {activeTab.name === 'specs' && showUpload && device && (
                <div className="flex justify-end w-full">
                  <a
                    className={`btn-sm btn ${uploading ? 'btn-error btn-outline' : ''}`}
                    onClick={() => setShowUpload(false)}
                  >
                    <ArrowUturnLeftIcon className="size-4 mb-[2px]" />
                    Cancel
                  </a>
                </div>
              )}
            </div>
          )}

          <div className="flex flex-col w-full my-4">
            {deviceIsLoading && <Spinner>Loading project...</Spinner>}
            {deviceIsError && (
              <p>Error loading device and spec documents, please try again later.</p>
            )}

            {activeTab.name === 'tests' && device && deviceSpec && (
              <FunctionSpecList deviceUnderTest={device} deviceSpec={deviceSpec} />
            )}

            {activeTab.name === 'specs' && !showUpload && device && (
              <div>
                {device && (
                  <DeviceSpecList
                    onSelectDeviceSpec={updateDeviceSpec}
                    onDelete={handleDeleteDeviceSpec}
                    onDeleteError={handleDeleteDeviceSpecError}
                    deviceSpecs={device.device_specs as DeviceSpecRead[]}
                  />
                )}
              </div>
            )}

            {activeTab.name === 'specs' && showUpload && device && (
              <DeviceSpecUploader
                device={device}
                onComplete={handleUploadComplete}
                onSubmit={() => {
                  setUploading(true);
                }}
                disconnect={!showUpload}
              />
            )}
          </div>
        </PageCard>
      )}
    </div>
  );
};

export default Page;
