'use client';

import React, { useEffect, useState } from 'react';
import { useMutation } from '@tanstack/react-query';

import FileUploadForm from '../components/FileUploadForm';
import GenericProgressBar from '@/app/components/ProgressBarGeneric';
import ProgressBar from '@/app/components/ProgressBar';
import { DeviceUnderTest, FunctionSpecRead, UnderTestService } from '@/app/client';
import { WebSocketMessage } from '@/app/lib/definitions';
import { getWebSocketState, maxConnectionTries } from '@/app/lib/WebSocketConfig';

interface DeviceSpecUploaderProps {
  device: DeviceUnderTest;
  deviceSpecId?: number;
  onSubmit?: () => void;
  onError?: () => void;
  onComplete?: (deviceSpecId: number, functionSpecs?: FunctionSpecRead[]) => void;
  disconnect?: boolean;
}

const DeviceSpecUploader: React.FC<DeviceSpecUploaderProps> = ({
  device,
  deviceSpecId,
  onComplete,
  onSubmit,
  onError,
  disconnect
}) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<boolean>(false);
  const [errorCode, setErrorCode] = useState<number | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [specFile, setSpecFile] = useState<File | null>(null);
  const [numPages, setNumPages] = useState<number>(0);
  const [currentFeatureWindow, setCurrentFeatureWindow] = useState<number>(0);
  const [featureWindowCount, setFeatureWindowCount] = useState<number>(0);
  const [processedPages, setProcessedPages] = useState<number[]>([]);

  const [webSocket, setWebSocket] = useState<WebSocket | null>(null);
  const [webSocketState, setWebSocketState] = useState<string>(getWebSocketState(3));
  const [connectionError, setConnectionError] = useState<boolean>(false);
  const [connectionTries, setConnectionTries] = useState<number>(0);

  const [pageProcessingComplete, setPageProcessingComplete] = useState<boolean>(false);
  const [chunkProcessingComplete, setChunkProcessingComplete] = useState<boolean>(false);
  const [featureProcessingComplete, setFeatureProcessingComplete] = useState<boolean>(false);

  // socket connection states
  let connectionInProgress = false;

  useEffect(() => {
    if (webSocket) {
      webSocket.onopen = handleSocketOpen;
      webSocket.onclose = handleSocketClose;
      webSocket.onerror = handleSocketError;
      webSocket.onmessage = handleSocketMessage;
    } else if (loading) {
      if (connectionTries >= maxConnectionTries) {
        handleConnectionFailure();
        return;
      }
      connectWebSocket();
    }
  }, [webSocket, loading]);

  function connectWebSocket() {
    if (connectionInProgress) return;
    connectionInProgress = true;
    setConnectionTries(connectionTries + 1);
    console.log('Opening connection');
    setWebSocketState('CONNECTING');
    const socketUrl = `${process.env.NEXT_PUBLIC_API_WEBSOCKET_URL}/under_test_ws/add_spec`;
    setWebSocket(new WebSocket(socketUrl));
  }

  function handleConnectionFailure() {
    setWebSocket(null);
    setConnectionError(true);
    connectionInProgress = false;
  }

  function handleSocketOpen() {
    console.log('Connection opened');
    setConnectionTries(0);
    setWebSocketState('OPEN');
    connectionInProgress = false;
    resetUploader();
  }

  function handleSocketClose() {
    console.log('Connection closed');
    setLoading(false);
    setWebSocketState('CLOSED');
    setWebSocket(null);
    setSpecFile(null);
    setNumPages(0);
    setProcessedPages([]);
    setPageProcessingComplete(false);
    setChunkProcessingComplete(false);
    setFeatureProcessingComplete(false);
  }

  function handleSocketError(event: Event) {
    console.error('WebSocket error:', event);
    setError(true);
    setSpecFile(null);

    const ws = event.target as WebSocket;
    if (getWebSocketState(Number(ws.readyState)) === 'CLOSED') {
      setConnectionError(true);
    }

    setTimeout(() => {
      setError(false);
      if (onError) onError();
    }, 5000);
  }

  function handleSocketMessage(event: MessageEvent) {
    if (event.data.includes('ACK')) return;

    console.log('Handling inbound message', event.data);
    const message = JSON.parse(event.data) as WebSocketMessage;
    const isError = message.is_error;
    const payload = message.payload;

    if (isError) {
      setError(true);
      setErrorCode(message.code);
      if (onError) onError();
      return;
    }

    if (payload) {
      handleSocketMessagePayload(payload);
      return;
    }
  }

  function handleSocketMessagePayload(payload: any) {
    console.log('Handling message payload:', payload);
    if (payload.event_type) {
      switch (payload.event_type) {
        case 'page_processed': {
          console.log('Message payload: Event - page processed');
          if (numPages === 0 && payload.page_count) {
            setNumPages(parseInt(payload.page_count));
          }

          const pageNumber = parseInt(payload.page_number);
          if (processedPages.includes(pageNumber)) return;

          processedPages.push(pageNumber);
          setProcessedPages([...processedPages]);
          break;
        }
        case 'chunks_processed': {
          console.log('Message payload: Event - chunks processed');
          setChunkProcessingComplete(true);
          break;
        }
        case 'feature_extracted': {
          console.log('Message payload: Event - feature extracted');
          const currentWindow = parseInt(payload.current_window);
          const windowCount = parseInt(payload.window_count);
          setCurrentFeatureWindow(currentWindow);
          setFeatureWindowCount(windowCount);
          break;
        }
        case 'features_extracted': {
          console.log('Message payload: Event - features extracted');
          setFeatureProcessingComplete(true);
          break;
        }
        case 'document_processed': {
          console.log('Message payload: Event - doc processed');
          handleComplete(parseInt(payload.devicespec_id));
          break;
        }
        default: {
          break;
        }
      }
      return;
    }
  }

  const fileReader = new FileReader();
  fileReader.onload = (e) => {
    if (!webSocket || !e.target || !e.target.result) {
      return;
    }
    setLoading(true);
    webSocket.send(e.target.result as ArrayBuffer);
  };

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    setError(false);
  };

  const handleUpload = () => {
    if (!selectedFile || !device) {
      setError(true);
      return;
    }

    if (!webSocket) {
      setError(true);
      setLoading(false);
      setTimeout(() => {
        setError(false);
        if (onError) onError();
      }, 5000);
      return;
    }

    setLoading(true);
    if (onSubmit) onSubmit();

    setSpecFile(selectedFile);

    webSocket.send(
      JSON.stringify({
        device_under_test_id: device.id,
        filename: selectedFile.name
      })
    );
    fileReader.readAsArrayBuffer(selectedFile);
  };

  const handleComplete = (newDeviceSpecId: number, functionSpecs?: FunctionSpecRead[]) => {
    if (onComplete) {
      onComplete(newDeviceSpecId, functionSpecs);
      resetUploader();
    }
  };

  const resetUploader = () => {
    setSelectedFile(null);
    setSpecFile(null);
    setNumPages(0);
    setProcessedPages([]);
    setPageProcessingComplete(false);
    setChunkProcessingComplete(false);
    setFeatureProcessingComplete(false);
  };

  const mutation = useMutation({
    mutationFn: (id: number) =>
      UnderTestService.createFunctionSpecsUnderTestFunctionSpecsDeviceSpecIdPost({
        deviceSpecId: id
      }),
    onSuccess: (data) => {
      setFeatureProcessingComplete(true);
      setLoading(false);
      handleComplete(deviceSpecId as number, data);
    }
  });

  useEffect(() => {
    if (!deviceSpecId && !webSocket) {
      if (connectionTries >= maxConnectionTries) {
        setConnectionError(true);
        return;
      }
      connectWebSocket();
    }
  }, [deviceSpecId, webSocket, connectionTries]);

  useEffect(() => {
    if (disconnect) {
      if (webSocket) {
        webSocket.close();
      }
    }
  }, [disconnect]);

  if (deviceSpecId && !featureProcessingComplete) {
    if (mutation.isIdle) mutation.mutate(deviceSpecId);
  }

  const allowedExtensions = ['.pdf', '.doc', '.docx'];

  return (
    <div className="p4">
      {!(webSocketState === 'OPEN') && !deviceSpecId && !error && !connectionError && (
        <div className="flex flex-row">
          <span className="loading loading-spinner text-primary loading-md mr-2"></span>Establishing
          server connection...
        </div>
      )}

      {!(webSocketState === 'OPEN') && connectionError && (
        <div className="text-red-500">Error connecting to server.</div>
      )}

      {!loading && webSocketState === 'OPEN' && !deviceSpecId && (
        <FileUploadForm
          onFileSelect={handleFileSelect}
          onUpload={handleUpload}
          isLoading={loading}
          allowedExtensions={allowedExtensions}
          maxSizeInMB={10}
        />
      )}

      {loading && specFile && !deviceSpecId && (
        <div>
          {!pageProcessingComplete && numPages === 0 && (
            <GenericProgressBar
              title={`Warming the Engines (${specFile.name})`}
              current={0}
              total={0}
            />
          )}
          {!pageProcessingComplete && numPages > 0 && (
            <GenericProgressBar
              title={`Parsing the Pages (${specFile.name})`}
              current={processedPages.length}
              total={numPages}
              onComplete={() => setPageProcessingComplete(true)}
            />
          )}
          {pageProcessingComplete && !featureProcessingComplete && (
            <GenericProgressBar
              title={`Finding the Features (${specFile.name})`}
              current={currentFeatureWindow}
              total={featureWindowCount}
              onComplete={() => setPageProcessingComplete(true)}
            />
          )}
        </div>
      )}

      {deviceSpecId && !featureProcessingComplete && (
        <div>
          <ProgressBar durationSeconds={20} title="Extracting device features from specs..." />
        </div>
      )}

      {error && (
        <div className="text-red-500">Error uploading spec document. Please try again later.</div>
      )}
    </div>
  );
};

export default DeviceSpecUploader;
