import { useState } from 'react';
import { UnderTestService } from '@/app/client';
import { DeviceSpecRead } from '@/app/client';

import ConfirmDialog from 'app/components/ConfirmDialog';
import DateComponent from '@/app/components/Date';
import Image from 'next/image';
import { TrashIcon } from '@heroicons/react/24/solid';

interface DeviceSpecListProps {
  deviceSpecs: DeviceSpecRead[];
  onSelectDeviceSpec?: (spec: DeviceSpecRead, isLatestVersion: boolean) => void;
  onDelete?: (spec: DeviceSpecRead) => void;
  onDeleteError?: (error: any) => void;
}

const DeviceSpecList: React.FC<DeviceSpecListProps> = ({
  deviceSpecs,
  onSelectDeviceSpec,
  onDelete,
  onDeleteError
}) => {
  const [deviceSpecToDelete, setDeviceSpecToDelete] = useState<DeviceSpecRead | null>(null);
  const [confirmOpen, setConfirmOpen] = useState<boolean>(false);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [deleteInProgress, setDeleteInProgress] = useState<boolean>(false);

  function selectDeviceSpec(spec: DeviceSpecRead) {
    const isLatestVersion = sortedDeviceSpecs(deviceSpecs)[0]?.id === spec.id;
    if (onSelectDeviceSpec) onSelectDeviceSpec(spec, isLatestVersion);
  }

  function sortedDeviceSpecs(specs: DeviceSpecRead[]) {
    return specs.sort(
      (a, b) =>
        (new Date((b.updated_at || b.created_at)!).getTime() as number) -
        (new Date((a.updated_at || a.created_at)!).getTime() as number)
    );
  }

  function deleteDeviceSpec() {
    if (!deviceSpecToDelete) return;
    setDeleteInProgress(true);
    UnderTestService.deleteDeviceSpecUnderTestDeviceSpecsDeviceSpecIdDelete({
      deviceSpecId: deviceSpecToDelete.id
    })
      .then(() => {
        if (onDelete) onDelete(deviceSpecToDelete);
      })
      .catch((error) => {
        if (onDeleteError) onDeleteError(error);
      })
      .finally(() => {
        setDeleteInProgress(false);
      });
  }

  return (
    <div>
      {deviceSpecs.length === 0 && <p className="p-4">No device specs found.</p>}
      {deviceSpecs.length > 0 && (
        <div>
          <table className={`table-auto font-mono text-sm`}>
            <thead>
              <tr className="border-b border-white font-semibold text-left">
                <th className="w-full pr-2">DOCUMENT NAME</th>
                <th className="whitespace-nowrap text-right pr-8">LAST UPDATED</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {sortedDeviceSpecs(deviceSpecs).map((spec, index) => (
                <tr
                  key={index}
                  className="group cursor-pointer hover:bg-black hover:text-primary border-b border-white"
                  onClick={() => selectDeviceSpec(spec)}
                >
                  <td className="py-4 pr-2 flex flex-row">
                    <Image
                      className="mr-2"
                      src="/icon-folder.svg"
                      alt="projects"
                      width="20"
                      height="20"
                    />
                    {spec.filename}
                  </td>
                  <td className="pr-8 text-right text-xs whitespace-nowrap">
                    {(spec.updated_at || spec.created_at) && (
                      <DateComponent dateString={(spec.updated_at || spec.created_at) as string} />
                    )}
                  </td>
                  <td className="whitespace-nowrap">
                    <a
                      className="invisible group-hover:visible flex mx-4 hover:text-error align-center w-4 h-4 text-white"
                      aria-label="delete"
                      onClick={(e) => {
                        setConfirmOpen(true);
                        setDeviceSpecToDelete(spec);
                        e.stopPropagation();
                      }}
                    >
                      <TrashIcon />
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <ConfirmDialog
            title="Delete Document?"
            open={confirmOpen}
            onClose={() => {
              setConfirmOpen(false);
              setDeviceSpecToDelete(null);
            }}
            onConfirm={deleteDeviceSpec}
          >
            Are you sure you want to delete this Document?
          </ConfirmDialog>
        </div>
      )}
    </div>
  );
};

export default DeviceSpecList;
