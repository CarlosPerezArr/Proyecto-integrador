'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Gleap from 'gleap';

export default function Home() {
  const router = useRouter();

  useEffect(() => {
    router.push('/projects');
  });
  useEffect(() => {
    // Run within useEffect to execute this code on the frontend.
    Gleap.initialize('JRwGbHdBXC3dceOQx4Wl00JhrpJV1R57');
  }, []);

  return;
}
