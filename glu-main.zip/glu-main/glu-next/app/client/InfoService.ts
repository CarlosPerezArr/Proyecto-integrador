/* eslint-disable */
import type { CancelablePromise } from './core/CancelablePromise';
import { OpenAPI } from './core/OpenAPI';
import { request as __request } from './core/request';
import { UserRead } from './types.gen';

export class InfoService {
  /**
   * Get User Info
   * Retrieve information about the currently authenticated user.
   * @returns UserRead Successful Response
   * @throws ApiError
   */
  public static getUserInfoUserInfoGet(): CancelablePromise<UserRead> {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/user_info',
      errors: {
        422: `Validation Error`
      }
    });
  }

  /**
   * Get System Info
   * Retrieve general system information.
   * @returns any Successful Response
   * @throws ApiError
   */
  public static getSystemInfoSystemInfoGet(): CancelablePromise<any> {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/system_info',
      errors: {
        422: `Validation Error`
      }
    });
  }

  /**
   * Get Application Version
   * Retrieve the current version of the application.
   * @returns any Successful Response
   * @throws ApiError
   */
  public static getAppVersionAppVersionGet(): CancelablePromise<any> {
    return __request(OpenAPI, {
      method: 'GET',
      url: '/app_version',
      errors: {
        422: `Validation Error`
      }
    });
  }
}
