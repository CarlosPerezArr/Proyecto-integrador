'use client';

import React from 'react';
import PageCard from 'app/components/PageCard';

// TODO - enable text box to append messages to conversation
const Reports: React.FC = () => {
  return (
    <div>
      <div>
        <PageCard>
          <div className="flex flex-row p-2 w-full h-svh">TODO: reports page</div>
        </PageCard>
      </div>
    </div>
  );
};

export default Reports;
