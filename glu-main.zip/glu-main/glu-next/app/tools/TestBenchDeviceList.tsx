import React from 'react';
import { keepPreviousData, useQuery } from '@tanstack/react-query';
import { LabBenchService } from '@/app/client';
import TestBenchDeviceTable from './TestBenchDeviceTable';
import { PlusIcon } from '@heroicons/react/24/solid';
import LoadingSpinner from '../components/LoadingSpinner';

const TestBenchDeviceList: React.FC = () => {
  const { isPending, isError, data, isFetching, isPlaceholderData } = useQuery({
    queryKey: ['TestBenchDevices'],
    queryFn: () => LabBenchService.listTestBenchDevicesLabBenchDevicesGet(),
    placeholderData: keepPreviousData,
    staleTime: Infinity
  });

  return (
    <div className="w-full p-8">
      {isError && (
        <div className="mt-8 w-full flex justify-center">
          Error loading testing tools, please try again later.
        </div>
      )}

      {isPending && <LoadingSpinner title="Loading testing tools..." />}

      {data && data.length === 0 && (
        <div className="mt-8 w-full flex justify-center">No testing tools found.</div>
      )}

      {data && data.length > 0 && (
        <div>
          <a className="btn-sm btn btn-primary" href="/tools/new" key="1">
            <PlusIcon className="mb-0.5 size-4" />
            New Testing Tool
          </a>
          <TestBenchDeviceTable
            tools={data}
            isFetching={isFetching}
            isPlaceholderData={isPlaceholderData}
          />
        </div>
      )}
    </div>
  );
};

export default TestBenchDeviceList;
