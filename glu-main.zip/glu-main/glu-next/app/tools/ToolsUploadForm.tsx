'use client';

import React, { useState, useEffect } from 'react';
import WebSocketComponent from '@/app/components/WebSocketComponent';
import GenericProgressBar from '@/app/components/ProgressBarGeneric';
import FileUploadForm from '../components/FileUploadForm';
import TestBenchDeviceTable from './TestBenchDeviceTable';
import { TestBenchDeviceRead } from '@/app/client';

interface ToolListUploaderProps {
  onSuccess?: (toolListId: number) => void;
  onError?: () => void;
}

/**
 * A modernized tool list uploader with drag-and-drop support and title field
 */
export default function ToolListUploader({
  onSuccess,
  onError
}: ToolListUploaderProps): JSX.Element {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [toolListFile, setToolListFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [tools, setTools] = useState<TestBenchDeviceRead[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [connectWebSocket, setConnectWebSocket] = useState(false);
  const [currentPage, setCurrentPage] = useState(0);
  const [numPages, setNumPages] = useState(0);
  const [parseComplete, setParseComplete] = useState(false);
  const [title, setTitle] = useState<string>('');

  // Auto-populate title when file is selected
  useEffect(() => {
    if (selectedFile && !title) {
      const currentDate = new Date().toISOString().split('T')[0];
      const fileName = selectedFile.name.replace(/\.[^/.]+$/, ''); // Remove file extension
      setTitle(`${fileName} - ${currentDate}`);
    }
  }, [selectedFile, title]);

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    setError(null);
  };

  const handleUpload = () => {
    if (!selectedFile) {
      setError('Please select a file to upload.');
      return;
    }

    if (!title.trim()) {
      setError('Please enter a title for the test bench.');
      return;
    }

    setToolListFile(selectedFile);
    setLoading(true);
    setError(null);
    setConnectWebSocket(true);
  };

  const handleWebSocketOpen = async () => {
    if (!toolListFile || !(window as any).websocketInstance) {
      setError('WebSocket or file is missing.');
      setLoading(false);
      return;
    }

    try {
      const metadata = {
        type: 'metadata',
        device: {
          filename: toolListFile.name,
          title: title.trim()
        }
      };
      (window as any).websocketInstance.send(JSON.stringify(metadata));
      await new Promise((resolve) => setTimeout(resolve, 100));
      const buffer = await toolListFile.arrayBuffer();
      (window as any).websocketInstance.send(buffer);
    } catch (err) {
      console.error('Error uploading file:', err);
      setError('File upload failed.');
    }
  };

  const handleWebSocketMessage = (message: any) => {
    if (!message || !message.payload) return;

    if (message.is_error) {
      setError('An error occurred during processing.');
      return;
    }
    const payload = message.payload;

    switch (message.type) {
      case 'status_update': {
        if (payload.page_count && numPages !== payload.page_count) {
          setNumPages(payload.page_count);
        }
        setCurrentPage(payload.page_number);
        break;
      }
      case 'parse_complete': {
        setParseComplete(true);
        break;
      }
      case 'specifics_complete': {
        const toolsList = (payload.tools || []).map((tool: any) => ({
          id: tool.id,
          name: tool.name,
          category: tool.category || 'unknown',
          manufacturer: tool.manufacturer || null,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString()
        }));

        onSuccess?.(payload.bench_id);
        setTools(toolsList);
        setLoading(false);
        setConnectWebSocket(false);
        break;
      }
    }
  };

  const handleWebSocketError = () => {
    setError('WebSocket connection failed.');
    setLoading(false);
    onError?.();
  };

  const handleWebSocketComplete = () => {
    setLoading(false);
    setConnectWebSocket(false);
  };

  const allowedExtensions = ['.xlsx', '.xls', '.csv', '.doc', '.docx', '.md', '.pdf'];

  return (
    <div className="space-y-4">
      {connectWebSocket && (
        <WebSocketComponent
          url={`${process.env.NEXT_PUBLIC_API_WEBSOCKET_URL}/lab_bench_ws/upload`}
          onMessage={handleWebSocketMessage}
          onError={handleWebSocketError}
          onComplete={handleWebSocketComplete}
          onOpen={handleWebSocketOpen}
          connect={connectWebSocket}
        />
      )}

      {!loading && !tools && (
        <>
          <div className="mb-4">
            <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
              Test Bench Title
            </label>
            <input
              type="text"
              id="title"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              placeholder="Enter test bench title"
            />
          </div>
          <FileUploadForm
            onFileSelect={handleFileSelect}
            onUpload={handleUpload}
            isLoading={loading}
            allowedExtensions={allowedExtensions}
            maxSizeInMB={10}
          />
        </>
      )}

      {loading && !parseComplete && (
        <div className="mt-4">
          <GenericProgressBar
            title="Uploading and processing file..."
            current={currentPage}
            total={numPages}
          />
        </div>
      )}

      {loading && parseComplete && (
        <div className="mt-4">
          <GenericProgressBar
            title="Loading Tool Specifics..."
            current={currentPage}
            total={numPages}
          />
        </div>
      )}

      {tools && (
        <div>
          <h2 className="text-lg font-semibold mb-4">{title}</h2>
          <TestBenchDeviceTable tools={tools} isFetching={false} isPlaceholderData={false} />
        </div>
      )}

      {error && <div className="text-red-500 text-sm mt-2">{error}</div>}
    </div>
  );
}
