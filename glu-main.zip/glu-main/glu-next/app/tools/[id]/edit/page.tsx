'use client';

import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import PageCard from 'app/components/PageCard';
import ConfirmDialog from 'app/components/ConfirmDialog';
import TestBenchForm from '../../TestBenchForm';

import { TestBenchResponse } from '@/app/client';
import { LabBenchService } from '@/app/client';
import LoadingSpinner from '@/app/components/LoadingSpinner';

const Page: React.FC<{ params: Promise<{ id: number }> }> = ({ params }) => {
  const [deleteError, setDeleteError] = useState<boolean>(false);
  const [confirmOpen, setConfirmOpen] = useState<boolean>(false);

  const router = useRouter();
  const resolvedParams = React.use(params);

  const {
    data: bench,
    isLoading,
    error
  } = useQuery({
    queryKey: ['TestBench', resolvedParams.id],
    queryFn: () =>
      LabBenchService.viewTestBenchLabBenchTestBenchesBenchIdGet({ benchId: resolvedParams.id }),
    staleTime: Infinity,
    refetchOnWindowFocus: false
  });

  const handleSuccess = () => {
    router.back();
    router.refresh();
  };

  const deleteBench = async () => {
    try {
      await LabBenchService.deleteTestBenchLabBenchTestBenchesBenchIdDelete({
        benchId: resolvedParams.id
      });
      router.push('/tools');
    } catch (error) {
      setDeleteError(true);
      setTimeout(() => {
        setDeleteError(false);
      }, 3000);
    }
  };

  if (isLoading) {
    return <LoadingSpinner title="Loading bench details..." />;
  }

  if (error) {
    return (
      <div className="text-center p-8">
        <p className="text-red-500">Error loading bench details. Please try again later.</p>
      </div>
    );
  }

  return (
    <div>
      {bench && (
        <PageCard
          title="Edit Test Bench"
          headerNodes={[
            <a
              className="btn-sm btn"
              onClick={() => router.back()}
              style={{ cursor: 'pointer' }}
              key="0"
            >
              back
            </a>,
            <div key="1">
              <a
                className="btn-sm btn btn-error ml-4"
                aria-label="delete"
                onClick={() => setConfirmOpen(true)}
              >
                delete test bench
              </a>
              <ConfirmDialog
                title="Delete Test Bench?"
                open={confirmOpen}
                onClose={() => setConfirmOpen(false)}
                onConfirm={deleteBench}
              >
                Are you sure you want to delete this test bench?
              </ConfirmDialog>
              {deleteError && (
                <p className="text-right mr-2">
                  <small className="text-red-500">Error deleting bench.</small>
                </p>
              )}
            </div>
          ]}
        >
          <TestBenchForm bench={bench} onSuccess={handleSuccess} />
        </PageCard>
      )}
    </div>
  );
};

export default Page;
