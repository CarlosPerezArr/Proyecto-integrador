'use client';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';

import PageCard from 'app/components/PageCard';
import TestBenchDeviceForm from '@/app/tools/TestBenchDeviceForm';

import { TestBenchDeviceRead } from '@/app/client';

interface PageProps {
  params: Promise<{
    id: string;
  }>;
}

const Page: React.FC<PageProps> = ({ params }) => {
  const router = useRouter();
  const [_device, setDevice] = useState<TestBenchDeviceRead | null>(null);

  // Unwrap the params using React.use()
  const resolvedParams = React.use(params);
  const benchId = parseInt(resolvedParams.id);

  const handleCreateSuccess = (newDevice: TestBenchDeviceRead) => {
    console.log('Device created:', newDevice);
    setDevice(newDevice);
    router.push(`/tools/${resolvedParams.id}`);
  };

  return (
    <div>
      <PageCard
        title="New Testing Tool"
        subTitle="Add a new testing tool to the lab bench."
        headerNodes={[]}
      >
        <div className="mt-12">
          <TestBenchDeviceForm benchId={benchId} onSuccess={handleCreateSuccess} />
        </div>
      </PageCard>
    </div>
  );
};

export default Page;
