'use client';

import { useQuery } from '@tanstack/react-query';
import React from 'react';
import { LabBenchService } from '@/app/client';
import PageCard from '@/app/components/PageCard';
import TestBenchDeviceTable from '../TestBenchDeviceTable';
import LoadingSpinner from '@/app/components/LoadingSpinner';
import { AddToolButton, EditBenchButton } from '../BenchesButtons';

const Page: React.FC<{ params: Promise<{ id: string }> }> = ({ params }) => {
  const resolvedParams = React.use(params);
  const benchId = parseInt(resolvedParams.id, 10);

  const {
    data: testBenchData,
    isLoading,
    isError,
    isFetching
  } = useQuery({
    queryKey: ['TestBench', benchId],
    queryFn: () =>
      LabBenchService.viewTestBenchLabBenchTestBenchesBenchIdGet({
        benchId: benchId
      }),
    staleTime: Infinity,
    refetchOnWindowFocus: false
  });

  return (
    <div>
      <PageCard
        title={testBenchData?.identifier || 'Loading Tool Collection...'}
        headerNodes={
          testBenchData
            ? [
                <EditBenchButton benchId={testBenchData?.id as number} key={1} />,
                <AddToolButton benchId={testBenchData?.id as number} key={2} />
              ]
            : []
        }
      >
        <div className="flex flex-col w-full m-4">
          {isLoading && <LoadingSpinner title="Loading Tool Collection..." />}

          {isError && (
            <div className="text-error">
              Error loading test bench details, please try again later.
            </div>
          )}

          {testBenchData && (
            <>
              <div className="mt-4">
                <TestBenchDeviceTable
                  tools={testBenchData.test_bench_devices || []}
                  isFetching={isFetching}
                  isPlaceholderData={false}
                />
              </div>
            </>
          )}
        </div>
      </PageCard>
    </div>
  );
};

export default Page;
