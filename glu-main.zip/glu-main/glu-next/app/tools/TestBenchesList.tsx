import React, { useEffect, useState } from 'react';
import { useQueryClient, useQuery } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import Image from 'next/image';
import { TrashIcon } from '@heroicons/react/24/solid';

import DateComponent from '@/app/components/Date';
import Spinner from '@/app/components/Spinner';
import ConfirmDialog from '@/app/components/ConfirmDialog';

import { TestBenchReadWithDeviceInfo, LabBenchService } from '@/app/client';

interface TestBenchesListProps {
  onLoaded?: (testBenches: TestBenchReadWithDeviceInfo[]) => void;
  onClick?: (testBench: TestBenchReadWithDeviceInfo) => void;
  onDeleted?: (testBench: TestBenchReadWithDeviceInfo) => void;
  onError?: (error: any) => void;
}

const TestBenchesList: React.FC<TestBenchesListProps> = ({
  onLoaded,
  onClick,
  onDeleted,
  onError
}) => {
  const router = useRouter();
  const [confirmOpen, setConfirmOpen] = useState<boolean>(false);
  const [testBenchToDelete, setTestBenchToDelete] = useState<TestBenchReadWithDeviceInfo | null>(
    null
  );
  const [deleteInProgress, setDeleteInProgress] = useState<boolean>(false);
  const [animatingRows, setAnimatingRows] = useState<Set<string>>(new Set());

  const queryClient = useQueryClient();
  const testBenchesQueryKey = ['testBenches'];

  const { data, isFetching, isLoading, isError, isPending, error } = useQuery({
    queryKey: testBenchesQueryKey,
    queryFn: () => LabBenchService.listTestBenchesLabBenchTestBenchesGet({}),
    staleTime: Infinity
  });

  useEffect(() => {
    if (data && onLoaded) {
      onLoaded(data);
    }
  }, [data, onLoaded]);

  function deleteTestBench() {
    if (!testBenchToDelete) return;
    setDeleteInProgress(true);

    setAnimatingRows((prev) => new Set(prev).add(testBenchToDelete.id + ''));

    setTimeout(() => {
      LabBenchService.deleteTestBenchLabBenchTestBenchesBenchIdDelete({
        benchId: testBenchToDelete.id
      })
        .then(() => {
          queryClient.invalidateQueries({ queryKey: testBenchesQueryKey });
          if (onDeleted) {
            onDeleted(testBenchToDelete);
          }
        })
        .catch((error) => {
          if (onError) {
            onError(error);
          }
          setAnimatingRows((prev) => {
            const next = new Set(prev);
            next.delete(testBenchToDelete.id + '');
            return next;
          });
        })
        .finally(() => {
          setDeleteInProgress(false);
          setTestBenchToDelete(null);
        });
    }, 300);
  }

  const handleRowClick = (bench: TestBenchReadWithDeviceInfo) => {
    if (onClick) {
      onClick(bench);
    }
    router.push(`/tools/${bench.id}/`);
  };

  useEffect(() => {
    if (error && onError) {
      onError(error);
    }
  }, [error, onError]);

  if (isError) {
    return <h2>{error.message}</h2>;
  }

  return (
    <div
      className={`${
        isFetching || deleteInProgress ? 'opacity-50 pointer-events-none' : ''
      } relative w-full mt-4`}
    >
      {isLoading && (
        <div className="w-full flex justify-center">
          <Spinner className="mt-8">Loading tool collections...</Spinner>
        </div>
      )}
      {((!isLoading && isFetching) || deleteInProgress) && (
        <div className="absolute h-full w-full flex justify-center items-center">
          <Spinner className="mt-4" />
        </div>
      )}
      {!isPending && data && data.length > 0 && (
        <>
          <div className="overflow-hidden">
            <table className="w-full table-auto">
              <thead>
                <tr className="border-b border-white font-semibold text-left">
                  <th className="w-full pr-2">NAME</th>
                  <th className="text-right pr-16">LAST UPDATED</th>
                  <th className="whitespace-nowrap text-right"></th>
                </tr>
              </thead>
              <tbody>
                {data.toReversed().map((bench) => (
                  <tr
                    key={bench.id}
                    className={`
                      group cursor-pointer hover:bg-black hover:text-primary border-b border-white
                      transition-all duration-300
                      ${animatingRows.has(bench.id + '') ? 'opacity-0 translate-x-full' : ''}
                    `}
                    onClick={() => handleRowClick(bench)}
                  >
                    <td className="py-4 pr-2 flex flex-row">
                      <Image
                        className="mr-2"
                        src="/icon-folder.svg"
                        alt="projects"
                        width="20"
                        height="20"
                      />
                      {bench.identifier}
                    </td>
                    <td className="text-right whitespace-nowrap pr-16">
                      {bench.updated_at ? (
                        <DateComponent dateString={bench.updated_at as string} />
                      ) : (
                        <DateComponent dateString={bench.created_at as string} />
                      )}
                    </td>
                    <td className="block w-6 text-right text-xs whitespace-nowrap">
                      <a
                        className="hidden group-hover:flex hover:text-error align-center w-5 h-5 text-base-content/75"
                        aria-label="delete"
                        onClick={(e) => {
                          setConfirmOpen(true);
                          setTestBenchToDelete(bench);
                          e.stopPropagation();
                        }}
                      >
                        <TrashIcon />
                      </a>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
      {!isLoading && !isPending && data && data.length === 0 && (
        <p>No previous tool collection versions.</p>
      )}
      <ConfirmDialog
        title="Delete Test Bench?"
        open={confirmOpen}
        onClose={() => {
          setConfirmOpen(false);
          setTestBenchToDelete(null);
        }}
        onConfirm={deleteTestBench}
      >
        Are you sure you want to delete this tool collection?
      </ConfirmDialog>
    </div>
  );
};

export default TestBenchesList;
