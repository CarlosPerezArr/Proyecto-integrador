import React, { useState, FormEvent } from 'react';
import { TestBenchResponse } from '@/app/client';
import { LabBenchService } from '@/app/client';

interface TestBenchFormProps {
  bench?: TestBenchResponse;
  onSuccess: (bench: TestBenchResponse) => void;
}

const TestBenchForm: React.FC<TestBenchFormProps> = ({ bench, onSuccess }) => {
  const [identifier, setIdentifier] = useState(bench?.identifier || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(false);

    const testBench = { identifier } as TestBenchResponse;

    try {
      let response;

      if (bench) {
        // Update existing bench
        testBench.id = bench.id;
        response = await LabBenchService.updateTestBenchLabBenchTestBenchesBenchIdPut({
          benchId: testBench.id as number,
          requestBody: testBench
        });
      } else {
        // Create new bench
        response = await LabBenchService.createTestBenchLabBenchTestBenchesPost({
          requestBody: testBench
        });
      }

      setLoading(false);
      onSuccess(response as TestBenchResponse);
    } catch (err) {
      setError(true);
      setLoading(false);
      setTimeout(() => setError(false), 5000);
    }
  };

  const isCreating = !bench;
  const buttonText = loading
    ? isCreating
      ? 'Creating...'
      : 'Updating...'
    : isCreating
      ? 'Create'
      : 'Update';
  const errorText = isCreating ? 'Error creating test bench' : 'Error updating test bench';

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <div className="flex flex-col">
        <label htmlFor="identifier" className="mb-2">
          Identifier:
        </label>
        <input
          type="text"
          id="identifier"
          value={identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          className="input input-bordered w-1/2"
          required
        />
      </div>

      <div className="flex mt-6 w-2/3">
        <div className="w-1/2">{error && <p className="text-red-500">{errorText}</p>}</div>
        <div className="flex justify-end w-1/2">
          <button type="submit" className="btn btn-sm btn-primary" disabled={loading}>
            {buttonText}
          </button>
        </div>
      </div>
    </form>
  );
};

export default TestBenchForm;
