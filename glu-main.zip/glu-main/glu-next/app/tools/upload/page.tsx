'use client';

import { useState } from 'react';
import PageCard from '@/app/components/PageCard';
import Alert from '@/app/components/Alert';
import ToolsUploadForm from '../ToolsUploadForm';
import { AlertObject } from '@/app/lib/definitions';

/**
 * Page component for uploading tool lists
 * Provides a form for uploading documents containing tool information
 * @returns JSX.Element The rendered page component
 */
export default function Page(): JSX.Element {
  // State for managing alerts
  const [alert, setAlert] = useState<AlertObject | null>(null);

  /**
   * Handler for successful upload
   */
  const handleSuccess = () => {
    setAlert({
      type: 'success',
      message: 'Tool list uploaded successfully',
      onClick: () => setAlert(null) // Add dismiss handler
    });
  };

  /**
   * Handler for upload errors
   */
  const handleError = () => {
    setAlert({
      type: 'error',
      message: 'Failed to upload tool collection',
      onClick: () => setAlert(null) // Add dismiss handler
    });
  };

  return (
    <PageCard
      title="Upload Tools Collection"
      subTitle="Upload a document containing test bench tools information"
      alert={alert}
    >
      <div className="mt-4">
        <ToolsUploadForm onSuccess={handleSuccess} onError={handleError} />
      </div>
    </PageCard>
  );
}
