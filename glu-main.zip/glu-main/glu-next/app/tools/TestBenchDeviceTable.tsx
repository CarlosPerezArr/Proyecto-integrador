import React, { useState, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import DateComponent from '@/app/components/Date';
import { TestBenchDevice, TestBenchDeviceRead } from '@/app/client';
import { MagnifyingGlassIcon, ChevronUpIcon, ChevronDownIcon } from '@heroicons/react/24/outline';

interface TestBenchDeviceTableProps {
  tools: (TestBenchDeviceRead | TestBenchDevice)[];
  isFetching: boolean;
  isPlaceholderData: boolean;
}

const TestBenchDeviceTable: React.FC<TestBenchDeviceTableProps> = ({
  tools,
  isFetching,
  isPlaceholderData
}) => {
  const router = useRouter();
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [sortConfig, setSortConfig] = useState<{
    key: string;
    direction: 'asc' | 'desc';
  }>({ key: 'category', direction: 'asc' });

  // Get all unique categories
  const categories = useMemo(() => {
    const uniqueCategories = Array.from(new Set(tools.map((tool) => tool.category)));
    return ['All', ...uniqueCategories.sort()];
  }, [tools]);

  // Filter tools based on search and category
  const filteredTools = useMemo(() => {
    let filtered = tools;

    // Apply category filter
    if (selectedCategory && selectedCategory !== 'All') {
      filtered = filtered.filter((tool) => tool.category === selectedCategory);
    }

    // Apply search filter
    if (searchTerm) {
      const searchLower = searchTerm.toLowerCase();
      filtered = filtered.filter(
        (tool) =>
          tool.name.toLowerCase().includes(searchLower) ||
          tool.manufacturer?.toLowerCase().includes(searchLower)
      );
    }

    // Apply sorting
    if (sortConfig.key) {
      filtered.sort((a, b) => {
        let aValue = a[sortConfig.key as keyof TestBenchDeviceRead];
        let bValue = b[sortConfig.key as keyof TestBenchDeviceRead];

        if (sortConfig.key === 'date') {
          aValue = a.updated_at || a.created_at;
          bValue = b.updated_at || b.created_at;
        }

        // Handle cases where either value is null
        if (aValue === null && bValue === null) return 0;
        if (aValue === null) return sortConfig.direction === 'asc' ? 1 : -1;
        if (bValue === null) return sortConfig.direction === 'asc' ? -1 : 1;

        // If we get here, both values are non-null
        if (aValue! < bValue!) return sortConfig.direction === 'asc' ? -1 : 1;
        if (aValue! > bValue!) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
      });
    }

    return filtered;
  }, [tools, searchTerm, selectedCategory, sortConfig]);

  const handleSort = (key: string) => {
    setSortConfig((current) => ({
      key,
      direction: current.key === key && current.direction === 'asc' ? 'desc' : 'asc'
    }));
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-4 items-center">
        {/* Search Input */}
        <div className="relative flex-grow max-w-md">
          <MagnifyingGlassIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 text-base-content/50 h-4 w-4" />
          <input
            type="text"
            placeholder="Search tools..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="input input-bordered w-full pl-10"
          />
        </div>

        {/* Category Filter */}
        <select
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          className="select select-bordered"
        >
          {categories.map(
            (category) =>
              category && (
                <option key={category} value={category}>
                  {category ?? 'All Categories'}
                </option>
              )
          )}
        </select>
      </div>

      <table
        className={`table-fixed w-full ${
          isFetching || isPlaceholderData ? 'opacity-50 pointer-events-none' : ''
        }`}
      >
        <thead>
          <tr>
            <th
              className="w-1/4 border-b border-base-content/10 font-medium p-2 pt-0 pb-3 text-base-content/50 text-left cursor-pointer"
              onClick={() => handleSort('category')}
            >
              Category
              {sortConfig.key === 'category' &&
                (sortConfig.direction === 'asc' ? (
                  <ChevronUpIcon className="inline ml-1 h-4 w-4" />
                ) : (
                  <ChevronDownIcon className="inline ml-1 h-4 w-4" />
                ))}
            </th>
            <th
              className="w-2/4 border-b border-base-content/10 font-medium p-2 pt-0 pb-3 text-base-content/50 text-left cursor-pointer"
              onClick={() => handleSort('manufacturer')}
            >
              Tool
              {sortConfig.key === 'manufacturer' &&
                (sortConfig.direction === 'asc' ? (
                  <ChevronUpIcon className="inline ml-1 h-4 w-4" />
                ) : (
                  <ChevronDownIcon className="inline ml-1 h-4 w-4" />
                ))}
            </th>
            <th
              className="w-1/4 border-b border-base-content/10 font-medium p-2 pt-0 pb-3 text-base-content/50 text-right cursor-pointer"
              onClick={() => handleSort('date')}
            >
              Last Edited
              {sortConfig.key === 'date' &&
                (sortConfig.direction === 'asc' ? (
                  <ChevronUpIcon className="inline ml-1 h-4 w-4" />
                ) : (
                  <ChevronDownIcon className="inline ml-1 h-4 w-4" />
                ))}
            </th>
          </tr>
        </thead>
        <tbody>
          {filteredTools.map((device: TestBenchDeviceRead | TestBenchDevice) => (
            <tr
              key={device.id}
              className="cursor-pointer hover:bg-base-content/10 hover:text-primary border-b border-base-content/10"
              onClick={() => router.push(`/tools/tools/${device.id}/edit`)}
            >
              <td className="p-2">{device.category}</td>
              <td className="p-2">
                <b>{device.manufacturer}</b>
                <br />
                {device.name}
              </td>
              <td className="text-base-content/75 p-2 text-right text-xs whitespace-nowrap">
                <DateComponent dateString={(device.updated_at || device.created_at) as string} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TestBenchDeviceTable;
