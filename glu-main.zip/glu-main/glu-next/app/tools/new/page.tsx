'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import PageCard from 'app/components/PageCard';
import TestBenchForm from '../TestBenchForm';
import { TestBenchResponse } from '@/app/client';

const CreateBenchPage: React.FC = () => {
  const router = useRouter();

  const handleSuccess = (bench: TestBenchResponse) => {
    router.push('/tools');
  };

  return (
    <div>
      <PageCard
        title="Create Test Collection"
        headerNodes={[
          <a
            className="btn-sm btn"
            onClick={() => {
              router.back();
              router.refresh();
            }}
            style={{ cursor: 'pointer' }}
            key="0"
          >
            back
          </a>
        ]}
      >
        <TestBenchForm onSuccess={handleSuccess} />
      </PageCard>
    </div>
  );
};

export default CreateBenchPage;
