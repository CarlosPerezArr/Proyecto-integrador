'use client';

import React from 'react';
import PageCard from 'app/components/PageCard';
import { UploadToolsButton, CreateBenchButton } from './BenchesButtons';
import TestBenchesList from './TestBenchDeviceList';

const Tools: React.FC = () => {
  return (
    <div>
      <div>
        <PageCard
          title="Tools"
          headerNodes={[<CreateBenchButton key="1" />, <UploadToolsButton key="2" />]}
        >
          <TestBenchesList />
        </PageCard>
      </div>
    </div>
  );
};

export default Tools;
