'use client';

import React, { useState, use } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import PageCard from 'app/components/PageCard';
import ConfirmDialog from 'app/components/ConfirmDialog';
import TestBenchDeviceForm from '@/app/tools/TestBenchDeviceForm';
import LoadingSpinner from '@/app/components/LoadingSpinner';

import { TestBenchDeviceRead } from '@/app/client';
import { LabBenchService } from '@/app/client';

const Page: React.FC<{ params: Promise<{ id: number }> }> = (props) => {
  const params = use(props.params);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const [deleteError, setDeleteError] = useState<boolean>(false);
  const [confirmOpen, setConfirmOpen] = useState<boolean>(false);

  const router = useRouter();

  const { data: device, isLoading } = useQuery({
    queryKey: ['TestBenchDevice', params.id],
    queryFn: () =>
      LabBenchService.viewTestBenchDeviceLabBenchDevicesDeviceIdGet({ deviceId: params.id }),
    staleTime: Infinity,
    refetchOnWindowFocus: false
  });

  const handleSuccess = (device: TestBenchDeviceRead) => {
    setIsSaving(false);
    router.back();
  };

  const handleSaveStart = () => {
    setIsSaving(true);
  };

  const handleSaveError = () => {
    setIsSaving(false);
  };

  const deleteTool = () => {
    setIsSaving(true);
    LabBenchService.deleteTestBenchDeviceLabBenchDevicesDeviceIdDelete({
      deviceId: params.id
    })
      .then(() => {
        router.push(`/tools`);
      })
      .catch(() => {
        setDeleteError(true);
        setIsSaving(false);
        setTimeout(() => {
          setDeleteError(false);
        }, 3000);
      });
  };

  if (isLoading) {
    return <LoadingSpinner title="Loading device details..." />;
  }

  if (isSaving) {
    return <LoadingSpinner title="Saving changes..." />;
  }

  return (
    <div>
      {device && (
        <PageCard
          title="Edit Testing Tool"
          headerNodes={[
            <a
              className="btn-sm btn"
              onClick={() => {
                router.back();
                router.refresh();
              }}
              style={{ cursor: 'pointer' }}
              key="0"
            >
              back
            </a>,
            <div key="1">
              <button
                className="btn-sm btn btn-error ml-4"
                aria-label="delete"
                onClick={() => setConfirmOpen(true)}
                disabled={isSaving}
              >
                delete testing tool
              </button>
              <ConfirmDialog
                title="Delete Testing Tool?"
                open={confirmOpen}
                onClose={() => setConfirmOpen(false)}
                onConfirm={deleteTool}
              >
                Are you sure you want to delete this testing tool?
              </ConfirmDialog>
              {deleteError && (
                <p className="text-right mr-2">
                  <small className="text-red-500">Error deleting device.</small>
                </p>
              )}
            </div>
          ]}
        >
          <TestBenchDeviceForm
            device={device}
            onSuccess={handleSuccess}
            onSaveStart={handleSaveStart}
            onSaveError={handleSaveError}
            disabled={isSaving}
          />
        </PageCard>
      )}
    </div>
  );
};

export default Page;
