'use client';

import { useQuery } from '@tanstack/react-query';
import React, { use } from 'react';
import { LabBenchService } from '@/app/client';
import PageCard from '@/app/components/PageCard';
import LoadingSpinner from '@/app/components/LoadingSpinner';

const Page: React.FC<{ params: Promise<{ id: number }> }> = (props) => {
  const params = use(props.params);
  const {
    data: device,
    isLoading: deviceIsLoading,
    isError: deviceIsError
  } = useQuery({
    queryKey: ['TestBenchDevice', params.id],
    queryFn: () =>
      LabBenchService.viewTestBenchDeviceLabBenchDevicesDeviceIdGet({ deviceId: params.id }),
    staleTime: Infinity,
    refetchOnWindowFocus: false
  });

  return (
    <div>
      <PageCard
        title="Testing Tools"
        headerNodes={
          device
            ? [
                <a className="btn-sm btn btn-primary" href={`/tools/${device?.id}/edit`} key="1">
                  Edit Testing Tool
                </a>
              ]
            : []
        }
      >
        <div className="flex flex-col w-full m-4">
          {deviceIsLoading && <LoadingSpinner title="Loading testing tool..." />}
          {deviceIsError && <p>Error loading testing tool, please try again later.</p>}
          {device && (
            <div className="mb-2">
              <h1 className="text-xl font-bold">{device.name}</h1>
              <p className="mb-4">
                <small className="text-gray-400">
                  {device.manufacturer}, {device.category || 'unknown'}
                </small>
              </p>
              <p>{device.description}</p>
            </div>
          )}
        </div>
      </PageCard>
    </div>
  );
};

export default Page;
