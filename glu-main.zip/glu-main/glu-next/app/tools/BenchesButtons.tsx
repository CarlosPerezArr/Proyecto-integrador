'use client';

import Link from 'next/link';
import { PlusIcon } from '@heroicons/react/24/solid';

interface BaseButtonProps {
  href: string;
  icon?: JSX.Element;
  children: React.ReactNode;
}

function BaseButton({
  href,
  icon = <PlusIcon className="-ml-1 mr-2 h-5 w-5" />,
  children
}: BaseButtonProps): JSX.Element {
  return (
    <Link
      href={href}
      className="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-primary rounded-md hover:bg-primary-focus focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary ml-4"
    >
      {icon}
      {children}
    </Link>
  );
}

export function UploadToolsButton(): JSX.Element {
  return <BaseButton href="/tools/upload">Upload Collection</BaseButton>;
}

export function CreateBenchButton(): JSX.Element {
  return <BaseButton href="/tools/new">Create Collection</BaseButton>;
}

interface WithBenchIdProps {
  benchId: number | string;
}

export function AddToolButton({ benchId }: WithBenchIdProps): JSX.Element {
  return <BaseButton href={`/tools/${benchId}/tools/new`}>Add Tool</BaseButton>;
}

export function EditBenchButton({ benchId }: WithBenchIdProps): JSX.Element {
  return <BaseButton href={`/tools/${benchId}/edit`}>Edit Collection</BaseButton>;
}
