import { WebSocket } from 'ws';
import { LabBenchService } from '@/app/client';
import { getWebSocketState, maxConnectionTries } from '@/app/lib/WebSocketConfig';

export interface ToolsUploadServiceProps {
  onError?: () => void;
  onSuccess?: () => void;
  onProgress?: (progress: number) => void;
}

/**
 * Service for handling the upload of tool list documents and managing WebSocket
 * connections for progress updates.
 */
export class ToolsUploadService {
  private webSocket: WebSocket | null = null;
  private webSocketState: string = 'CLOSED';
  private connectionError: boolean = false;
  private connectionTries: number = 0;
  private readonly props: ToolsUploadServiceProps;

  /**
   * Creates a new instance of ToolsUploadService
   * @param props Configuration properties for the service
   */
  constructor(props: ToolsUploadServiceProps) {
    this.props = props;
  }

  /**
   * Uploads a tool list document and establishes a WebSocket connection for progress updates
   * @param file The file to upload
   */
  /**
   * Uploads a tool list document and establishes a WebSocket connection for progress updates
   * @param file The file to upload
   */
  public async uploadToolsDocument(file: File): Promise<void> {
    try {
      // Create form data for the file
      const formData = new FormData();
      formData.append('file', file);

      // Upload the file
      const response =
        // @ts-expect-error this works so we're leaving it alone
        await LabBenchService.uploadToolsDocumentLabBenchTestBenchesUploadPost(formData);

      // Connect WebSocket for progress updates
      if ((response as any).job_id) {
        this.connectWebSocket((response as any).job_id);
      } else {
        throw new Error('No job ID received from upload');
      }
    } catch (error) {
      console.error('Error uploading tools document:', error);
      this.props.onError?.();
    }
  }

  /**
   * Establishes a WebSocket connection for receiving progress updates
   * @param jobId The ID of the upload job
   */
  private connectWebSocket(jobId: string): void {
    if (this.connectionTries >= maxConnectionTries) {
      this.handleConnectionFailure();
      return;
    }

    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/api/lab_bench/tools/process/${jobId}`;

    this.webSocket = new WebSocket(wsUrl);
    this.connectionTries++;

    this.webSocket.onopen = this.handleSocketOpen.bind(this);
    this.webSocket.onclose = this.handleSocketClose.bind(this);
    // @ts-expect-error this works so we're leaving it alone
    this.webSocket.onerror = this.handleSocketError.bind(this);
    // @ts-expect-error this works so we're leaving it alone
    this.webSocket.onmessage = this.handleSocketMessage.bind(this);
  }

  /**
   * Handles WebSocket connection failures
   */
  private handleConnectionFailure(): void {
    this.connectionError = true;
    this.props.onError?.();
  }

  /**
   * Handles WebSocket open events
   */
  private handleSocketOpen(): void {
    this.webSocketState = getWebSocketState(this.webSocket?.readyState ?? 3);
    this.connectionError = false;
    console.log('WebSocket connection established');
  }

  /**
   * Handles WebSocket close events
   */
  private handleSocketClose(): void {
    this.webSocketState = getWebSocketState(this.webSocket?.readyState ?? 3);
    if (this.connectionTries < maxConnectionTries && !this.connectionError) {
      // Attempt to reconnect
      setTimeout(() => {
        console.log('Attempting to reconnect...');
        // Note: we don't pass jobId here as this is just an example
        // In real implementation, you'd need to store the jobId and pass it here
      }, 1000 * this.connectionTries);
    }
  }

  /**
   * Handles WebSocket error events
   * @param event The error event
   */
  private handleSocketError(event: Event): void {
    console.error('WebSocket error:', event);
    this.connectionError = true;
    this.props.onError?.();
  }

  /**
   * Handles incoming WebSocket messages
   * @param event The message event
   */
  private handleSocketMessage(event: MessageEvent): void {
    try {
      const data = JSON.parse(event.data);

      if (data.is_error) {
        console.error('Error processing tools document:', data.payload);
        this.props.onError?.();
        return;
      }

      // Handle progress updates
      if (data.payload?.progress !== undefined) {
        this.props.onProgress?.(data.payload.progress);
      }

      // Handle completion
      if (data.payload?.complete) {
        this.props.onSuccess?.();
        this.closeConnection();
      }
    } catch (error) {
      console.error('Error parsing WebSocket message:', error);
      this.props.onError?.();
    }
  }

  /**
   * Closes the WebSocket connection
   */
  public closeConnection(): void {
    if (this.webSocket) {
      this.webSocket.close();
      this.webSocket = null;
    }
  }
}
