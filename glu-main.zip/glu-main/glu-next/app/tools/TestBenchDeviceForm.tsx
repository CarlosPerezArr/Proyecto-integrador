import React, { useState, FormEvent } from 'react';
import { TestBenchDeviceCreate, TestBenchDeviceRead } from '@/app/client';
import { LabBenchService } from '@/app/client';

interface TestBenchDeviceFormProps {
  device?: TestBenchDeviceRead;
  onSuccess: (device: TestBenchDeviceRead) => void;
  onSaveStart?: () => void;
  onSaveError?: () => void;
  disabled?: boolean;
  benchId?: number;
}

const TestBenchDeviceForm: React.FC<TestBenchDeviceFormProps> = ({
  device,
  onSuccess,
  onSaveStart,
  onSaveError,
  disabled,
  benchId
}) => {
  const [name, setName] = useState(device?.name || '');
  const [manufacturer, setManufacturer] = useState(device?.manufacturer || '');
  const [description, setDescription] = useState(device?.description || '');
  const [category, setCategory] = useState(device?.category || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(false);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    onSaveStart?.();

    if (device) {
      const testBenchDevice = { name, manufacturer, description, category } as TestBenchDeviceRead;
      testBenchDevice.id = device.id;
      console.log(testBenchDevice);
      LabBenchService.updateTestBenchDeviceLabBenchDevicesDeviceIdPut({
        deviceId: testBenchDevice.id as number,
        requestBody: testBenchDevice
      })
        .then((res) => {
          setLoading(false);
          onSuccess(res as TestBenchDeviceRead);
        })
        .catch((_err) => {
          setError(true);
          setLoading(false);
          onSaveError?.();
          setTimeout(() => setError(false), 5000);
        });
    } else {
      LabBenchService.createTestBenchDeviceLabBenchDevicesPost({
        requestBody: { name, manufacturer, description, category } as TestBenchDeviceCreate
      })
        .then((res) => {
          if (typeof benchId === 'number' && benchId >= 1) {
            return LabBenchService.addTestBenchToDeviceLabBenchDevicesDeviceIdTestBenchesPost({
              deviceId: res.id!,
              requestBody: benchId
            }).then(() => res);
          }
          return res;
        })
        .then((res) => {
          setLoading(false);
          onSuccess(res as TestBenchDeviceRead);
        })
        .catch((_err) => {
          setError(true);
          setLoading(false);
          onSaveError?.();
          setTimeout(() => setError(false), 5000);
        });
    }
  };

  const isDisabled = disabled || loading;

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-4">
      <div className="flex flex-col">
        <label htmlFor="name" className="mb-2">
          Name:
        </label>
        <input
          type="text"
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="input input-bordered w-1/2"
          placeholder=""
          required
          disabled={isDisabled}
        />
      </div>

      <div className="flex flex-col">
        <label htmlFor="manufacturer" className="mb-2">
          Manufacturer:
        </label>
        <input
          type="text"
          id="manufacturer"
          value={manufacturer}
          onChange={(e) => setManufacturer(e.target.value)}
          className="input input-bordered w-1/2"
          placeholder=""
          required
          disabled={isDisabled}
        />
      </div>

      <div className="flex flex-col">
        <label htmlFor="category" className="mb-2">
          Category:
        </label>
        <input
          type="text"
          id="category"
          value={category}
          onChange={(e) => setCategory(e.target.value)}
          className="input input-bordered w-1/2"
          placeholder=""
          required
          disabled={isDisabled}
        />
      </div>

      <div className="flex flex-col">
        <label htmlFor="description" className="mb-2">
          Description:
        </label>
        <textarea
          id="description"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="textarea textarea-bordered h-48 w-2/3"
          placeholder=""
          required
          disabled={isDisabled}
        ></textarea>
      </div>

      <div className="flex mt-6 w-2/3">
        <div className="w-1/2">
          {error && <p className="text-red-500">Error {device ? 'updating' : 'creating'} device</p>}
        </div>
        <div className="flex justify-end w-1/2">
          <button type="submit" className="btn btn-sm btn-primary" disabled={isDisabled}>
            {loading ? (
              <span className="flex items-center gap-2">
                <span className="loading loading-spinner loading-sm"></span>
                {device ? 'Updating...' : 'Creating...'}
              </span>
            ) : device ? (
              'Update'
            ) : (
              'Create'
            )}
          </button>
        </div>
      </div>
    </form>
  );
};

export default TestBenchDeviceForm;
