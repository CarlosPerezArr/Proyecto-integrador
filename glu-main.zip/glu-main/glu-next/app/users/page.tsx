'use client';

import React from 'react';
import PageCard from 'app/components/PageCard';

const Users: React.FC = () => {
  return (
    <div>
      <div>
        <PageCard>
          <div className="flex flex-row p-2 w-full h-svh">TODO: users page</div>
        </PageCard>
      </div>
    </div>
  );
};

export default Users;
