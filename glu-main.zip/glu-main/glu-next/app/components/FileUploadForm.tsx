'use client';

import React, { useState, useRef, DragEvent } from 'react';
import { DocumentArrowUpIcon } from '@heroicons/react/24/outline';

interface FileUploadFormProps {
  onFileSelect: (file: File) => void;
  onUpload: () => void;
  isLoading?: boolean;
  allowedExtensions?: string[];
  maxSizeInMB?: number;
}

const DEFAULT_ALLOWED_EXTENSIONS = ['.xlsx', '.xls', '.csv', '.doc', '.docx', '.md', '.pdf'];
const DEFAULT_MAX_SIZE_MB = 10;

export default function FileUploadForm({
  onFileSelect,
  onUpload,
  isLoading = false,
  allowedExtensions = DEFAULT_ALLOWED_EXTENSIONS,
  maxSizeInMB = DEFAULT_MAX_SIZE_MB
}: FileUploadFormProps): JSX.Element {
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const validateFile = (file: File): boolean => {
    if (!allowedExtensions.some((ext) => file.name.toLowerCase().endsWith(ext))) {
      const allowedExtensionsMessage = allowedExtensions.join(', ').replace(/\./g, '');
      setError(`Please upload a valid file (${allowedExtensionsMessage}).`);
      return false;
    }
    if (file.size > maxSizeInMB * 1024 * 1024) {
      setError(`File size must be less than ${maxSizeInMB}MB.`);
      return false;
    }
    return true;
  };

  const handleFileDrop = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragging(false);

    const droppedFile = e.dataTransfer.files?.[0];
    if (droppedFile && validateFile(droppedFile)) {
      setFile(droppedFile);
      setError(null);
      onFileSelect(droppedFile);
    }
  };

  const handleDragOver = (e: DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragging(true);
  };

  const handleDragLeave = () => {
    setDragging(false);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && validateFile(selectedFile)) {
      setFile(selectedFile);
      setError(null);
      onFileSelect(selectedFile);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) {
      setError('Please select a file to upload.');
      return;
    }
    onUpload();
  };

  return (
    <form onSubmit={handleSubmit}>
      <div
        className={`border-2 border-dashed rounded-lg p-6 text-center cursor-pointer ${
          dragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300'
        } ${
          error ? 'border-red-500' : ''
        } hover:border-blue-500 hover:bg-blue-50 transition-colors duration-200`}
        onDrop={handleFileDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onClick={() => fileInputRef.current?.click()}
      >
        <input
          type="file"
          ref={fileInputRef}
          onChange={handleFileChange}
          accept={allowedExtensions.join(',')}
          className="hidden"
        />
        <DocumentArrowUpIcon className="mx-auto h-12 w-12 text-gray-400" />
        <p className="mt-2 text-sm text-gray-600">
          {file ? file.name : 'Drag and drop your file here, or click to select'}
        </p>
        <p className="mt-1 text-xs text-gray-500">
          {allowedExtensions.join(', ').toUpperCase()} up to {maxSizeInMB}MB
        </p>
      </div>

      {error && <div className="text-red-500 text-sm mt-2">{error}</div>}

      <div className="flex justify-end mt-4">
        <button
          type="submit"
          disabled={!file || isLoading}
          className={`px-4 py-2 text-white rounded-md ${
            !file || isLoading ? 'bg-gray-300 cursor-not-allowed' : 'bg-blue-500 hover:bg-blue-600'
          } transition-colors duration-200`}
        >
          {isLoading ? 'Uploading...' : 'Upload'}
        </button>
      </div>
    </form>
  );
}
