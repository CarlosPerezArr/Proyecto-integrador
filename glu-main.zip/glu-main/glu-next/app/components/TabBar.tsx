import React, { useEffect, useState } from 'react';

export interface TabProps {
  name: string;
  title?: string;
  count?: number;
  flag?: {
    inProgress: boolean;
    done: boolean;
  };
  disabled?: boolean;
}

export interface TabBarProps {
  tabs: TabProps[];
  selectedTab?: TabProps | null;
  onClick?: (clickedTab: TabProps) => void;
  progressive?: boolean;
}

const TabBar: React.FC<TabBarProps> = ({ tabs, selectedTab, onClick, progressive }) => {
  const [activeTab, setActiveTab] = useState(tabs[0]);

  const handleClick = (tab: TabProps) => {
    setActiveTab(tab);
    onClick && onClick(tab);
  };

  useEffect(() => {
    if (selectedTab) {
      setActiveTab(selectedTab);
    }
  }, [selectedTab]);

  const flagClass = 'px-1 h-6 leading-[26px] font-mono text-xs rounded-sm uppercase';

  return (
    <div className="mt-8">
      <div className="relative h-[42px] border-b-[1px] border-gray-300">
        <div className={`absolute h-[42px] flex w-full`}>
          {tabs.map((tab, i) => (
            <div key={i} className={`${progressive ? 'w-1/4' : ''} flex flex-row`}>
              <a
                className={`px-2 flex-none flex items-center py-2 font-normal font-mono text-sm cursor-pointer
                  ${
                    activeTab && activeTab.name === tab.name
                      ? 'pointer-events-none text-primary border-b-2 border-primary'
                      : tab.flag?.done
                        ? 'text-primary border-b-2 border-primary'
                        : 'text-gray-300 hover:text-primary'
                  }
                  ${progressive ? '' : i === tabs.length - 1 ? 'mr-0' : 'mr-24'}
                  ${tab.disabled ? 'opacity-25 pointer-events-none' : ''}
                `}
                onClick={() => handleClick(tab)}
              >
                {tab.count && (
                  <span
                    className={`mr-2 ${flagClass} ${
                      activeTab.name === tab.name
                        ? 'bg-primary text-white'
                        : 'bg-neutral text-base-100'
                    }`}
                  >
                    {tab.count > 0 ? tab.count : 'E'}
                  </span>
                )}
                {tab.title}
                {!tab.disabled && tab.flag && (
                  <span
                    className={`ml-2 ${flagClass} ${
                      tab.flag.done || tab.flag.inProgress
                        ? 'bg-primary text-base-100'
                        : 'bg-neutral text-white'
                    }`}
                  >
                    {tab.flag.inProgress
                      ? tab.flag.done
                        ? 'Done'
                        : 'In Progress'
                      : tab.flag.done
                        ? 'Done'
                        : 'To Do'}
                  </span>
                )}
              </a>
              {progressive && (
                <div
                  key={`line-${i}`}
                  className={`flex-1 h-[42px]  ${
                    tab.flag?.done && (tabs[i + 1]?.flag?.done || tabs[i + 1]?.flag?.inProgress)
                      ? 'border-b-2 border-primary'
                      : ''
                  }`}
                />
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default TabBar;
