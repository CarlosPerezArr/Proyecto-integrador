import React from 'react';
import Spinner from './Spinner';

const LoadingSpinner = ({ title = 'Loading...' }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-64 p-8 space-y-4 bg-white dark:bg-transparent rounded-lg">
      <h2 className="text-xl font-semibold text-gray-700 dark:text-gray-200">{title}</h2>
      <Spinner />
    </div>
  );
};

export default LoadingSpinner;
