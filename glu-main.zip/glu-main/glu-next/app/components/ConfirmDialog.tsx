import Dialog from './Dialog';
import React from 'react';
interface Props {
  title: string;
  children: React.ReactNode;
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
}
export default function Confirm(props: Props) {
  const { open, onClose, title, children, onConfirm } = props;
  if (!open) {
    return <></>;
  }

  return (
    <Dialog open={open} onClose={onClose}>
      <h2 className="text-xl font-semibold">{title}</h2>
      <div className="py-5">{children}</div>
      <div className="flex justify-end">
        <div className="p-1">
          <button onClick={() => onClose()} className="btn-sm btn btn-primary">
            No
          </button>
        </div>
        <div className="p-1">
          <button
            className="btn btn-sm btn-error btn-outline"
            onClick={() => {
              onClose();
              onConfirm();
            }}
          >
            Yes
          </button>
        </div>
      </div>
    </Dialog>
  );
}
