import React from 'react';
import { ChevronRightIcon } from '@heroicons/react/24/solid';

interface BreadCrumbProps {
  trail: any[];
}

const BreadCrumb: React.FC<BreadCrumbProps> = ({ trail }) => {
  return (
    <div className="font-mono font-semibold text-sm flex items-center">
      {trail.map((crumb, index) => (
        <span className="flex items-center" key={index}>
          {crumb}
          {index + 1 === trail.length ? (
            ''
          ) : (
            <ChevronRightIcon className="mx-3 mb-0.5 size-4 stroke-white inline" strokeWidth="1" />
          )}
        </span>
      ))}
    </div>
  );
};

export default BreadCrumb;
