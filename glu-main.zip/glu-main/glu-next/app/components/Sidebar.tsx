'use client';

import Link from 'next/link';
import RemoteSVG from 'app/components/RemoteSVG';
import { usePathname } from 'next/navigation';

export default function Sidebar({ children }: { children: React.ReactNode }) {
  const currentPath = usePathname();

  const isActive = (path: string) => {
    if (path === '/') {
      return currentPath === path;
    }
    return currentPath.startsWith(path);
  };

  return (
    <div className="drawer lg:drawer-open">
      <input id="my-drawer-2" type="checkbox" className="drawer-toggle" />
      <div className="drawer-content flex flex-col flex-1 overflow-y-auto">{children}</div>
      <div className="drawer-side shadow-xl">
        <label htmlFor="my-drawer-2" aria-label="close sidebar" className="drawer-overlay "></label>
        <ul className="menu mt-4 p-4 w-50 min-h-full text-base-content bg-base-100  lg:bg-transparent">
          <li className={` mb-4 ${isActive('/') || isActive('/projects') ? 'active' : ''}`}>
            <Link
              className="flex items-center hover:bg-transparent hover:underline font-mono pl-2 pr-6 py-1 rounded-md"
              href="/"
            >
              <RemoteSVG
                src="/icon-projects.svg"
                alt="projects"
                width="16"
                height="16"
                className="mb-[2px]"
                wrapperClassName="w-4"
              />
              Projects
            </Link>
          </li>
          <li className={` mb-4 ${isActive('/tools') ? 'active' : ''}`}>
            <Link
              className="flex items-center hover:bg-transparent hover:underline font-mono pl-2 pr-6 py-1 rounded-md"
              href="/tools"
            >
              <RemoteSVG
                src="/icon-tools.svg"
                alt="tools"
                width="16"
                height="16"
                className="mb-[2px]"
                wrapperClassName="w-4"
              />
              Tools
            </Link>
          </li>
          {/* <li className={` mb-4 ${isActive('/users') ? 'active' : ''}`}>
            <Link
              className="flex items-center hover:bg-transparent hover:underline font-mono pl-2 pr-6 py-1 rounded-md"
              href="/users"
            >
              <RemoteSVG
                src="/icon-users.svg"
                alt="users"
                width="16"
                height="16"
                className="mb-[2px]"
                wrapperClassName="w-4"
              />
              Users
            </Link>
          </li> */}
          {/* <li className={` mb-4 ${isActive('/reports') ? 'active' : ''}`}>
            <Link
              className="flex items-center hover:bg-transparent hover:underline font-mono pl-2 pr-6 py-1 rounded-md"
              href="/reports"
            >
              <RemoteSVG
                src="/icon-reports.svg"
                alt="reports"
                width="16"
                height="16"
                className="mb-[2px]"
                wrapperClassName="w-4"
              />
              Reports
            </Link>
          </li> */}
          <li className={` mb-4 ${isActive('/recents') ? 'active' : ''}`}>
            <Link
              className="flex items-center hover:bg-transparent hover:underline font-mono pl-2 pr-6 py-1 rounded-md"
              href="/recents"
            >
              <RemoteSVG
                src="/icon-recents.svg"
                alt="recents"
                width="16"
                height="16"
                className="mb-[2px]"
                wrapperClassName="w-4"
              />
              Recents
            </Link>
          </li>
        </ul>
      </div>
    </div>
  );
}
