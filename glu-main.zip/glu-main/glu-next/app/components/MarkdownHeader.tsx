import React from 'react';
import Image from 'next/image';

interface MarkdownHeaderProps {
  busy: boolean;
  content: any;
}

const MarkdownHeader: React.FC<MarkdownHeaderProps> = ({ busy, content }) => {
  return (
    <div className="p-8 w-full flex flex-row rounded-lg rounded-b-none bg-base-100 border-[1px] border-b-0 border-gray-500">
      <div className="mr-4 flex items-center justify-center rounded-full bg-base-100 w-8 h-8">
        <Image alt="logo" src="/logo-purple-32.svg" className="" width="32" height="32" />
      </div>
      <div className="flex items-center rounded-[4px] border-[1px] border-gray-400 px-2 font-semibold text-xs text-primary">
        <div className={`flex items-center`}>
          {busy ? (
            <span className={`loading loading-spinner text-white loading-xs mr-2`}></span>
          ) : (
            <div>
              <span
                className={`rounded-full block w-4 h-4 ring-[3px] ring-inset ring-primary mr-2`}
              ></span>
            </div>
          )}

          {content}
        </div>
      </div>
    </div>
  );
};

export default MarkdownHeader;
