'use client';
import React, { useState } from 'react';

interface PageButtonsProps {
  data?: {
    previous_page?: string | null | undefined;
    next_page?: string | null | undefined;
    total?: number | null | undefined;
  };
  pageSize: number;
  onClick: (pageCursor: string, pageNumber: number) => void;
  disabled: boolean;
}

const PageButtons: React.FC<PageButtonsProps> = ({ data, pageSize, onClick, disabled }) => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [cursor, setCursor] = useState<string>('default');
  const [pageNumber, setPageNumber] = useState<number>(1);

  const total = data?.total || null;
  const numPages = total ? (total > pageSize ? Math.ceil(total / pageSize) : 1) : null;

  function prevPage(pageCursor: string) {
    const newPageNumber = pageNumber - 1;
    const newCursor = newPageNumber === 1 ? 'default' : pageCursor;
    setPageNumber(newPageNumber);
    setCursor(newCursor);

    onClick(newCursor, newPageNumber);
  }

  function nextPage(pageCursor: string) {
    const newPageNumber = pageNumber + 1;
    setPageNumber(newPageNumber);
    setCursor(pageCursor);

    onClick(pageCursor, newPageNumber);
  }

  return (
    <div>
      {numPages && numPages > 1 && (
        <div
          className={`flex justify-center mt-4 ${disabled ? 'opacity-50 pointer-events-none	' : ''}`}
        >
          <div className="join">
            <button
              className={`join-item btn ${
                data?.previous_page ? '' : 'btn-disabled'
              } mr-4 hover:bg-primary hover:text-base-100`}
              onClick={() => prevPage(data?.previous_page as string)}
            >
              «
            </button>
            <button className="join-item mr-4 font-mono font-normal">
              Page {pageNumber} of {numPages}
            </button>
            <button
              className={`join-item btn ${
                data?.next_page ? '' : 'btn-disabled'
              } hover:bg-primary hover:text-base-100`}
              onClick={() => nextPage(data?.next_page as string)}
            >
              »
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default PageButtons;
