'use client';

import Image from 'next/image';
import Link from 'next/link';
import AccountNav from './AccountNav';

export default function Header() {
  return (
    <div className="navbar shadow-md bg-base-100 min-h-20 p-0">
      <div className="flex-1">
        <Link href="/" className="btn btn-ghost normal-case text-xl text-primary">
          <Image alt="logo" src="/logo-white.svg" className="w-18 mr-2" width="116" height="32" />
        </Link>
      </div>

      <div className="flex-none gap-2 mr-4">
        <label htmlFor="my-drawer-2" className="btn btn-ghost drawer-button lg:hidden">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={1.5}
            stroke="currentColor"
            className="w-6 h-6"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5"
            />
          </svg>
        </label>

        <AccountNav />
      </div>
    </div>
  );
}
