'use client';
import React from 'react';
import { XMarkIcon } from '@heroicons/react/24/solid';

interface Props {
  children: React.ReactNode;
  open: boolean;
  onClose: () => void;
}
export default function Dialog(props: Props) {
  const { open, onClose } = props;
  if (!open) {
    return <></>;
  }
  return (
    <div className="fixed inset-0 z-50 overflow-auto bg-gray-500/[.4] flex">
      <div className="relative p-8 bg-base-100 mt-64 w-full max-w-md h-fit mx-auto flex-col flex rounded-lg">
        <div>{props.children}</div>
        <span className="absolute top-0 right-0 p-4">
          <a
            className="text-gray-500 hover:text-white cursor-pointer w-6 h-6 block"
            onClick={() => onClose()}
          >
            <XMarkIcon className="" />
          </a>
        </span>
      </div>
    </div>
  );
}
