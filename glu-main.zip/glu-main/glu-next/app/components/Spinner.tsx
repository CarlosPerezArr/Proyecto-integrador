import React from 'react';

interface SpinnerProps {
  children?: any;
  className?: string;
}

const Spinner: React.FC<SpinnerProps> = ({ children, className }) => {
  return (
    <div className={`flex items-center font-mono text-xl ${className}`}>
      <span className="loading loading-spinner text-primary loading-md mr-2"></span>
      {children}
    </div>
  );
};

export default Spinner;
