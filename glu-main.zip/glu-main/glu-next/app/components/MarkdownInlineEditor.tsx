'use client';

import React, { useState, useEffect, useRef } from 'react';
import ReactMarkdown, { Components } from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { dracula } from 'react-syntax-highlighter/dist/esm/styles/prism';

// eslint-disable-next-line @typescript-eslint/no-unused-vars
interface CodeProps {
  inline?: boolean;
  className?: string;
  children?: React.ReactNode;
}

interface Annotation {
  id: string;
  type: string;
  body: any[];
  target: any;
}

interface MarkdownInlineEditor {
  text: string;
  className?: string;
  components?: Components;
  onExport?: (markdown: string) => void;
}

const customComponents: Components = {
  code: ({ className, children, ...props }) => {
    const match = /language-(\w+)/.exec(className || '');
    return match ? (
      <SyntaxHighlighter
        style={dracula as any}
        language={match[1]}
        PreTag="div"
        {...(props as any)}
      >
        {String(children)}
      </SyntaxHighlighter>
    ) : (
      <code className={className} {...props}>
        {children}
      </code>
    );
  }
};

const MarkdownInlineEditor = React.forwardRef<
  { exportAnnotations: () => string },
  MarkdownInlineEditor
>(({ text = '', className = '', components, onExport }, ref) => {
  const [currentText, setCurrentText] = useState<string>(text);
  const [isClient, setIsClient] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);
  const recogitoRef = useRef<any>(null);
  const previousTextRef = useRef<string>(text);
  const markdownContentRef = useRef<HTMLDivElement>(null);
  const unmountingRef = useRef(false);

  // Initialize Recogito function with safety checks
  const initializeRecogito = async () => {
    // Wait for next render cycle
    await new Promise((resolve) => requestAnimationFrame(resolve));

    if (unmountingRef.current || !contentRef.current || !isClient) {
      console.log('Skipping Recogito initialization due to unmounting or missing requirements');
      return;
    }

    // Cleanup existing instance
    if (recogitoRef.current) {
      try {
        recogitoRef.current.destroy();
      } catch (e) {
        console.warn('Error destroying previous Recogito instance:', e);
      }
      recogitoRef.current = null;
    }

    // Safety check after cleanup
    if (unmountingRef.current || !contentRef.current) {
      return;
    }

    // Wait for any pending DOM updates
    await new Promise((resolve) => setTimeout(resolve, 0));

    try {
      if ((window as any).Recogito) {
        console.log('Initializing new Recogito instance');
        recogitoRef.current = (window as any).Recogito.init({
          content: contentRef.current,
          locale: 'en',
          allowEmpty: true,
          readOnly: false,
          mode: 'pre-select',
          widgets: [{ widget: 'COMMENT' }]
        });
      }
    } catch (error) {
      console.error('Failed to initialize Recogito:', error);
    }
  };

  // Load Recogito resources
  useEffect(() => {
    let mounted = true;

    const loadResources = async () => {
      if (!mounted) return;

      if (!document.querySelector('link[href*="recogito.min.css"]')) {
        const cssLink = document.createElement('link');
        cssLink.rel = 'stylesheet';
        cssLink.href = 'https://cdn.jsdelivr.net/npm/@recogito/recogito-js/dist/recogito.min.css';
        document.head.appendChild(cssLink);
      }

      if (!document.querySelector('script[src*="recogito.min.js"]')) {
        const scriptElement = document.createElement('script');
        scriptElement.src =
          'https://cdn.jsdelivr.net/npm/@recogito/recogito-js/dist/recogito.min.js';
        await new Promise((resolve) => {
          scriptElement.onload = resolve;
          document.head.appendChild(scriptElement);
        });
      }

      if (mounted) {
        setIsClient(true);
      }
    };

    loadResources();

    return () => {
      mounted = false;
    };
  }, []);

  // Handle text updates
  useEffect(() => {
    if (text !== previousTextRef.current) {
      setCurrentText(text);
      previousTextRef.current = text;
    }
  }, [text]);

  // Initialize Recogito when text or client state changes
  useEffect(() => {
    unmountingRef.current = false;
    let mounted = true;
    let timeoutId: NodeJS.Timeout;

    if (isClient && currentText && mounted) {
      timeoutId = setTimeout(() => {
        if (mounted && !unmountingRef.current) {
          initializeRecogito();
        }
      }, 200);
    }

    return () => {
      mounted = false;
    };
  }, []);

  // Handle text updates
  useEffect(() => {
    if (text !== previousTextRef.current) {
      setCurrentText(text);
      previousTextRef.current = text;
    }
  }, [text]);

  // Initialize Recogito when text or client state changes
  useEffect(() => {
    unmountingRef.current = false;
    let mounted = true;
    let timeoutId: NodeJS.Timeout;

    if (isClient && currentText && mounted) {
      timeoutId = setTimeout(() => {
        if (mounted && !unmountingRef.current) {
          initializeRecogito();
        }
      }, 200);
    }

    return () => {
      mounted = false;
    };
  }, []);

  // Handle text updates
  useEffect(() => {
    // console.log('TEXT CHANGED:', text);
    if (text !== previousTextRef.current) {
      // console.log('Updating text:', text);

      setCurrentText(text);
      previousTextRef.current = text;
    }
  }, [text]);

  // Initialize Recogito when text or client state changes
  useEffect(() => {
    unmountingRef.current = false;
    let mounted = true;
    let timeoutId: NodeJS.Timeout;

    if (isClient && currentText && mounted) {
      timeoutId = setTimeout(() => {
        if (mounted && !unmountingRef.current) {
          initializeRecogito();
        }
      }, 200);
    }

    return () => {
      mounted = false;
      unmountingRef.current = true;
      if (timeoutId) {
        clearTimeout(timeoutId);
      }
      if (recogitoRef.current) {
        try {
          recogitoRef.current.destroy();
        } catch (e) {
          console.warn('Error destroying Recogito instance:', e);
        }
        recogitoRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isClient, currentText]);

  // Ensure cleanup on unmount
  useEffect(() => {
    return () => {
      unmountingRef.current = true;
      if (recogitoRef.current) {
        try {
          recogitoRef.current.destroy();
        } catch (e) {
          console.warn('Final cleanup - Error destroying Recogito:', e);
        }
        recogitoRef.current = null;
      }
    };
  }, []);

  const generateAnnotatedMarkdown = () => {
    if (!recogitoRef.current || !contentRef.current) return null;
    if (
      recogitoRef.current.getAnnotations() === null ||
      recogitoRef.current.getAnnotations().length === 0
    )
      return null;

    let result = contentRef.current.innerHTML;
    let prevResult;

    // Process annotations
    do {
      prevResult = result;
      result = result.replace(
        /<span class="r6o-annotation" data-id="#([a-f0-9-]+)">((?:[^<]|<(?!span class="r6o-annotation")[^>]*>)*?)<\/span>/g,
        (match, id, content) => {
          const cleanContent = content.replace(/<[^>]+>/g, '');
          return `[[${cleanContent}]]((#${id}))`;
        }
      );
    } while (result !== prevResult);

    // Clean up HTML
    result = result
      .replace(/<([a-z0-9]+)(?:\s+[^>]*)?>\s*<\/\1>/gi, '')
      .replace(/<([a-z0-9]+)(?:\s+[^>]*)?>/gi, (match, tagName) => {
        if (tagName === 'code' && match.includes('language-')) {
          const langMatch = match.match(/language-[a-zA-Z]+/);
          return langMatch ? `<code class="${langMatch[0]}">` : `<${tagName}>`;
        }
        if (tagName === 'a' && match.includes('href=')) {
          const hrefMatch = match.match(/href="([^"]+)"/);
          return hrefMatch ? `<a href="${hrefMatch[1]}">` : `<${tagName}>`;
        }
        return `<${tagName}>`;
      });

    // Process annotation metadata
    const annotations = recogitoRef.current.getAnnotations();
    annotations.forEach((annotation: Annotation) => {
      const notes = [
        ...annotation.body.filter((body) => body.purpose === 'tagging').map((body) => body.value),
        ...annotation.body.filter((body) => body.purpose === 'commenting').map((body) => body.value)
      ].join(', ');

      result = result.replace(new RegExp(`${annotation.id}`, 'g'), `${notes}`);
    });

    return result.split('\n').join('\n\n');
  };

  React.useImperativeHandle(ref, () => ({
    exportAnnotations: () => {
      const annotatedText = generateAnnotatedMarkdown();
      if (onExport) {
        onExport(annotatedText || '');
      }
      console.log('Exporting');
      console.log(annotatedText);
      return annotatedText || ''; // Return empty string if null
    }
  }));

  if (!isClient) {
    return null;
  }

  return (
    <div className={`relative w-full h-full min-h-[200px] ${className}`}>
      <div ref={contentRef} className="w-full h-full p-4">
        <div ref={markdownContentRef}>
          <ReactMarkdown
            key={currentText} // Add this
            className="markdown-content prose prose-invert max-w-none"
            skipHtml={true}
            components={customComponents}
          >
            {currentText}
          </ReactMarkdown>
        </div>
      </div>
    </div>
  );
});

MarkdownInlineEditor.displayName = 'MarkdownInlineEditor';

export default MarkdownInlineEditor;
