import React, { useEffect } from 'react';
import Alert from '@/app/components/Alert';
import { AlertObject } from '@/app/lib/definitions';

interface PageCardProps {
  title?: any | null;
  subTitle?: any | null;
  alert?: AlertObject | null;
  headerNodes?: React.ReactNode[];
  children: React.ReactNode;
}

const PageCard: React.FC<PageCardProps> = ({
  title = null,
  subTitle = null,
  alert = null,
  headerNodes = null,
  children
}) => {
  useEffect(() => {
    if (alert) {
      if (alert.autoClose) {
        setTimeout(() => {
          // eslint-disable-next-line react-hooks/exhaustive-deps
          alert = null;
        }, 5000);
      }
    }
  }, [alert]);

  return (
    <div className="h-screen px-16 flex flex-col items-center mt-">
      <div className="w-full rounded shadow-xl flex flex-col gradient-box bg-base-100">
        <div className="flex">
          <div className="w-2/3">
            {title && typeof title === 'string' && <h1 className="mb-1/2">{title}</h1>}
            {title && typeof title !== 'string' && <>{title}</>}
            {subTitle && typeof subTitle === 'string' && (
              <small className="block max-w-96 font-normal font-mono text-gray-500">
                {subTitle}
              </small>
            )}
            {subTitle && typeof subTitle !== 'string' && <>{subTitle}</>}
            {alert && <Alert message={alert.message} type={alert.type} onClick={alert.onClick} />}
          </div>
          {headerNodes && (
            <div className="w-1/3 justify-end items-end flex flex-row">{headerNodes}</div>
          )}
        </div>
        {children}
      </div>
    </div>
  );
};

PageCard.displayName = 'PageCard';

export default PageCard;
