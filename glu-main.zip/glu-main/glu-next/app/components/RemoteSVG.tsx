import React, { useEffect } from 'react';

const fetchSvg = async (url: string) => {
  const response = await fetch(url);

  const text = await response.text();
  // Remove the XML declaration
  const svg = text.replace(/<\?xml.*\?>/, '');
  return svg;
};

// Fetches an SVG from the file and renders it inline
// This is useful so that SVG values like 'currentColor' work properly with local styling
type Props = {
  src: string;
  alt?: string;
  width?: string;
  height?: string;
  className?: string;
  wrapperClassName?: string;
};

const RemoteSVG: React.FC<Props> = ({
  src,
  alt,
  width,
  height,
  className = '',
  wrapperClassName = ''
}) => {
  const id = React.useId();

  useEffect(() => {
    fetchSvg(src).then((svg) => {
      const element = document.getElementById(id);
      if (element) {
        element.innerHTML = svg;
        if (className) element.querySelector('svg')?.setAttribute('class', className);
        if (alt) element.querySelector('svg')?.setAttribute('alt', alt);
        if (height) element.querySelector('svg')?.setAttribute('height', height);
        if (width) element.querySelector('svg')?.setAttribute('width', width);
      }
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [src]);

  return <div id={id} className={wrapperClassName} />;
};

export default RemoteSVG;
