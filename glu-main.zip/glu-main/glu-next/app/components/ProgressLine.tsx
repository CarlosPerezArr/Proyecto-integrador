import React from 'react';
import { CheckIcon } from '@heroicons/react/24/solid';

interface ProgressLineProps {
  currentStep: number;
  totalSteps: number;
}

const ProgressLine: React.FC<ProgressLineProps> = ({ currentStep = 0, totalSteps = 2 }) => {
  return (
    <div className="flex flex-row justify-start mb-8">
      {[...Array(totalSteps)].map((_, i) => (
        <div key={i} className="flex items-center relative">
          <div
            className={`mr-20 w-8 h-8 rounded-full flex items-center justify-center border-2  bg-black ${
              i + 1 === currentStep
                ? 'border-primary'
                : i + 1 < currentStep
                  ? 'bg-primary border-primary'
                  : 'border-gray-500'
            }`}
          >
            {i + 1 < currentStep ? (
              <CheckIcon className="size-4 text-white stroke-white" strokeWidth="2" />
            ) : i + 1 === currentStep ? (
              <span className="block w-[10px] h-[10px] rounded-full bg-primary"></span>
            ) : (
              ''
            )}
          </div>
          {i + 1 < totalSteps && (
            <hr
              key={`line-${i}`}
              className={`absolute right-0 w-20 border-t-0 h-[2px] ${
                i + 1 < currentStep ? 'bg-primary' : 'bg-gray-500'
              }`}
            />
          )}
        </div>
      ))}
    </div>
  );
};

export default ProgressLine;
