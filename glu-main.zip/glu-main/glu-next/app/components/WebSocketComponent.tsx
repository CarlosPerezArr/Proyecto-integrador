import React, { useEffect, useState } from 'react';
import { getWebSocketState, maxConnectionTries } from '@/app/lib/WebSocketConfig';

interface WebSocketComponentProps {
  url: string;
  onMessage?: (data: any) => void;
  onError?: () => void;
  onComplete?: () => void;
  onOpen?: () => void; // New prop for open event
  disconnect?: boolean;
  connect?: boolean;
}

const WebSocketComponent: React.FC<WebSocketComponentProps> = ({
  url,
  onMessage,
  onError,
  onComplete,
  onOpen,
  disconnect,
  connect = false
}) => {
  const [webSocket, setWebSocket] = useState<WebSocket | null>(null);
  const [webSocketState, setWebSocketState] = useState<string>('CLOSED');
  const [connectionError, setConnectionError] = useState<boolean>(false);
  const [connectionTries, setConnectionTries] = useState<number>(0);

  // Connection status tracking
  let connectionInProgress = false;

  useEffect(() => {
    if (webSocket) {
      webSocket.onopen = () => {
        console.log('Connection opened');
        setConnectionTries(0);
        setWebSocketState('OPEN');
        connectionInProgress = false;
        if (onOpen) onOpen(); // Call the onOpen callback
      };

      webSocket.onclose = () => {
        console.log('Connection closed');
        setWebSocketState('CLOSED');
        setWebSocket(null);
        (window as any).websocketInstance = undefined;
        if (onComplete) onComplete();
      };

      webSocket.onerror = (event) => {
        console.error('WebSocket error:', event);
        const ws = event.target as WebSocket;
        if (getWebSocketState(Number(ws.readyState)) === 'CLOSED') {
          setConnectionError(true);
        }
        if (onError) onError();
      };

      webSocket.onmessage = (event) => {
        if (event.data.includes('ACK')) return;

        console.log('Handling inbound message', event.data);
        try {
          const message = JSON.parse(event.data);
          if (onMessage) onMessage(message);
        } catch (error) {
          console.error('Error parsing message:', error);
          if (onError) onError();
        }
      };
    }
  }, [webSocket, onOpen, onMessage, onError, onComplete]);

  // Handle connection request
  useEffect(() => {
    if (connect && !webSocket && !connectionInProgress) {
      if (connectionTries >= maxConnectionTries) {
        handleConnectionFailure();
        return;
      }
      connectWebSocket();
    }
  }, [connect]);

  // Handle disconnection request
  useEffect(() => {
    if (disconnect && webSocket) {
      webSocket.close();
    }
  }, [disconnect, webSocket]);

  function connectWebSocket() {
    if (connectionInProgress) return;
    connectionInProgress = true;
    setConnectionTries((prev) => prev + 1);
    console.log('Opening connection');
    setWebSocketState('CONNECTING');
    const ws = new WebSocket(url);
    setWebSocket(ws);
    (window as any).websocketInstance = ws;
  }

  function handleConnectionFailure() {
    setWebSocket(null);
    setConnectionError(true);
    connectionInProgress = false;
    if (onError) onError();
  }

  return (
    <div className="w-full shadow-sm rounded-lg">
      <div className="p-4">
        {webSocketState === 'CONNECTING' && !connectionError && (
          <div className="flex flex-row items-center">
            <div className="w-4 h-4 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mr-2"></div>
            <span>Establishing server connection...</span>
          </div>
        )}

        {connectionError && <div className="text-red-500">Error connecting to server.</div>}
      </div>
    </div>
  );
};

export default WebSocketComponent;
