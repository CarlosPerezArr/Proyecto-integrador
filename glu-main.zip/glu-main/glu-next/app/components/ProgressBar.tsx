import React, { useEffect, useState } from 'react';

interface ProgressBarProps {
  durationSeconds: number;
  title: string;
  onComplete?: () => void;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ durationSeconds, title, onComplete }) => {
  const [progressSeconds, setProgressSeconds] = useState<number>(0);
  const [progressPercentage, setProgressPercentage] = useState<number>(0);

  useEffect(() => {
    const id = setInterval(() => {
      setProgressSeconds((prev) => {
        return prev + 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    setProgressPercentage(Math.round((progressSeconds / durationSeconds) * 100));
  }, [progressSeconds, durationSeconds]);
  useEffect(() => {
    console.log('progressPercentage:', progressPercentage);
    if (progressPercentage === 100) {
      setProgressSeconds(0);
      setProgressPercentage(0);
      if (onComplete) onComplete();
    }
  }, [progressPercentage, onComplete]);

  return (
    <div className="w-3/4 rounded bg-base-100 p-4">
      <div className="mb-4">
        <strong>Processing:</strong> {title}
      </div>
      <div className="flex flex-row">
        <div className="flex-1 flex flex-row">
          <span className="loading loading-spinner text-primary loading-md mr-2"></span>
        </div>
        <div className="flex-1 text-right">
          <strong>Progress:</strong> {progressPercentage}%
        </div>
      </div>
      <progress
        className="progress progress-primary w-full"
        value={progressPercentage}
        max="100"
      ></progress>
    </div>
  );
};

export default ProgressBar;
