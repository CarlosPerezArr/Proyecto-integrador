'use client';
import React, { useState } from 'react';
// import { ClipboardIcon } from '@heroicons/react/24/outline';
// import { CopyToClipboard } from 'react-copy-to-clipboard';

interface CopyButtonProps {
  textToCopy: string;
  enabled: boolean;
  onCopy?: (text: string) => void;
}

const CopyButton: React.FC<CopyButtonProps> = ({ textToCopy, enabled, onCopy }) => {
  // const [copyStatus, setCopyStatus] = useState<boolean>(false);

  // const onCopyText = () => {
  //   setCopyStatus(true);
  //   setTimeout(() => setCopyStatus(false), 2000); // Reset status after 2 seconds
  //   if (onCopy) onCopy(textToCopy);
  // };

  return (
    <div></div>
    // <CopyToClipboard text={textToCopy} onCopy={onCopyText}>
    //   <div
    //     className="text-xs tooltip tooltip-right tooltip-base-100 tooltip-xs"
    //     data-tip={`${copyStatus ? 'copied!' : 'copy to clipboard'}`}
    //   >
    //     <button
    //       className={`btn btn-primary btn-sm ${copyStatus ? 'italic' : ''} ${
    //         enabled ? '' : 'opacity-25 pointer-events-none'
    //       }`}
    //     >
    //       <ClipboardIcon className="mb-0.5 size-4" />
    //     </button>
    //   </div>
    // </CopyToClipboard>
  );
};

export default CopyButton;
