import React, { useEffect, useState } from 'react';

interface PageProcessingProgressBarProps {
  filename: string;
  numPages: number;
  processedPages: number[];
  onComplete?: () => void;
}

const PageProcessingProgressBar: React.FC<PageProcessingProgressBarProps> = ({
  filename,
  numPages,
  processedPages,
  onComplete
}) => {
  const [progressPercentage, setProgressPercentage] = useState<number>(0);

  useEffect(() => {
    console.log('processedPages:', processedPages.length, 'of', numPages);

    setProgressPercentage(
      processedPages.length > 0 && numPages > 0
        ? parseFloat(((processedPages.length / numPages) * 100).toFixed(1))
        : 0
    );
  }, [processedPages, numPages]);

  useEffect(() => {
    console.log('progressPercentage:', progressPercentage);
    if (progressPercentage >= 100 && onComplete) {
      onComplete();
    }
  }, [progressPercentage, onComplete]);

  return (
    <div className="w-1/2 rounded bg-base-100 p-4 border-dashed border-primary border-[1px]">
      <div className="mb-4 text-primary text-sm font-mono font-normal line-clamp-1">{filename}</div>
      <div className="flex flex-row">
        <div className="flex-1 flex flex-row items-center text-primary font-mono text-xs">
          <span className="loading loading-spinner text-primary loading-md mr-2"></span>
          {numPages > 0 ? `${processedPages.length} / ${numPages}` : 0}
        </div>
        <div className="flex-1 text-right text-primary font-mono">{progressPercentage}%</div>
      </div>
      <progress className="progress w-full" value={progressPercentage} max="100"></progress>
      <small className="text-gray-500">
        Glu is loading your specification to the project. This can take several minutes.{' '}
      </small>
    </div>
  );
};

export default PageProcessingProgressBar;
