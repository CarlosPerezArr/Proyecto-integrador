import React, { useEffect, useState } from 'react';

interface ProgressBarProps {
  title: string;
  current: number;
  total: number;
  onComplete?: () => void;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ title, current, total, onComplete }) => {
  const [progressPercentage, setProgressPercentage] = useState<number>(0);

  useEffect(() => {
    const percentage = total > 0 ? parseFloat(((current / total) * 100).toFixed(1)) : 0;
    setProgressPercentage(percentage);

    if (percentage >= 100 && onComplete) {
      onComplete();
    }
  }, [current, total, onComplete]);

  return (
    <div className="w-full rounded bg-base-100 p-4">
      <div className="mb-4">
        <strong>{title}</strong>
      </div>
      <div className="flex flex-row">
        <div className="flex-1 flex flex-row">
          <span className="loading loading-spinner text-primary loading-md mr-2"></span>
          <strong className="mr-2">Progress:</strong>{' '}
          {total > 0 ? `${current} / ${total}` : 'Loading...'}
        </div>
        <div className="flex-1 text-right">
          <strong>Percentage:</strong> {progressPercentage}%
        </div>
      </div>
      <progress
        className="progress progress-primary w-full"
        value={progressPercentage}
        max="100"
      ></progress>
    </div>
  );
};

export default ProgressBar;
