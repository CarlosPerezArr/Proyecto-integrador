import React from 'react';
import {
  ExclamationCircleIcon,
  InformationCircleIcon,
  CheckCircleIcon,
  XCircleIcon
} from '@heroicons/react/24/solid';

export interface AlertProps {
  message: string;
  type: 'error' | 'success' | 'warning' | 'info';
  onClick?: () => void;
}

const Alert: React.FC<AlertProps> = ({ message, type, onClick }) => {
  const getBackgroundColor = () => {
    switch (type) {
      case 'error':
        return 'bg-red-100';
      case 'success':
        return 'bg-green-100';
      case 'warning':
        return 'bg-yellow-100';
      case 'info':
        return 'bg-blue-100';
      default:
        return 'bg-gray-100';
    }
  };

  const getIconColor = () => {
    switch (type) {
      case 'error':
        return 'text-red-500';
      case 'success':
        return 'text-green-500';
      case 'warning':
        return 'text-yellow-500';
      case 'info':
        return 'text-blue-500';
      default:
        return 'text-gray-500';
    }
  };

  return (
    <div
      role="alert"
      className={`font-mono absolute inset-x-1/2 -translate-x-1/2 w-3/4 -top-8 p-4 flex items-center gap-2 rounded-lg ${getBackgroundColor()} ${
        onClick ? 'cursor-pointer' : ''
      }`}
      onClick={onClick}
    >
      {type === 'error' && <XCircleIcon className={`size-6 ${getIconColor()}`} />}
      {type === 'success' && <CheckCircleIcon className={`size-6 ${getIconColor()}`} />}
      {type === 'warning' && <ExclamationCircleIcon className={`size-6 ${getIconColor()}`} />}
      {type === 'info' && <InformationCircleIcon className={`size-6 ${getIconColor()}`} />}
      <span className={getIconColor()}>{message}</span>
    </div>
  );
};

export default Alert;
