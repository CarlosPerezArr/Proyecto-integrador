import React from 'react';

interface MarkdownFooterProps {
  busy?: boolean;
  content: any;
}

const MarkdownFooter: React.FC<MarkdownFooterProps> = ({ busy = false, content }) => {
  return (
    <div
      className={`${
        busy ? 'pointer-events-none opacity-50' : ''
      } p-8 w-full flex flex-row rounded-lg rounded-t-none bg-base-100 border-[1px] border-t-0 border-gray-500`}
    >
      {content}
    </div>
  );
};

export default MarkdownFooter;
