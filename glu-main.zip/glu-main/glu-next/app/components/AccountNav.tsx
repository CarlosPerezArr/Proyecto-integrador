'use client';
import { useQuery } from '@tanstack/react-query';
import React from 'react';

import { InfoService } from '@/app/client';
import { trackUser } from '@/app/lib/mixpanel';

const AccountNav: React.FC = () => {
  const { data: user } = useQuery({
    queryKey: ['userRead'],
    queryFn: () => InfoService.getUserInfoUserInfoGet(),
    staleTime: Infinity
  });

  if (user) {
    trackUser(user);
  }

  function userNameAbbr(name: string) {
    name = 'brian howard arenz';
    const parts = name.split(' ');
    let abbr;
    if (parts.length === 1) {
      abbr = parts[0][0].toUpperCase();
    } else {
      abbr = [parts[0][0], parts[parts.length - 1][0]].join('');
    }
    return abbr.toUpperCase();
  }

  return (
    <div className="dropdown dropdown-end">
      <label
        tabIndex={1}
        className="btn btn-ghost border-0 hover:bg-info bg-info/75 p-0 rounded-full h-8 min-h-8"
      >
        <div className="flex">
          {user ? (
            <>
              {user.avatar_url ? (
                <div className="w-8 rounded-full grayscale">
                  <img className="rounded-full" src={user.avatar_url} alt="profile-image" />
                </div>
              ) : (
                <div className="avatar online placeholder">
                  <div className="bg-transparent text-primary w-8 rounded-full">
                    <span className="text-xl">{userNameAbbr(user.name)}</span>
                  </div>
                </div>
              )}
            </>
          ) : (
            <div className="avatar placeholder">
              <div className="bg-transparent text-primary w-8 rounded-full">
                <span className="text-xl">?</span>
              </div>
            </div>
          )}
        </div>
      </label>

      <ul
        tabIndex={1}
        className="mt-1 z-[1] p-2 menu menu-sm dropdown-content rounded-md w-52 shadow bg-black"
      >
        <li className="px-3 pb-2 mb-2 font-bold border-b-2 text-base-100">
          {user?.name || 'Guest User'}
        </li>
        <li>
          <a href="/api/auth/logout" className="">
            Logout
          </a>
        </li>
      </ul>
    </div>
  );
};

export default AccountNav;
