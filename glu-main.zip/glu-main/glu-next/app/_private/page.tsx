'use client';

import React, { useRef, useState, useCallback, useEffect } from 'react';
import MarkdownInlineEditor from '../components/MarkdownInlineEditor';

const testMarkdown = `# Welcome to the Markdown Editor

This is a test of the markdown editor with various elements. Try selecting some text to add annotations!

## Code Example
\`\`\`javascript
const greeting = "Hello, World!";
console.log(greeting);
\`\`\`

## List Example
- Item 1
- Item 2
  - Nested item
  - Another nested item
- Item 3

## Text Formatting
*This is italic* and **this is bold**

> This is a blockquote

[This is a link](https://example.com)
`;

const LoremButton = ({ onGenerate }: { onGenerate: (text: string) => void }) => {
  const generateLoremIpsum = () => {
    const lorem = [
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
      'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
      'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.',
      'Duis aute irure dolor in reprehenderit in voluptate velit esse.',
      'Excepteur sint occaecat cupidatat non proident, sunt in culpa.',
      'Nulla facilisi. Mauris blandit aliquet elit, eget tincidunt nibh.',
      'Vestibulum ante ipsum primis in faucibus orci luctus.',
      'Pellentesque habitant morbi tristique senectus et netus.'
    ];

    // Generate random number of paragraphs (1-5)
    const numParagraphs = Math.floor(Math.random() * 5) + 1;

    let text = '# Random Lorem Ipsum\n\n'; // Start with a title

    for (let i = 0; i < numParagraphs; i++) {
      // Add a subtitle for each paragraph
      text += `## Paragraph ${i + 1}\n\n`;

      // Generate random number of sentences (2-5) per paragraph
      const numSentences = Math.floor(Math.random() * 4) + 2;
      const paragraph = [];

      for (let j = 0; j < numSentences; j++) {
        const randomIndex = Math.floor(Math.random() * lorem.length);
        paragraph.push(lorem[randomIndex]);
      }

      text += paragraph.join(' ') + '\n\n';
    }

    onGenerate(text.trim());
  };

  return (
    <button
      onClick={generateLoremIpsum}
      className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-md
                shadow-sm transition-colors duration-200 flex items-center space-x-2 mr-2"
    >
      Generate Lorem Ipsum
    </button>
  );
};

export default function TestPage() {
  const [annotatedMarkdown, setAnnotatedMarkdown] = useState('');
  const [isExporting, setIsExporting] = useState(false);
  const [key, setKey] = useState(0); // Add a key to force re-mount
  const [editorContent, setEditorContent] = useState(testMarkdown);
  const editorRef = useRef<{ exportAnnotations: () => string }>(null);

  const handleExport = useCallback((markdown: string) => {
    setAnnotatedMarkdown(markdown);
    setIsExporting(false);
  }, []);

  const triggerExport = useCallback(() => {
    setIsExporting(true);
    if (editorRef.current) {
      try {
        const markdown = editorRef.current.exportAnnotations();
        handleExport(markdown);
      } catch (error) {
        console.error('Error exporting annotations:', error);
        setIsExporting(false);
      }
    }
  }, [handleExport]);

  const updateEditorContent = useCallback((text: string) => {
    console.log('Updating editor content:', text);
    setEditorContent(text);
    setKey((prev) => prev + 1); // Force re-mount of editor
  }, []);

  // Debug effect to monitor content changes
  useEffect(() => {
    console.log('Editor content changed:', editorContent);
  }, [editorContent]);

  return (
    <main className="min-h-screen bg-gray-900">
      <div className="container mx-auto p-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-4 text-white">Markdown Editor Test Page</h1>
          <div className="bg-gray-800 border border-gray-700 rounded-lg p-4 text-gray-300">
            <h2 className="text-lg font-semibold mb-2">Instructions:</h2>
            <ol className="list-decimal list-inside space-y-2">
              <li>Select any text in the editor to add annotations</li>
              <li>Use the annotation tools to add comments or tags</li>
              <li>
                Click Export to see the annotated markdown with format: [[text]]{'{{'}tags, comments
                {'}}'}
              </li>
              <li>Use &quot;Generate Lorem Ipsum&quot; to create random test content</li>
            </ol>
          </div>
        </div>

        <div className="flex justify-end mb-4">
          <LoremButton onGenerate={updateEditorContent} />
          <button
            onClick={triggerExport}
            disabled={isExporting}
            className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-800
                     text-white rounded-md shadow-sm transition-colors duration-200
                     flex items-center space-x-2"
          >
            {isExporting ? (
              <>
                <span className="animate-spin">↻</span>
                <span>Exporting...</span>
              </>
            ) : (
              'Export Annotations'
            )}
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="border border-gray-700 rounded-lg shadow-lg bg-gray-800">
            <div className="border-b border-gray-700 p-4">
              <h2 className="text-xl font-semibold text-white">Editor</h2>
              <p className="text-sm text-gray-400 mt-1">
                Select text to add annotations using the popup tools
              </p>
            </div>
            <MarkdownInlineEditor
              key={key} // Add key to force re-mount
              ref={editorRef}
              text={editorContent}
              onExport={handleExport}
              className="min-h-[600px]"
            />
          </div>

          <div className="border border-gray-700 rounded-lg shadow-lg bg-gray-800">
            <div className="border-b border-gray-700 p-4">
              <h2 className="text-xl font-semibold text-white">Annotated Markdown</h2>
              <p className="text-sm text-gray-400 mt-1">
                View the exported markdown with annotations
              </p>
            </div>
            <div className="relative">
              <pre className="p-4 whitespace-pre-wrap font-mono text-sm text-gray-300 max-h-[600px] overflow-auto">
                {annotatedMarkdown || 'Click "Export" to see the annotated markdown...'}
              </pre>
              {annotatedMarkdown && (
                <button
                  onClick={() => navigator.clipboard.writeText(annotatedMarkdown)}
                  className="absolute top-4 right-4 p-2 bg-gray-700 hover:bg-gray-600
                           rounded text-gray-300 text-sm transition-colors duration-200"
                  title="Copy to clipboard"
                >
                  Copy
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
