// Types for our recent items
type RecentItemType = 'project' | 'test';

type RecentItem = {
  id: string;
  type: RecentItemType;
  name: string;
  timestamp: number;
  projectId?: string; // Added for tests to reference their parent project
};

// Maximum number of recent items to store
const MAX_RECENT_ITEMS = 10;

// Key for storing recent items in local storage
const RECENT_ITEMS_KEY = 'gluRecentItems';

/**
 * Compare two RecentItems for equality
 * @param a First RecentItem to compare
 * @param b Second RecentItem to compare
 * @returns boolean indicating if the items are equal
 */
const isRecentItemEqual = (a: RecentItem, b: RecentItem): boolean => {
  return a.id === b.id && a.type === b.type;
};

/**
 * Add a project or test to the recent items list
 * @param item The item to add to the recents list
 */
export const addRecentItem = (item: RecentItem): void => {
  const recentItems = getRecentItems();

  // Remove any existing item with the same id and type
  const filteredItems = recentItems.filter(
    (existingItem) => !isRecentItemEqual(existingItem, item)
  );

  // Add the new item to the beginning of the list
  filteredItems.unshift(item);

  // If it's a test, ensure its parent project is also in the list
  if (item.type === 'test' && item.projectId) {
    const projectIndex = filteredItems.findIndex(
      (existingItem) => existingItem.type === 'project' && existingItem.id === item.projectId
    );
    if (projectIndex !== -1) {
      // Move the project to the front if it exists
      const [project] = filteredItems.splice(projectIndex, 1);
      filteredItems.unshift(project);
    }
  }

  // Trim to max size
  const trimmedItems = filteredItems.slice(0, MAX_RECENT_ITEMS);

  try {
    localStorage.setItem(RECENT_ITEMS_KEY, JSON.stringify(trimmedItems));
  } catch (error) {
    console.error('Error saving recent items to local storage:', error);
  }
};

/**
 * Retrieve the list of recent items from local storage
 * @returns An array of RecentItem objects
 */
export const getRecentItems = (): RecentItem[] => {
  try {
    const storedItems = localStorage.getItem(RECENT_ITEMS_KEY);
    if (!storedItems) {
      return [];
    }
    const parsedItems = JSON.parse(storedItems);
    if (!Array.isArray(parsedItems)) {
      throw new Error('Stored items are not in the expected format');
    }
    return parsedItems;
  } catch (error) {
    console.error('Error retrieving or parsing recent items from local storage:', error);
    return [];
  }
};

/**
 * Clear all recent items from local storage
 */
export const clearRecentItems = (): void => {
  try {
    localStorage.removeItem(RECENT_ITEMS_KEY);
  } catch (error) {
    console.error('Error clearing recent items from local storage:', error);
  }
};

/**
 * Remove a specific item from the recent items list
 * @param id The id of the item to remove
 * @param type The type of the item to remove
 */
export const removeRecentItem = (id: string, type: RecentItemType): void => {
  const recentItems = getRecentItems();
  const updatedItems = recentItems.filter((item) => !(item.id === id && item.type === type));

  try {
    localStorage.setItem(RECENT_ITEMS_KEY, JSON.stringify(updatedItems));
  } catch (error) {
    console.error('Error removing recent item from local storage:', error);
  }
};

/**
 * Check if local storage is available in the current environment
 * @returns boolean indicating if local storage is available
 */
export const isLocalStorageAvailable = (): boolean => {
  try {
    const testKey = '__test__';
    localStorage.setItem(testKey, testKey);
    localStorage.removeItem(testKey);
    return true;
  } catch (e) {
    return false;
  }
};

/**
 * Get recent tests for a specific project
 * @param projectId The id of the project
 * @returns An array of RecentItem objects representing tests for the given project
 */
export const getRecentTestsForProject = (projectId: string): RecentItem[] => {
  const recentItems = getRecentItems();
  return recentItems.filter((item) => item.type === 'test' && item.projectId === projectId);
};

/**
 * Add a recently visited test
 * @param testId The id of the test
 * @param testName The name of the test
 * @param projectId The id of the parent project
 */
export const addRecentTest = (testId: string, testName: string, projectId: string): void => {
  addRecentItem({
    id: testId,
    type: 'test',
    name: testName,
    timestamp: Date.now(),
    projectId: projectId
  });
};
