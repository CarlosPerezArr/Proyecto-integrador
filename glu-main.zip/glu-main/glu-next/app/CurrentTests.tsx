'use client';

import React, { useState } from 'react';
import PageCard from '@/app/components/PageCard';
import TabBar from '@/app/components/TabBar';
import { TabProps } from '@/app/components/TabBar';

const pageTabs: TabProps[] = [
  {
    title: 'List Tests',
    name: 'list'
  },
  {
    title: 'Import Tests',
    name: 'import'
  }
];

const CurrentTests: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabProps>(pageTabs[0]);

  return (
    <div>
      <TabBar tabs={pageTabs} selectedTab={pageTabs[0]} onClick={setActiveTab} />
      {activeTab.name === 'list' && (
        <PageCard title="Device Feature Tests">
          <div className="p-4">
            <p className="mb-4">There are currently no tests defined.</p>
            <a href="/copilot" className="btn btn-secondary">
              Generate new test
            </a>
          </div>
        </PageCard>
      )}

      {activeTab.name === 'import' && (
        <PageCard title="Import Tests">
          <div className="p-4">
            <p className="mb-4">Choose a file to import</p>
          </div>
        </PageCard>
      )}
    </div>
  );
};

export default CurrentTests;
