// FIXME: Leverage the generated client.
import { TestBenchDeviceRead } from '@/app/client';

export interface Device {
  id: number;
  name: string;
  description: string;
  manufacturer: string;
}

export interface DeviceSpec {
  id: number;
  device_under_test_id: number;
  s3_key: string;
  filename: string;
  function_specs?: FunctionSpec[];
}

export interface FunctionSpec {
  id: number;
  device_spec_id: number;
  name: string;
  original_text: string;
}

export interface Message {
  email: string;
  session_uuid: string;
  message_role: string;
  message_content: string;
  functionspec_id: number;
}

export interface Memory {
  deviceundertest_id: number;
  notes: string;
}

export interface WebSocketMessage {
  is_error: boolean;
  code: number;
  payload: WebSocketMessagePayload;
}

export interface WebSocketMessagePayload {
  event_type?: string;
  chosen_tools?: TestBenchDeviceRead[];
}

export interface AlertObject {
  type: 'error' | 'success' | 'warning' | 'info';
  message: string;
  onClick: () => void;
  autoClose?: boolean;
}
