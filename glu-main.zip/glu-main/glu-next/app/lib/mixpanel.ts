import Mixpanel from 'mixpanel';
import { UserRead } from '@/app/client';

const mixpanel = Mixpanel.init(<string>process.env.NEXT_PUBLIC_MIXPANEL_TOKEN);

/*
 * NOTE - we're using email as userid in mixpanel
 */

// ex:
// mixpanel.track('Signed Up', {
//   distinct_id: user_id,
//   'Signup Type': 'Referral'
// });
export function trackEvent(name: string, userEmail: string, properties?: any) {
  mixpanel.track(name, {
    distinct_id: userEmail,
    ...properties
  });
}

export function trackUser(user: UserRead) {
  mixpanel.people.set(user.email, {
    email: user.email,
    name: user.name
  });
}
