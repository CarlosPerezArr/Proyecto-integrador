import { WebSocketMessage } from '@/app/lib/definitions';

class LLMWebsocket {
  readonly maxConnectionTries: number = 4;
  readonly baseUri: string = process.env.NEXT_PUBLIC_API_WEBSOCKET_URL || '';

  protected url: string;

  protected connectionInProgress: boolean = false;
  protected connectionTries: number = 0;
  protected connection: WebSocket | null = null;

  payloadFn: (payload: any) => void;
  openFn: () => void;
  errorFn: (event: ErrorEvent) => void;
  closeFn: (event: CloseEvent) => void;

  protected cachedPayload: any | null = null;

  protected constructor(
    path: string,
    handleOpen?: () => void,
    handleError?: (event: ErrorEvent) => void,
    handleClose?: (event: CloseEvent) => void,
    handlePayload?: (payload: any) => void
  ) {
    this.url = `${this.baseUri}${path}`;
    this.openFn = handleOpen || (() => {});
    this.errorFn = handleError || (() => {});
    this.closeFn = handleClose || (() => {});
    this.payloadFn = handlePayload || (() => {});
  }

  private resetDefaults() {
    this.connectionInProgress = false;
    this.connectionTries = 0;
  }

  protected onOpen = () => {
    console.log('LLMWebsocket: Connection opened');
    this.resetDefaults();
    this.openFn();

    if (this.cachedPayload) {
      this.send(this.cachedPayload);
      this.cachedPayload = null;
    }
  };

  protected onMessage = (event: MessageEvent) => {
    console.log('LLMWebsocket: Message received', event.data);
    const message = JSON.parse(event.data) as WebSocketMessage;
    const isError = message.is_error;
    const payload = message.payload;
    // const code = message.code;

    if (isError) {
      this.onError(event);
      return;
    }

    if (payload) {
      this.payloadFn(payload);
      return;
    }
  };

  private onError = (event: Event) => {
    console.error('LLMWebsocket: Error', event);
    this.errorFn(event as ErrorEvent);
  };

  protected onClose = (event: CloseEvent) => {
    console.log('LLMWebsocket: Connection closed', event.wasClean ? 'clean' : 'unclean');
    this.closeFn(event);
    if (this.connectionTries < this.maxConnectionTries) {
      // console.log('LLMWebsocket: Reconnecting');
      // this.connectionInProgress = false;
      // this.connect(this.userFeedback);
    } else {
      console.log('LLMWebsocket: Max connection tries reached');
      this.connectionInProgress = false;
      this.resetDefaults();
    }
  };

  state() {
    if (!this.connection) return 'CLOSED';
    const states: { [key: number]: string } = {
      0: 'CONNECTING',
      1: 'OPEN',
      2: 'CLOSING',
      3: 'CLOSED'
    };
    return states[Number(this.connection.readyState)];
  }

  isConnecting() {
    return this.state() === 'CONNECTING';
  }

  isConnected() {
    return this.state() === 'OPEN';
  }

  isDisconnecting() {
    return this.state() === 'CLOSING';
  }

  isDisconnected() {
    if (!this.connection) return true;
    return this.state() === 'CLOSED';
  }

  connect() {
    if (this.connectionInProgress) return;
    if (this.connection && this.isConnected()) return;

    console.log('LLMWebsocket: Connecting');

    this.connectionInProgress = true;
    this.connectionTries = this.connectionTries + 1;
    this.connection = new WebSocket(this.url);
    this.connection.onopen = this.onOpen;
    this.connection.onmessage = this.onMessage;
    this.connection.onerror = this.onError;
    this.connection.onclose = this.onClose;
  }

  disconnect() {
    if (!this.connection) return;
    if (this.isDisconnected()) return;
    console.log('LLMWebsocket: Closing connection');
    this.connection.close();
  }

  send(payload: any) {
    if (!this.connection || this.isDisconnected()) {
      this.cachedPayload = payload;
      this.connect();
      return;
    }
    console.log('LLMWebsocket: Sending message', payload);
    this.connection.send(JSON.stringify(payload));
  }
}

export class PlanGeneratorWebsocket extends LLMWebsocket {
  constructor(functionSpecId: number) {
    super(`/testing_ws/function_specs/${functionSpecId}/test_plan`);
  }
}

export class PlanReviserWebsocket extends LLMWebsocket {
  constructor(testPlanId: number) {
    super(`/testing_ws/test_plans/${testPlanId}`);
  }
}

export class ToolPickerWebsocket extends LLMWebsocket {
  constructor(testPlanId: number) {
    super(`/testing_ws/test_plans/${testPlanId}/pick_em`);
  }
}

export interface MockResponse {
  response: WebSocketMessage;
  delay: number;
}

export class MockLLMWebsocket extends LLMWebsocket {
  private mockConnection: any;
  private responseQueue: MockResponse[];
  private queueIndex: number = 0;

  constructor(
    mockResponses: MockResponse[],
    handleOpen?: () => void,
    handleError?: (event: ErrorEvent) => void,
    handleClose?: (event: CloseEvent) => void,
    handlePayload?: (payload: any) => void
  ) {
    super('', handleOpen, handleError, handleClose, handlePayload);
    this.responseQueue = mockResponses;
  }

  connect() {
    if (this.connectionInProgress) return;
    console.log('MockLLMWebsocket: Connecting');

    this.connectionInProgress = true;
    this.queueIndex = 0;

    setTimeout(() => {
      this.mockConnection = {
        readyState: 1, // OPEN
        close: () => {
          this.mockConnection.readyState = 3; // CLOSED
          this.onClose(new CloseEvent('close', { wasClean: true }));
        }
      };

      this.onOpen();
      this.send();
    }, 100);
  }

  disconnect() {
    if (this.mockConnection) {
      this.mockConnection.close();
    }
  }

  send() {
    if (!this.mockConnection) {
      this.connect();
      return;
    }

    const sendNextResponse = () => {
      if (this.queueIndex >= this.responseQueue.length) return;

      const { response, delay } = this.responseQueue[this.queueIndex];
      setTimeout(() => {
        const event = new MessageEvent('message', {
          data: JSON.stringify(response)
        });
        this.onMessage(event);

        console.log('MockLLMWebsocket: Sending mock message', response);

        this.queueIndex++;
        if (this.queueIndex < this.responseQueue.length) {
          sendNextResponse();
        }
      }, delay);
    };

    sendNextResponse();
  }

  state() {
    if (!this.mockConnection) return 'CLOSED';
    const states: { [key: number]: string } = {
      0: 'CONNECTING',
      1: 'OPEN',
      2: 'CLOSING',
      3: 'CLOSED'
    };
    return states[this.mockConnection.readyState];
  }
}
