export const maxConnectionTries = 4;

export function getWebSocketState(key: number) {
  const states: { [key: number]: string } = {
    0: 'CONNECTING',
    1: 'OPEN',
    2: 'CLOSING',
    3: 'CLOSED'
  };
  return states[key];
}
