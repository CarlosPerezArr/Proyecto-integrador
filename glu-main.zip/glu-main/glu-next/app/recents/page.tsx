'use client';

import React, { useEffect, useState } from 'react';
import PageCard from '../components/PageCard';
import Link from 'next/link';
import { getRecentItems } from '../utils/localStorageUtils';

interface Test {
  id: string;
  name: string;
  lastVisited: string;
}

interface Project {
  id: string;
  name: string;
  lastVisited: string;
  tests: Test[];
}

const Recents: React.FC = () => {
  const [recentProjects, setRecentProjects] = useState<Project[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchRecentItems = () => {
      const recentItems = getRecentItems();
      const processedProjects = processRecentItems(recentItems);
      setRecentProjects(processedProjects);
      setIsLoading(false);
    };

    fetchRecentItems();
  }, []);

  const processRecentItems = (recentItems: any[]): Project[] => {
    const projectMap = new Map<string, Project>();

    recentItems.forEach((item) => {
      if (item.type === 'project' && item.name && item.name.trim() !== '') {
        projectMap.set(item.id, {
          id: item.id,
          name: item.name,
          lastVisited: item.timestamp.toString(),
          tests: []
        });
      } else if (item.type === 'test') {
        const projectId = item.projectId;
        const project = projectMap.get(projectId);

        // Only add tests to existing projects with valid names
        if (project && project.name && project.name !== 'Unknown Project') {
          project.tests.push({
            id: item.id,
            name: item.name,
            lastVisited: item.timestamp.toString()
          });
          // Update project's last visited time if the test is more recent
          if (new Date(item.timestamp) > new Date(project.lastVisited)) {
            project.lastVisited = item.timestamp.toString();
          }
        }
      }
    });

    // Filter out any remaining projects with invalid names
    const validProjects = Array.from(projectMap.values()).filter(
      (project) => project.name && project.name.trim() !== '' && project.name !== 'Unknown Project'
    );

    return validProjects.sort(
      (a, b) => new Date(b.lastVisited).getTime() - new Date(a.lastVisited).getTime()
    );
  };

  // Function to format date
  const formatDate = (dateString: string) => {
    return new Date(parseInt(dateString)).toLocaleString();
  };

  return (
    <PageCard title="Recent Projects">
      {isLoading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-gray-900"></div>
        </div>
      ) : (
        <div className="space-y-6">
          {recentProjects.length === 0 ? (
            <p className="text-center text-gray-500">No recent projects or tests found.</p>
          ) : (
            recentProjects.map((project) => (
              <div key={project.id} className="bg-base-200 p-4 rounded-lg shadow">
                <Link
                  href={`/projects/${project.id}`}
                  className="text-lg font-semibold hover:text-primary"
                >
                  {project.name}
                </Link>
                <p className="text-sm text-gray-500">
                  Last visited: {formatDate(project.lastVisited)}
                </p>
                {project.tests.length > 0 && (
                  <div className="mt-2 space-y-2">
                    <h4 className="text-md font-medium">Recent Tests:</h4>
                    {project.tests.map((test) => (
                      <div key={test.id} className="bg-base-100 p-2 rounded ml-4">
                        <Link
                          href={`/projects/${project.id}/features/${test.id}/test`}
                          className="text-md hover:text-secondary"
                        >
                          {test.name}
                        </Link>
                        <p className="text-xs text-gray-500">
                          Last visited: {formatDate(test.lastVisited)}
                        </p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      )}
    </PageCard>
  );
};

export default Recents;
