import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}'
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['var(--font-inter)', 'sans-serif'],
        mono: ['var(--font-fraktion)', 'sans-serif']
      }
    },
    fontSize: {
      '2xs': '0.625rem',
      xs: '0.75rem',
      sm: '0.875rem',
      base: '1rem',
      lg: '1.125rem',
      xl: '1.25rem',
      '2xl': '1.5rem',
      '3xl': '2rem',
      '4xl': '2.5rem',
      '5xl': '3rem'
    }
  },
  daisyui: {
    themes: [
      {
        dark: {
          ...require('daisyui/src/theming/themes')['dark'],
          primary: '#888DF5',
          'primary-content': '#0D0F11',
          secondary: '#26E19F',
          'secondary-content': '#0D0F11',
          neutral: '#828385',
          'neutral-content': '#FFFFFF',
          'base-100': '#0D0F11',
          'base-content': '#FFFFFF',
          'text-primary': '#FFFFFF',
          black: '#000000',
          white: '#FFFFFF',
          'grey-200': '#9CA3Af',
          success: '#26E19F'
        }
      }
    ]
  },
  plugins: [require('daisyui')],
  variants: {
    lineClamp: ['responsive', 'hover']
  }
};
export default config;
