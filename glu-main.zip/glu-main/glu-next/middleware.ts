import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

export function middleware(request: NextRequest) {
  const session = request.cookies.get('session');
  const forwardedHost = request.headers.get('X-Forwarded-Host');
  const nextUrl = request.nextUrl;
  const redirectTo = forwardedHost
    ? `${nextUrl.protocol}//${forwardedHost}${nextUrl.pathname}`
    : nextUrl.href;

  if (typeof session === 'undefined') {
    return NextResponse.redirect(
      `${process.env.NEXT_PUBLIC_API_URL}/login?redirect_to=${redirectTo}`
    );
  } else {
    console.log('Session found!');
  }
}
export const config = {
  // matcher solution for public, api, assets and _next exclusion
  matcher: '/((?!api|static|.*\\..*|_next).*)'
};
