import { defineConfig } from '@hey-api/openapi-ts';

export default defineConfig({
  input: 'http://localhost:3001/openapi.json',
  output: './app/client',
  client: 'axios',
  format: 'prettier',
  lint: 'eslint'
});
