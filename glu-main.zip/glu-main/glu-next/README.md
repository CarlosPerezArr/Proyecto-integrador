---
This is a [Next.js](https://nextjs.org/) project bootstrapped with [`create-next-app`](https://github.com/vercel/next.js/tree/canary/packages/create-next-app).

1. **Environment Management**

   1. Make sure you have latest [NodeJS](https://nodejs.org/en) installed

```bash
brew install node@23 (edited)
```

```bash
brew unlink node
```

```bash
brew link node@23
```

2. **Clone the Repository**

    If you haven't already, clone the repository to your local machine: `git clone git@github.com:PioneerSquareLabs/glu.git`

3. **Environment Variables**

   The Next application expects certain environment variables to be defined. During development, you can define a
   `.env` file in the `glu-next` directory and NodeJS will automatically detect it and supply them for you.

   It should have the following entries:

    ```
    AUTH0_ALGORITHMS=
    AUTH0_API_AUDIENCE=
    AUTH0_CLIENT_ID=
    AUTH0_CLIENT_SECRET=
    AUTH0_DOMAIN=
    AUTH0_ISSUER=
    NEXT_PUBLIC_MIXPANEL_TOKEN=
    NEXT_PUBLIC_API_URL=
    NEXT_PUBLIC_API_WEBSOCKET_URL=
    OPENAI_API_KEY=
    SENTRY_AUTH_TOKEN=
    SQLALCHEMY_URL=
    ```

4. **Install Dependencies**

```bash
rm -rf node_modules/
```

```bash
rm package-lock.json
```

```bash
npm cache clean --force
```

```bash
rm -rf .next/
```

```bash
npm install
```

### Do the below ONLY if the Python API endpoints have changed

5. **Generate API Client**

The project uses OpenAPI TypeScript client generation. To regenerate the API client after backend changes:

```bash
npm run generate-client
```

Note: After generation, ensure the OpenAPI configuration in `glu-next/app/client/core` is updated to:

```typescript
export const OpenAPI: OpenAPIConfig = {
    BASE: process.env.NEXT_PUBLIC_API_URL ?? '',
    CREDENTIALS: 'include',
    ENCODE_PATH: undefined,
    HEADERS: undefined,
    PASSWORD: undefined,
    TOKEN: undefined,
    USERNAME: undefined,
    VERSION: '0.1.0',
    WITH_CREDENTIALS: true,
    interceptors: {
        request: new Interceptors(),
        response: new Interceptors()
    }
};
```

6. **Run the App**

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

See the FastAPI README about setting up Ngrok

### Troubleshooting

**Invalid Host Error**

If you run into Invalid host header error then make sure the API ngrok is set up correctly, look at the python log statements. Don't be like Will and put your .env file one level too high and have it try to access incorrect environment variables.

**API Client Generation**

If you encounter issues with API client generation:
1. Ensure your FastAPI server is running and accessible
2. Verify the `NEXT_PUBLIC_API_URL` environment variable is correctly set
3. Check that the FastAPI server has CORS properly configured for your Next.js development server
