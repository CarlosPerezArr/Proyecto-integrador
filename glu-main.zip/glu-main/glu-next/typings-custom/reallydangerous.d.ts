declare module 'reallydangerous';
