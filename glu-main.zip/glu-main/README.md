# GLU Platform

## Overview

GLU (Glue) is a sophisticated software ecosystem designed to streamline the management and testing of devices and their specifications. It combines a Next.js frontend with a FastAPI backend, creating a seamless interface for users to interact with laboratory equipment, manage device specifications, and execute test plans.

## Key Features

- Multi-tenant architecture supporting multiple organizations
- Device and specification management
- AI-assisted test plan and script generation
- Real-time file uploads and processing
- Comprehensive test planning and execution tools
- Integration with external services (AWS, OpenAI)

## Adding a New Tenant

In order to add a new Tenant, complete the following steps

1. Log into https://manage.auth0.com/dashboard/us/glutest/organizations
2. Create a new Organization (add name and Display name)
3. (Optional) Update Organization with branding
4. Navigate to Connections and click "Enable Connections"
5. Select "Username-Password-Authentication" and click "Enable Connection"
6. Keep other settings the same
7. In "Invitations" tab, send invitations to testers
8. In the glu-fastapi/glu_fastapi directory run the following command:
```console
poetry run python commands.py create-tenant --name=[NAME e.g. acme] --schema=[SCHEMA_NAME e.g. acme] --host=[SCHEMA_NAME e.g. acme].glutest.ai --org-id=[Auth0 Org ID e.g. org_tHDRGnFXv8gHBRyb]
```
9. Add a CNAME record at namecheap to match the above host
10. Add a custom domain in Render https://dashboard.render.com/web/srv-cojtj3ocmk4c73c3mamg/settings
11. Run the Alembic migration
```console
poetry run alembic -x tenant="[SCHEMA_NAME e.g. acme]" upgrade head
```
12. Add a user to the new tenant and test to make sure everything works correctly.

## Documentation

For detailed information about different aspects of the GLU platform, please refer to the following documentation:

- [Database Documentation](documentation/database.md)
- [Frontend Documentation](documentation/frontend.md)
- [Backend Documentation](documentation/backend.md)
- [AI Integration Documentation](documentation/ai_integration.md)
- [Deployment Documentation](documentation/deployment.md)
- [User Guide](documentation/user_guide.md)

## Getting Started

### Prerequisites

- Node.js (version specified in `glu-next/package.json`)
- Python 3.11
- PostgreSQL (for production) or SQLite (for development)
- AWS account (for S3 storage)
- OpenAI API key

### Setup

1. Clone the repository:
   ```
   git clone ...
   cd glu-platform
   ```

2. Set up the frontend:
   ```
   cd glu-next
   npm install
   ```

3. Set up the backend:
   ```
   cd ../glu-fastapi
   pip install poetry
   poetry install
   ```

4. Configure environment variables:
   - Create `.env` files in both `glu-next` and `glu-fastapi/glu_fastapi` directories
   - Add necessary environment variables (refer to the deployment documentation for details)

5. Start the development servers:
   - Frontend: `npm run dev` in the `glu-next` directory
   - Backend: `poetry run uvicorn main:app --reload` in the `glu-fastapi` directory

For more detailed instructions on deployment and configuration, please refer to the [Deployment Documentation](documentation/deployment.md).


---

Thank you for your interest in the GLU platform. We hope this tool enhances your device management and testing processes!
