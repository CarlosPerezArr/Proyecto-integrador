#! /bin/sh

git checkout main && git pull && git checkout develop && git pull && punch --action build && git push && git checkout main && git push && git push --tags ; git checkout develop && git pull
