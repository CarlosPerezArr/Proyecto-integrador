"""Test suite for GLU."""

import random
import uuid
from typing import AsyncGenerator, Generator, List

import structlog
from httpx import AsyncClient

import pytest

from sqlalchemy import text
from sqlmodel import Session, SQLModel, create_engine
from starlette import status

from glu_fastapi.config import Settings
from glu_fastapi.under_test.models import DeviceUnderTest, DeviceSpec, DeviceSpecChunk
from glu_fastapi.shared_models import Tenant  # noqa
from glu_fastapi.auth import User, require_logged_in_user
from glu_fastapi.database.session import get_sqlmodel_session
from glu_fastapi.main import app

logger = structlog.get_logger()
glu_settings = Settings()
# The next little bit is overriding the standard DB with the connection info for the test DB.
SQLALCHEMY_DATABASE_URL = glu_settings.test_sqlalchemy_url
glu_settings.sqlalchemy_url = glu_settings.test_sqlalchemy_url
engine = create_engine(SQLALCHEMY_DATABASE_URL).execution_options(
    schema_translate_map={
        None: "test",
    }
)
with engine.connect() as connection:
    connection.execute(text("CREATE SCHEMA IF NOT EXISTS test AUTHORIZATION glu_test;"))
    connection.execute(
        text("CREATE SCHEMA IF NOT EXISTS shared AUTHORIZATION glu_test;")
    )
    connection.commit()
SQLModel.metadata.drop_all(bind=engine)
SQLModel.metadata.create_all(bind=engine)


@pytest.fixture(scope="session")
def testing_sqlsession() -> Generator[Session, None, None]:
    """Fetch a SQLModel ``Session`` for use in our tests."""
    with Session(engine) as session:

        def get_session():
            yield session

        app.dependency_overrides[get_sqlmodel_session] = get_session

        try:
            yield session
        finally:
            session.rollback()

        del app.dependency_overrides[get_sqlmodel_session]


def get_testing_user() -> User:
    """Get a ``User`` so the tests look like they logged in."""
    return User(
        name="Bob Chipeska",
        email="bob.chipeska@saguarosquare.com",
        email_verified=True,
        scopes=[],
        org_id="kq8lbzlyRAi7CfDAcUf5mTHr4NJoUNxJ",  # 🎼random.org! We bring the random to you!🎶
    )


app.dependency_overrides[require_logged_in_user] = get_testing_user


@pytest.fixture(scope="function")
def device_under_test(
    testing_sqlsession: Generator[Session, None, None],
) -> DeviceUnderTest:
    device = DeviceUnderTest(
        name="Pip-Boy 2000",
        manufacturer="RobCo Industries",
        description="""
A cumbersome, wrist-mounted device utilizing modern cathode ray tube monitors in green monochrome for high resolution
display of its contents.
                    """,
    )
    testing_sqlsession.add(device)
    testing_sqlsession.flush()
    return device


@pytest.fixture(scope="function")
def device_spec(
    testing_sqlsession: Generator[Session, None, None],
    device_under_test: DeviceUnderTest,
    faker,
) -> DeviceSpec:
    spec = DeviceSpec(
        s3_key=f"{faker.url(schemes='s3')}/{faker.first_name()}/{uuid.uuid4()}",
        filename=faker.file_name(),
        device_under_test=device_under_test,
    )
    testing_sqlsession.add(spec)
    testing_sqlsession.flush()
    return spec


@pytest.fixture(scope="function")
def device_spec_chunks(
    testing_sqlsession: Generator[Session, None, None], device_spec: DeviceSpec, faker
) -> List[DeviceSpecChunk]:
    chunks = []
    # Each spec is going to have a random number of pages.
    for page_num in range(1, random.randint(1, 69)):
        # And each page will have a random number of chunks on it.
        for chunk_num in range(1, random.randint(1, 3)):
            fake_metadata = {
                "emphasized_text_contents": [
                    "DISTRIBUTION:",
                    "Per notification document",
                    "xxxxx",
                    ".",
                    "ORIGINAL APPROVAL:",
                ],
                "emphasized_text_tags": ["b", "b", "b", "b", "b"],
                "filename": device_spec.filename,
                "filetype": faker.mime_type(),
                "languages": ["eng"],
                "page_number": page_num,
            }

            chunk = DeviceSpecChunk(
                device_spec=device_spec,
                element_id=str(uuid.uuid4()),
                chunk_metadata=fake_metadata,
                chunk_text=faker.text(),
            )
            chunks.append(chunk)
            testing_sqlsession.add(chunk)
    testing_sqlsession.flush()
    return chunks


@pytest.fixture(scope="function")
async def test_client() -> AsyncGenerator[AsyncClient, None]:
    async with AsyncClient(app=app, base_url="http://test") as atc:
        yield atc


# In case you're wondering, ``faker`` is a Pytest fixture that comes from the Faker library. It comes "for free" when
# we ``import pytest``.
@pytest.mark.asyncio
async def test_langchain_hello(test_client, faker):
    async for client in test_client:
        name = faker.name()
        response = await client.get(f"/langchain_hello/{name}")
        assert response is not None
        assert response.status_code == status.HTTP_200_OK
        assert name.casefold() in response.text.casefold()
        await client.aclose()


class TestDeviceUnderTest:
    @pytest.mark.asyncio
    async def test_update_device_under_test_happy_path(
        self, device_under_test, test_client, faker
    ):
        async for client in test_client:
            url = app.url_path_for(
                "update_device_under_test", device_id=device_under_test.id
            )
            data_to_put = device_under_test.model_dump()
            new_description = faker.text()
            data_to_put["description"] = new_description
            response = await client.put(
                url,
                json=data_to_put,
            )
            assert response is not None
            assert response.status_code == status.HTTP_200_OK
            assert response.json()["name"] == device_under_test.name
            assert response.json()["description"] == new_description
            await client.aclose()

    @pytest.mark.asyncio
    async def test_view_device_under_test_not_found(self, test_client):
        async for client in test_client:
            url = app.url_path_for("view_device_under_test", device_id=-1)
            response = await client.get(url)
            assert response is not None
            assert response.status_code == status.HTTP_404_NOT_FOUND
            await client.aclose()

    @pytest.mark.asyncio
    async def test_view_device_under_test_happy_path(
        self, device_under_test, test_client
    ):
        async for client in test_client:
            url = app.url_path_for(
                "view_device_under_test", device_id=device_under_test.id
            )
            response = await client.get(url)
            assert response is not None
            assert response.status_code == status.HTTP_200_OK
            assert response.json()["name"] == device_under_test.name
            await client.aclose()

    @pytest.mark.asyncio
    async def test_delete_device_under_test_happy_path(
        self, device_under_test, test_client
    ):
        async for client in test_client:
            url = app.url_path_for(
                "delete_device_under_test", device_id=device_under_test.id
            )
            response = await client.delete(url)
            assert response is not None
            assert response.status_code == status.HTTP_204_NO_CONTENT
            await client.aclose()

    @pytest.mark.asyncio
    async def test_delete_device_under_test_no_device(self, test_client):
        async for client in test_client:
            url = app.url_path_for(
                "delete_device_under_test",
                device_id=-1,
            )
            response = await client.delete(url)
            assert response is not None
            assert response.status_code == status.HTTP_204_NO_CONTENT
            await client.aclose()


class TestTestBenchDevice:
    @pytest.mark.asyncio
    async def test_create_happy_path(self, test_client, faker):
        async for client in test_client:
            url = app.url_path_for("create_test_bench_device")
            response = await client.post(
                url,
                json={
                    "name": faker.vin(),
                    "manufacturer": faker.company(),
                    "description": faker.text(),
                },
            )
            assert response is not None
            assert response.status_code == status.HTTP_201_CREATED
            assert "id" in response.json().keys()
            await client.aclose()

    @pytest.mark.asyncio
    async def test_create_invalid_name(self, test_client, faker):
        async for client in test_client:
            url = app.url_path_for("create_test_bench_device")
            response = await client.post(
                url,
                json={
                    "name": False,
                    "manufacturer": faker.company(),
                    "description": faker.text(),
                },
            )
            assert response is not None
            assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY
            await client.aclose()

    @pytest.mark.asyncio
    async def test_create_invalid_manufacturer(self, test_client, faker):
        async for client in test_client:
            url = app.url_path_for("create_test_bench_device")
            response = await client.post(
                url,
                json={
                    "name": faker.vin(),
                    "manufacturer": False,
                    "description": faker.text(),
                },
            )
            assert response is not None
            assert response.status_code == status.HTTP_422_UNPROCESSABLE_ENTITY
            await client.aclose()


class TestDeviceSpecChunk:
    @pytest.mark.asyncio
    async def test_list_chunks_for_device_spec_all_pages(
        self, test_client, device_spec_chunks
    ):
        async for client in test_client:
            first_chunk = device_spec_chunks[0]
            url = app.url_path_for(
                "list_chunks_for_device_spec",
                device_id=first_chunk.device_spec.device_under_test_id,
                device_spec_id=first_chunk.device_spec_id,
            )
            response = await client.get(url, params={"limit": len(device_spec_chunks)})
            assert response is not None
            assert response.status_code == status.HTTP_200_OK
            assert len(response.json()) == len(device_spec_chunks)

    @pytest.mark.asyncio
    async def test_list_chunks_for_device_spec_filtered_by_page_number(
        self, test_client, device_spec_chunks
    ):
        async for client in test_client:
            first_chunk = device_spec_chunks[0]
            available_page_numbers = [chunk.page_number for chunk in device_spec_chunks]
            random_number_of_pages = random.randint(1, max(available_page_numbers))
            random_sampling_of_page_numbers = random.choices(
                available_page_numbers, k=random_number_of_pages
            )
            url = app.url_path_for(
                "list_chunks_for_device_spec",
                device_id=first_chunk.device_spec.device_under_test_id,
                device_spec_id=first_chunk.device_spec_id,
            )
            response = await client.get(
                url,
                params={
                    "limit": len(device_spec_chunks),
                    "requested_page_numbers": random_sampling_of_page_numbers,
                },
            )
            assert response is not None
            assert response.status_code == status.HTTP_200_OK
            chunk_models = [
                DeviceSpecChunk.model_validate(dict_from_json)
                for dict_from_json in response.json()
            ]
            returned_page_numbers = [chunk.page_number for chunk in chunk_models]
            for page_num in returned_page_numbers:
                assert page_num in random_sampling_of_page_numbers
