"""ToC page_number -> section_page_number

Revision ID: b48adac800f7
Revises: 3b667f2a220f
Create Date: 2024-07-02 15:44:07.827843+00:00

"""

from typing import Sequence, Union

from alembic import op

# revision identifiers, used by Alembic.
revision: str = "b48adac800f7"
down_revision: Union[str, None] = "3b667f2a220f"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.alter_column(
        "devicespectocentry",
        "page_number",
        new_column_name="section_page_number",
    )


def downgrade() -> None:
    op.alter_column(
        "devicespectocentry",
        "section_page_number",
        new_column_name="page_number",
    )
