"""Add concept of AiMemory.

Revision ID: 91cd4ea6494b
Revises: 53fce2547c30
Create Date: 2024-04-29 13:01:55.620244+00:00

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
import sqlmodel


# revision identifiers, used by Alembic.
revision: str = "91cd4ea6494b"
down_revision: Union[str, None] = "53fce2547c30"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "aimemory",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("notes", sqlmodel.sql.sqltypes.AutoString(), nullable=False),
        sa.Column("deviceundertest_id", sa.Integer(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["deviceundertest_id"],
            ["deviceundertest.id"],
        ),
    )

    (
        op.create_index(
            "ix_aimemory_deviceundertest_id",
            "aimemory",
            [
                "deviceundertest_id",
            ],
            unique=True,
        ),
    )


def downgrade() -> None:
    op.drop_index("aimemory_deviceundertest_id", table_name="aimemory")
    op.drop_table("aimemory")
