"""Add concept of AiMessage.

Revision ID: 53fce2547c30
Revises: 1ed04666d5c1
Create Date: 2024-04-29 01:21:38.845709+00:00

"""

from typing import Sequence, Union

from alembic import op
import pgvector
import sqlalchemy as sa

from glu_fastapi.ai.models import AiMessageRole

# revision identifiers, used by Alembic.
revision: str = "53fce2547c30"
down_revision: Union[str, None] = "1ed04666d5c1"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "aimessage",
        sa.Column("email", sa.String(length=320), nullable=False),
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("session_uuid", sa.Uuid(), nullable=False),
        sa.Column("message_role", sa.Enum(AiMessageRole), nullable=False),
        sa.Column("message_content", sa.Text(), nullable=False),
        sa.Column("functionspec_id", sa.Integer(), nullable=False),
        sa.Column(
            "created_at",
            sa.TIMESTAMP(timezone=True),
            nullable=False,
            server_default=sa.text("CURRENT_TIMESTAMP"),
        ),
        sa.Column(
            "msg_embeddings", pgvector.sqlalchemy.Vector(dim=1536), nullable=True
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["functionspec_id"],
            ["functionspec.id"],
        ),
    )

    (
        op.create_index(
            "aimessage_email_created_at",
            "aimessage",
            [
                "email",
                "created_at",
            ],
        ),
    )
    (
        op.create_index(
            "aimessage_session_uuid_created_at",
            "aimessage",
            [
                "session_uuid",
                "created_at",
            ],
        ),
    )
    (
        op.create_index(
            "aimessage_functionspec_id_created_at",
            "aimessage",
            [
                "functionspec_id",
                "created_at",
            ],
        ),
    )

    op.create_index(
        "aimessage_msg_embeddings_index",
        "aimessage",
        ["msg_embeddings"],
        unique=False,
        postgresql_using="hnsw",
        postgresql_with={"m": 16, "ef_construction": 64},
        postgresql_ops={"msg_embeddings": "vector_cosine_ops"},
    )


def downgrade() -> None:
    op.drop_index("aimessage_msg_embeddings_index", table_name="aimessage")
    op.drop_index("aimessage_functionspec_id_created_at_index", table_name="aimessage")
    op.drop_index("aimessage_session_uuid_created_at_index", table_name="aimessage")
    op.drop_index("aimessage_email_created_at_index", table_name="aimessage")
    op.drop_table("aimessage")
