"""Add vector index on devicespecchunk.embeddings

Revision ID: e08ee345d422
Revises: e11c0cb85601
Create Date: 2024-03-13 01:05:05.086760+00:00

"""

from typing import Sequence, Union

from alembic import op


# revision identifiers, used by Alembic.
revision: str = "e08ee345d422"
down_revision: Union[str, None] = "e11c0cb85601"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_index(
        "devicespecchunk_embeddings_index",
        "devicespecchunk",
        ["chunk_embeddings"],
        unique=False,
        postgresql_using="hnsw",
        postgresql_with={"m": 16, "ef_construction": 64},
        postgresql_ops={"chunk_embeddings": "vector_cosine_ops"},
    )


def downgrade() -> None:
    op.drop_index("devicespecchunk_embeddings_index")
