"""Add filename column to devicespec

Revision ID: 4fc372d72612
Revises: e08ee345d422
Create Date: 2024-04-26 01:59:30.093735+00:00

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = "4fc372d72612"
down_revision: Union[str, None] = "e08ee345d422"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column(
        "devicespec", sa.Column("filename", sa.String(length=1024), nullable=True)
    )


def downgrade() -> None:
    op.drop_column(
        "devicespec",
        "filename",
    )
