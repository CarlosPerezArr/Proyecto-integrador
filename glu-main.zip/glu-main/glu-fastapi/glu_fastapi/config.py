import re
from functools import lru_cache
from typing import Literal, Annotated, Optional

from fastapi import Depends
from pydantic import SecretStr, Field, field_validator
from pydantic_core.core_schema import ValidationInfo
from pydantic_settings import BaseSettings, SettingsConfigDict

_SQL_ALCHEMY_URL_PARSER = re.compile(
    # r"^(?:[\w\s]+\s+)?(?P<dialect>\w+):\/\/(?P<user>[\w:.\-]+):(?P<password>[\w:.\-]+)@(?P<host>[\w\-.]+)(:(?P<port>\d+))?\/(?P<dbname>\w+)$"
    r"(?P<dbms>\w+)\+(?P<dialect>\w+)://(?P<user>[\w:.\-]+):(?P<password>[\w:.\-]+)@(?P<host>[\w\-.]+)(:(?P<port>\d+))?/(?P<dbname>\w+)"
)


class Settings(BaseSettings):
    """Settings for GLU."""

    model_config = SettingsConfigDict(env_file=".env")

    sqlalchemy_url: str = (
        "postgresql+psycopg://glu_test:yzZfUjSUbdLbPUKCHDxY6z@localhost:5432/glu_test"
    )
    psycopg_url: Optional[str] = Field(default=None)

    # NOTE: Yes, that's a password. I determined it was alright, because this is the test user, who only has access to
    # the test database, which gets created and blown away repeatedly, and never exists on a shared server.
    test_sqlalchemy_url: str = (
        "postgresql+psycopg://glu_test:yzZfUjSUbdLbPUKCHDxY6z@localhost:5432/glu_test"
    )
    aws_access_key_id: str = "https://example.org"
    aws_secret_access_key: str = "https://example.org"
    aws_default_region: str = "us-west-2"
    openai_api_key: str = "https://example.org"
    openai_log: str = "False"
    unstructuredio_api_key: str = "https://example.org"
    unstructuredio_server_url: str = "https://example.org"
    glu_bucket: str = "glu-specs"
    auth0_domain: str = "https://example.org"
    auth0_api_audience: str = "https://example.org"
    auth0_issuer: str = "https://example.org"
    auth0_algorithms: str = "https://example.org"
    auth0_client_id: str = "https://example.org"
    auth0_client_secret: str = "https://example.org"
    langchain_tracing_v2: bool = False
    langchain_api_key: SecretStr = "API_KEY_GOES_HERE"
    hosting_env: Literal["test", "development", "production"] = "production"
    mixpanel_token: str = "https://example.org"

    @field_validator("psycopg_url", mode="before")
    @classmethod
    def assemble_psycopg_url(cls, v: Optional[str], values: ValidationInfo) -> str:
        if v is None:
            url = values.data["sqlalchemy_url"]
            m = _SQL_ALCHEMY_URL_PARSER.match(url)
            host_and_optionally_port = f"host={m.group('host')}"
            if m.group("port") is not None:
                host_and_optionally_port += f" port={m.group('port')}"
            return f"user={m.group('user')} password={m.group('password')} {host_and_optionally_port} dbname={m.group('dbname')}"
        return v


@lru_cache
def glu_settings() -> Settings:
    """Settings for use by the API endpoints."""
    return Settings()  # type: ignore


SettingsDep = Annotated[Settings, Depends(glu_settings)]
