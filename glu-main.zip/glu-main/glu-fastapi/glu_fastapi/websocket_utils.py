"""Classes/functions that are used by all websocket-based routing."""

from enum import StrEnum, auto
from typing import Any, Dict, Optional, Self

from fastapi import status
from pydantic import BaseModel, model_validator, computed_field
from starlette.websockets import WebSocket


class SocketResponse(BaseModel):
    is_error: bool
    code: int
    payload: Any | None


class ClientEventType(StrEnum):
    """The official list of events the client can signal to us."""

    tools_accepted = auto()
    tools_retry = auto()
    steps_retry = auto()
    steps_accepted = auto()


class ClientEvent(BaseModel):
    event_type: ClientEventType


class ClientEventWithUserFeedback(ClientEvent):
    user_feedback: Optional[str] = None
    user_annotations: Optional[str] = None

    @model_validator(mode="after")
    def at_least_one_piece_of_feedback(self) -> Self:
        """Ensure that at least one piece of feedback is provided."""
        general_feedback = (self.user_feedback or "").strip()
        specific_annotations = (self.user_annotations or "").strip()
        if len(general_feedback) == 0 and len(specific_annotations) == 0:
            raise ValueError(
                "At least one of 'user_feedback' or 'user_annotations' must be provided."
            )

        return self

    @computed_field
    @property
    def has_general_feedback(self) -> bool:
        return self.user_feedback is not None and len(self.user_feedback.strip()) > 0

    @computed_field
    @property
    def has_specific_annotations(self) -> bool:
        return (
            self.user_annotations is not None and len(self.user_annotations.strip()) > 0
        )


class ServerEventType(StrEnum):
    steps_persisted = auto()
    steps_generated = auto()
    tools_suggested = auto()
    test_bench_persisted = auto()
    features_extracted = auto()
    feature_extracted = auto()
    page_processed = auto()
    document_processed = auto()


class ServerEvent(BaseModel):
    event_type: ServerEventType


# def get_param[T](ws: WebSocket) -> T:
async def get_param(ws: WebSocket, param_name: str, max_retries: int = 3) -> Any:
    attempt_counter: int = 0
    while attempt_counter < max_retries:
        try:
            attempt_counter += 1
            metadata: Dict[Any, Any] = await ws.receive_json()
            # param_value: T = metadata[param_name]
            param_value: Any = metadata[param_name]
        except Exception as e:
            errors = [getattr(e, "message", repr(e))]
            await ws.send_text(
                SocketResponse(
                    is_error=True,
                    code=status.HTTP_404_NOT_FOUND,
                    payload={"errors": errors},
                ).model_dump_json()
            )
        else:
            await ws.send_text(
                SocketResponse(
                    is_error=False,
                    code=status.HTTP_204_NO_CONTENT,
                    payload=None,
                ).model_dump_json()
            )
            return param_value
    return KeyError(param_name)
