from typing import List, Optional

from glu_fastapi.lab_bench.models import (
    TestBenchDeviceRead,
    TestBenchDeviceWithFeedback,
)
from pydantic import BaseModel, Field

from glu_fastapi.test_plan.models import TestPlanForLlm


class ResponseWithUserNotes(BaseModel):
    """Pydantic model of an LLM response that includes user notes."""

    new_user_notes: Optional[str] = Field(
        description="Notes the LLM extracted from user input.", default=None
    )


class ToolPickerResponse(ResponseWithUserNotes):
    """Pydantic model of an LLM response to a tool-picking request."""

    description: str = Field(
        description="A README markdown formatted response that contains a narrative about whether the tools we have are sufficient, and how they will be used. This should be high level."
    )

    missing_tools: List[TestBenchDeviceWithFeedback] = Field(
        description='List of devices that are required but not currently available in the test bench. For each item, give a specific make and model that would meet this purpose.  Please suggest "A tool like [Tool Name]" and explain why that is the right tool based on its characteristics.',
        default_factory=list,
    )
    present_tools: List[TestBenchDeviceWithFeedback] = Field(
        description="List of devices that are currently available in the test bench. Wherever possible, use a tool that we already have!!!",
        default_factory=list,
    )


class StepsGeneratorResponse(ResponseWithUserNotes):
    """Pydantic model of an LLM response to a step-generating request."""

    test_plan: Optional[TestPlanForLlm] = Field(
        description="The steps the LLM chose for testing.",
        default=None,
    )


class ToolList(BaseModel):
    """Pydantic model of a list of test bench tools to send to the LLM."""

    available_tools: List[TestBenchDeviceRead] = Field(
        description="The tools available for the LLM to choose."
    )
