"""Collection of service objects for driving the copilot."""

from json import JSONDecodeError
from typing import Awaitable, Callable, Tuple

import structlog
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import (
    BaseMessage,
    ToolMessage,
    HumanMessage,
    SystemMessage,
)
from langchain_core.output_parsers import JsonOutputParser
from pydantic import BaseModel
from sqlmodel import Session

from glu_fastapi import prompts
from glu_fastapi.ai.services import AiMemoryService
from glu_fastapi.bookworm import Feature
from glu_fastapi.copilot.models import (
    StepsGeneratorResponse,
    ToolPickerResponse,
    ToolList,
)
from glu_fastapi.lab_bench.services import TestBenchDeviceService
from glu_fastapi.test_plan.models import TestPlan
from glu_fastapi.under_test.models import FunctionSpec

logger = structlog.get_logger()


class ToolsService:
    """Business logic related to choosing the ``TestBenchDevice``s (via LLM) required to execute a specific ``TestPlan``."""

    async def build_system_message(
        self, llm: BaseChatModel, sql_session: Session
    ) -> SystemMessage:
        """Build the ``SystemMessage`` used in the tool selection process."""
        system_message = await _get_tools_system_message(
            sql_session, llm, ToolPickerResponse
        )
        return system_message

    async def handle_llm_response(
        self,
        last_msg: BaseMessage,
    ) -> ToolPickerResponse:
        """Given the last message from the LLM and the ``FunctionSpec`` to which it relates, build a proposed ``TestPlan`` and return it, along with any notes the LLM thinks we should remember for the future."""
        logger.debug(
            "OK, now the last message looks like this:",
            type_of_response=type(last_msg),
            last_msg=last_msg,
        )

        tpr: ToolPickerResponse | None = None
        if isinstance(last_msg, ToolMessage):
            tpr: ToolPickerResponse = ToolPickerResponse.model_validate_json(
                last_msg.content
            )
        elif isinstance(last_msg.content, dict):
            tpr = ToolPickerResponse.model_validate(last_msg.content["test_plan"])

        if tpr is None:
            tpr = ToolPickerResponse()
        return tpr

    async def build_human_message(
        self, sql_session: Session, tp: TestPlan
    ) -> HumanMessage:
        fut = tp.function_spec
        dut = fut.device_spec.device_under_test
        fut_overview, fut_title = await get_overview_and_title_from_function_spec(fut)
        tbd_service = TestBenchDeviceService(sql_session)
        available_tools_json = (
            await tbd_service.get_all_available_tools_as_json_string()
        )
        human_message = prompts.tool_picker_two_point_oh_human_message(
            dut_name=dut.name,
            fut_name=fut_title,
            fut_overview=fut_overview,
            current_version_of_the_steps=tp.full_text,
            tool_list_schema=ToolList.model_json_schema(),
            available_tools_json_string=available_tools_json,
        )
        logger.info(
            "Here's the human message we will send.",
            formatted_human_msg=human_message.content,
        )
        return human_message


class StepsService:
    """Business logic related to the generation of test steps via LLM."""

    async def build_system_message(
        self,
        llm: BaseChatModel,
        sql_session: Session,
    ) -> SystemMessage:
        """Build the ``SystemMessage`` used in the steps generation/editing process."""
        system_message = await _get_steps_system_message(
            sql_session, llm, StepsGeneratorResponse
        )
        return system_message

    async def handle_steps_generator_llm_response(
        self,
        fut: FunctionSpec,
        last_msg: BaseMessage,
    ) -> Tuple[TestPlan, str]:
        """Given the last message from the LLM and the ``FunctionSpec`` to which it relates, build a proposed ``TestPlan`` and return it, along with any notes the LLM thinks we should remember for the future."""
        logger.debug(
            "OK, now the last message looks like this:",
            type_of_response=type(last_msg),
            last_msg=last_msg,
        )
        extracted_notes: str | None = None
        if isinstance(last_msg, ToolMessage):
            sgr: StepsGeneratorResponse = StepsGeneratorResponse.model_validate_json(
                last_msg.content
            )
            last_tp: TestPlan = TestPlan(
                id=-1,
                function_spec_id=fut.id,
                full_text=sgr.test_plan.full_text,
            )
            if sgr.new_user_notes is not None and sgr.new_user_notes != "":
                extracted_notes = sgr.new_user_notes
        elif isinstance(last_msg.content, dict):
            sgr = StepsGeneratorResponse.model_validate(last_msg.content["test_plan"])
            last_tp = TestPlan(
                id=-1,
                function_spec_id=fut.id,
                full_text=sgr.test_plan.full_text,
            )
            if sgr.new_user_notes is not None and sgr.new_user_notes != "":
                extracted_notes = sgr.new_user_notes
        else:
            last_tp = TestPlan(
                id=-1,
                function_spec_id=fut.id,
                full_text="" if last_msg is None else last_msg.content,
            )

        # TODO: Here need to make sure our full_text is actually JSON and not an escaped string

        return last_tp, extracted_notes


async def get_overview_and_title_from_function_spec(
    fut: FunctionSpec,
) -> Tuple[str, str]:
    # For backward-compatibility with ``FunctionSpec``s derived before the big Bookworm rewrite, we default to the ``title`` of the ``FunctionSpec`` and an empty string.
    fut_title = fut.name
    fut_overview = ""

    # With our fallbacks in place, we can try overwriting those values with information extracted from the new ``Feature`` abstraction that Bookworm uses now.
    try:
        fut_def = Feature.from_json_str(json_str=fut.original_text)
        fut_title = fut_def.title
        fut_overview = fut_def.content
    except JSONDecodeError:
        logger.warn(
            "Couldn't load JSON from the original text, maybe it is an older spec?"
        )
    return fut_overview, fut_title


async def _get_steps_system_message(
    sql_session: Session, llm: BaseChatModel, response_class: type[BaseModel]
):
    return await _get_std_sys_msg(
        sql_session=sql_session,
        llm=llm,
        response_class=response_class,
        call_func=prompts.steps_generator_system_message,
    )


async def _get_tools_system_message(
    sql_session: Session, llm: BaseChatModel, response_class: type[BaseModel]
):
    return await _get_std_sys_msg(
        sql_session=sql_session,
        llm=llm,
        response_class=response_class,
        call_func=prompts.tool_picker_system_message,
    )


async def _get_std_sys_msg(
    sql_session: Session,
    llm: BaseChatModel,
    response_class: type[BaseModel],
    call_func: Callable[
        ..., Awaitable[SystemMessage]
    ] = prompts.steps_generator_system_message,
) -> SystemMessage:
    """Build the standard ``SystemMessage`` part of most (all?) of our copilot prompts."""
    ai_memory_service = AiMemoryService(sql_session, llm)
    user_notes = await ai_memory_service.get_user_notes_for_prompt()
    response_parser = JsonOutputParser(pydantic_object=response_class)
    format_instructions = response_parser.get_format_instructions()
    tool_call_function = response_class.__name__

    # Store the awaited result first
    sys_msg = call_func(
        user_notes=user_notes,
        tool_call_function=tool_call_function,
        response_formatting_instructions=format_instructions,
    )

    logger.info(
        "Here's the formatted system message we will send.",
        formatted_sys_msg=sys_msg.content,  # Now sys_msg is the actual SystemMessage, not a coroutine
    )
    return sys_msg
