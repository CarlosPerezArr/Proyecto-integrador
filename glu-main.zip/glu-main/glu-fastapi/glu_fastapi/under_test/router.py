import re
from typing import List, Annotated, Any, TypeVar

import aioboto3
import structlog
from fastapi import APIRouter, Query, status, Path, Depends, Response
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal
from fastapi_pagination.ext.sqlmodel import paginate
from sqlalchemy.orm import selectinload
from sqlmodel import select, desc

from glu_fastapi.external_services import LlmDependency, get_embeddings
from glu_fastapi.config import SettingsDep
from glu_fastapi.database.session import SqlSessionDep
from glu_fastapi.under_test.models import (
    DeviceUnderTestRead,
    DeviceUnderTestReadWithDeviceSpecs,
    DeviceUnderTest,
    DeviceSpecRead,
    DeviceSpec,
    FunctionSpec,
    DeviceSpecChunk,
    DeviceSpecChunkRead,
    FunctionSpecRead,
    DeviceUnderTestCreate,
    DeviceSpecReadWithFunctionSpecs,
    DeviceSpecPage,
    DeviceSpecPageReadWithRemoteUrl,
)
from glu_fastapi.under_test.services import (
    DeviceSpecChunkService,
    FunctionSpecService,
    DeviceSpecPageService,
    DeviceSpecTocEntryService,
)
from glu_fastapi.test_plan.models import TestPlan, TestPlanRead
from glu_fastapi.exceptions import NotFoundException
from glu_fastapi.external_services import (
    get_boto_session,
)


logger = structlog.get_logger()
_S3_URL_PARSING_REGEX = re.compile(r"(s3://[a-z0-9\-\.]{3,63}/)?(?P<key>.+)")
BotoSessionDep = Annotated[aioboto3.Session, Depends(get_boto_session)]
logger = structlog.get_logger()
T = TypeVar("T")
CursorWithTotalPage = CustomizedPage[
    CursorPage[T],
    UseIncludeTotal(True),
]
router = APIRouter()


@router.get(
    "/devices",
    response_model=CursorWithTotalPage[DeviceUnderTestRead],
)
async def list_devices_under_test(
    sql_session: SqlSessionDep,
) -> Any:
    """List all the devices that can be tested (in paginated fashion)."""

    return paginate(
        sql_session, select(DeviceUnderTest).order_by(desc(DeviceUnderTest.id))
    )


@router.post(
    "/devices/",
    status_code=status.HTTP_201_CREATED,
    response_model=DeviceUnderTestRead,
)
async def create_device_under_test(
    device: DeviceUnderTestCreate,
    sql_session: SqlSessionDep,
    response: Response,
) -> Any:
    """Translate a user-provided tech spec into a ``Device`` and related ``Function``s."""

    db_device = DeviceUnderTest.model_validate(device)
    sql_session.add(db_device)
    sql_session.flush()
    sql_session.refresh(db_device)

    response.headers["Location"] = router.url_path_for(
        "view_device_under_test", device_id=db_device.id
    )

    return db_device


@router.delete(
    "/devices/{device_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_device_under_test(
    sql_session: SqlSessionDep,
    device_id: Annotated[int, Path(title="The ID of the DeviceUnderTest to delete.")],
):
    """Delete a single ``DeviceUnderTest``."""

    select_stmt = select(DeviceUnderTest).where(DeviceUnderTest.id == device_id)
    delete_me = sql_session.exec(select_stmt).one_or_none()
    if delete_me is not None:
        sql_session.delete(delete_me)
        sql_session.flush()


@router.put(
    "/devices/{device_id}",
    response_model=DeviceUnderTestRead,
)
async def update_device_under_test(
    sql_session: SqlSessionDep,
    device_id: Annotated[int, Path(title="The ID of the DeviceUnderTest to update.")],
    updated_device: DeviceUnderTest,
) -> Any:
    """Total update for a single ``DeviceUnderTest``."""
    select_stmt = select(DeviceUnderTest).where(DeviceUnderTest.id == device_id)
    update_me = sql_session.exec(select_stmt).one_or_none()
    if update_me is None:
        raise NotFoundException(f"No such DeviceUnderTest(id={device_id}).")

    attrs = updated_device.model_dump(
        exclude={
            "id",
            "created_at",
            "updated_at",
        }
    )
    for name, value in attrs.items():
        setattr(update_me, name, value)
    sql_session.add(update_me)
    sql_session.flush()

    return update_me


@router.get(
    "/devices/{device_id}",
    response_model=DeviceUnderTestReadWithDeviceSpecs,
)
async def view_device_under_test(
    sql_session: SqlSessionDep,
    device_id: Annotated[int, Path(title="The ID of the DeviceUnderTest to get.")],
) -> Any:
    """Retrieve a single ``DeviceUnderTest``."""

    db_device = sql_session.exec(
        select(DeviceUnderTest)
        .options(selectinload(DeviceUnderTest.device_specs))
        .where(DeviceUnderTest.id == device_id)
    ).one_or_none()
    if db_device is not None:
        return db_device

    raise NotFoundException(f"No such DeviceUnderTest(id=#{device_id}).")


@router.get(
    "/devices/{device_id}/device_specs",
    response_model=List[DeviceSpecRead],
)
async def list_device_specs_for_device(
    sql_session: SqlSessionDep,
    device_id: Annotated[
        int,
        Path(title="The ID of the DeviceUnderTest whose DeviceSpecs should be listed."),
    ],
    offset: int = 0,
    limit: int = Query(default=20, le=20),
) -> Any:
    """List the specs for a given device."""

    device_specs = sql_session.exec(
        select(DeviceSpec)
        .where(DeviceSpec.device_under_test_id == device_id)
        .offset(offset)
        .limit(limit)
    ).all()
    return device_specs


@router.get("/device_specs", response_model=List[DeviceSpecRead])
async def list_device_specs(
    sql_session: SqlSessionDep,
    offset: int = 0,
    limit: int = Query(default=20, le=20),
) -> Any:
    """List *ALL* the device specifications."""

    device_specs = sql_session.exec(
        select(DeviceSpec).offset(offset).limit(limit)
    ).all()
    return device_specs


@router.get(
    "/device_specs/{device_spec_id}",
    response_model=DeviceSpecReadWithFunctionSpecs,
)
async def view_device_spec(
    sql_session: SqlSessionDep,
    device_spec_id: Annotated[int, Path(title="The ID of the DeviceSpec to fetch.")],
) -> Any:
    """Retrieve a single ``DeviceSpec``."""

    db_device = sql_session.exec(
        select(DeviceSpec)
        .options(selectinload(DeviceSpec.function_specs))
        .where(DeviceSpec.id == device_spec_id)
    ).one_or_none()
    if db_device is not None:
        return db_device

    raise NotFoundException(f"No such DeviceSpec(id=#{device_spec_id}).")


@router.delete(
    "/device_specs/{device_spec_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_device_spec(
    settings: SettingsDep,
    sql_session: SqlSessionDep,
    boto_session: BotoSessionDep,
    device_spec_id: Annotated[int, Path(title="The ID of the DeviceSpec to delete.")],
) -> None:
    """Delete a single ``DeviceSpec``."""

    select_stmt = select(DeviceSpec).where(DeviceSpec.id == device_spec_id)
    delete_me = sql_session.exec(select_stmt).one_or_none()
    if delete_me is not None:
        sql_session.delete(delete_me)
        sql_session.flush()

    # Despite some unfortunate naming, we actually store complete URLs in at least some DeviceSpec records, so we need
    # to try to canonicalize the key before asking AWS to delete it.
    key = delete_me.s3_key
    logger.debug(
        "Started off thinking we needed to ask boto to delete this S3 object",
        s3_url=key,
    )
    m = _S3_URL_PARSING_REGEX.match(key)
    key = m.group("key")
    logger.debug(
        "After trying to regex off the 's3://$BUCKET/' prefix, we are left with this key.",
        s3_key=key,
    )
    if key is not None:
        logger.debug(
            "About to ask boto to delete_object", bucket=settings.glu_bucket, key=key
        )
        async with boto_session.client("s3") as s3:
            await s3.delete_object(Bucket=settings.glu_bucket, Key=key)


@router.get(
    "/device_specs/{device_spec_id}/pages/{page_number}",
    response_model=DeviceSpecPageReadWithRemoteUrl,
)
async def view_device_spec_page(
    settings: SettingsDep,
    sql_session: SqlSessionDep,
    boto_session: BotoSessionDep,
    device_spec_id: Annotated[int, Path(title="The ID of the DeviceSpec to fetch.")],
    page_number: Annotated[int, Path(title="The page number for the page we want.")],
) -> Any:
    """Retrieve a single ``DeviceSpecPage``."""

    db_spec = sql_session.exec(
        select(DeviceSpec).where(DeviceSpec.id == device_spec_id)
    ).one_or_none()
    if db_spec is None:
        raise NotFoundException(f"No such DeviceSpec(id=#{device_spec_id}).")

    db_page = sql_session.exec(
        select(DeviceSpecPage)
        .where(DeviceSpecPage.device_spec_id == device_spec_id)
        .where(DeviceSpecPage.page_number == page_number)
    ).one_or_none()
    if db_page is None:
        raise NotFoundException(
            f"No such DeviceSpecPage(device_spec_id=#{device_spec_id}, page_number=#{page_number})."
        )

    page_service = DeviceSpecPageService(settings, sql_session, boto_session)
    page_with_url = await page_service.urlify_page(db_page)
    return page_with_url


@router.get(
    "/device_specs/{device_spec_id}/chunks",
    response_model=List[DeviceSpecChunkRead],
)
async def search_chunks(
    settings: SettingsDep,
    sql_session: SqlSessionDep,
    device_spec_id: Annotated[
        int, Path(title="The ID of the DeviceSpec whose chunks we are querying.")
    ],
    q: str | None = None,
    offset: int = 0,
    limit: int = Query(default=5, le=20),
) -> Any:
    """Do a vector search over the chunks of a given spec."""

    base_query = select(DeviceSpecChunk).where(
        DeviceSpecChunk.device_spec_id == device_spec_id
    )

    if q is not None and q != "":
        embedded_q = await get_embeddings([q])
        # NOTE: We're using cosine_distance because the PGVector docs say that's what OpenAI recommends for their
        #       embeddings.
        base_query = base_query.order_by(
            DeviceSpecChunk.chunk_embeddings.cosine_distance(embedded_q[0])
        )

    chunks = sql_session.exec(base_query.offset(offset).limit(limit)).all()
    return chunks


@router.get(
    "/devices/{device_id}/device_specs/{device_spec_id}/device_spec_chunks",
    response_model=List[DeviceSpecChunkRead],
)
async def list_chunks_for_device_spec(
    sql_session: SqlSessionDep,
    device_id: Annotated[
        int, Path(title="The ID of the DeviceUnderTest whose chunks should be fetched.")
    ],
    device_spec_id: Annotated[
        int, Path(title="The ID of the DeviceSpec whose chunks should be fetched.")
    ],
    requested_page_numbers: Annotated[
        List[int] | None,
        "A list of page numbers on which the returned chunks should found",
    ] = Query(default=None),
    offset: int = 0,
    limit: int = Query(default=20),
) -> Any:
    """List all the chunks we have for a given device specification."""

    device_spec = sql_session.exec(
        select(DeviceSpec)
        .where(DeviceSpec.id == device_spec_id)
        .where(DeviceSpec.device_under_test_id == device_id)
    ).one_or_none()
    if device_spec is None:
        return []

    service = DeviceSpecChunkService(sql_session)
    return await service.get_chunks_for_spec(
        device_spec_id,
        offset=offset,
        limit=limit,
        requested_pages=requested_page_numbers,
    )


@router.get(
    "/devices/{device_id}/device_specs/{device_spec_id}/function_specs",
    response_model=CursorWithTotalPage[FunctionSpecRead],
)
async def list_function_specs_for_device(
    sql_session: SqlSessionDep,
    device_id: Annotated[
        int,
        Path(
            title="The ID of the DeviceUnderTest whose FunctionSpecs should be fetched."
        ),
    ],
    device_spec_id: Annotated[
        int,
        Path(title="The ID of the DeviceSpec whose FunctionSpecs should be fetched."),
    ],
) -> Any:
    """List the individual function specs for a given device."""

    device_spec = sql_session.exec(
        select(DeviceSpec)
        .where(DeviceSpec.id == device_spec_id)
        .where(DeviceSpec.device_under_test_id == device_id)
    ).one_or_none()
    if device_spec is None:
        return []

    filtered_select = (
        select(FunctionSpec)
        .where(FunctionSpec.device_spec_id == device_spec.id)
        .order_by(FunctionSpec.name)
    )
    return paginate(sql_session, filtered_select)


@router.get(
    "/device_specs/{device_spec_id}/function_specs",
    response_model=List[FunctionSpecRead],
)
async def list_function_specs_for_device_spec(
    sql_session: SqlSessionDep,
    device_spec_id: Annotated[
        int,
        Path(title="The ID of the DeviceSpec whose FunctionSpecs should be fetched."),
    ],
    offset: int = 0,
    limit: int = Query(default=100, le=500),
) -> Any:
    """List the individual function specs for a given device."""

    return sql_session.exec(
        select(FunctionSpec)
        .where(FunctionSpec.device_spec_id == device_spec_id)
        .offset(offset)
        .limit(limit)
    ).all()


@router.get("/function_specs", response_model=List[FunctionSpecRead])
async def list_function_specs(
    sql_session: SqlSessionDep,
    offset: int = 0,
    limit: int = Query(default=100, le=500),
) -> Any:
    """List *ALL* function specs."""

    function_specs = sql_session.exec(
        select(FunctionSpec).offset(offset).limit(limit)
    ).all()
    return function_specs


@router.post(
    "/function_specs/{device_spec_id}",
    response_model=List[FunctionSpecRead],
)
async def create_function_specs(
    device_spec_id: Annotated[
        int,
        Path(title="The ID of the DeviceSpec whose FunctionSpecs should be generated."),
    ],
    sql_session: SqlSessionDep,
    llm: LlmDependency,
) -> Any:
    """Create the individual function specs for a device."""

    service = FunctionSpecService(sql_session, llm)
    return await service.extract_and_save_function_specs(device_spec_id)


@router.get(
    "/function_specs/{function_spec_id}",
    response_model=FunctionSpecRead,
)
async def view_function_spec(
    sql_session: SqlSessionDep,
    function_spec_id: Annotated[
        int, Path(title="The ID of the FunctionSpec to be fetched.")
    ],
) -> Any:
    """Retrieve a single ``FunctionSpec``."""

    spec = sql_session.exec(
        select(FunctionSpec).where(FunctionSpec.id == function_spec_id)
    ).one_or_none()

    if spec is None:
        raise NotFoundException(f"No such FunctionSpec(id={function_spec_id}")

    return spec


@router.get(
    "/function_specs/{function_spec_id}/page_data",
    response_model=List[DeviceSpecPageReadWithRemoteUrl],
)
async def get_page_data_for_function_spec(
    settings: SettingsDep,
    sql_session: SqlSessionDep,
    boto_session: BotoSessionDep,
    function_spec_id: Annotated[
        int, Path(title="The ID of the FunctionSpec whose page data are to be fetched.")
    ],
) -> Any:
    function_spec = sql_session.exec(
        select(FunctionSpec).where(FunctionSpec.id == function_spec_id)
    ).one_or_none()
    if function_spec is None:
        raise NotFoundException(f"No such FunctionSpec(id={function_spec_id})")

    toc_entry_service = DeviceSpecTocEntryService(sql_session)
    page_service = DeviceSpecPageService(
        settings, sql_session, boto_session, toc_entry_service
    )
    return await page_service.fetch_fully_loaded_pages_for_function_spec(function_spec)


@router.get(
    "/function_specs/{function_spec_id}/test_plans",
    response_model=List[TestPlanRead],
)
async def get_test_plans_for_function_spec(
    sql_session: SqlSessionDep,
    function_spec_id: Annotated[
        int,
        Path(title="The ID of the FunctionSpec whose test plans are to be fetched."),
    ],
) -> Any:
    """List the individual test plans for a given function spec."""
    return sql_session.exec(
        select(TestPlan).where(TestPlan.function_spec_id == function_spec_id)
    ).all()


@router.delete(
    "/function_specs/{function_spec_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_function_spec(
    sql_session: SqlSessionDep,
    function_spec_id: Annotated[
        int, Path(title="The ID of the FunctionSpec to delete.")
    ],
):
    """Delete a single ``FunctionSpec``."""

    select_stmt = select(FunctionSpec).where(FunctionSpec.id == function_spec_id)
    delete_me = sql_session.exec(select_stmt).one_or_none()
    if delete_me is not None:
        sql_session.delete(delete_me)
        sql_session.flush()
