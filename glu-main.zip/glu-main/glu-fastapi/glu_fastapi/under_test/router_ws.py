import structlog
from fastapi import APIRouter, WebSocketException, status
from starlette.websockets import WebSocket, WebSocketDisconnect

from glu_fastapi.external_services import LlmDependency, EmbeddingsDependency
from glu_fastapi.auth import LoggedInUserWsDep
from glu_fastapi.bookworm import ImplBookwormService
from glu_fastapi.bookworm.service_implementation import DocumentProcessedEvent
from glu_fastapi.config import SettingsDep
from glu_fastapi.database.session import WsSqlSessionDep
from glu_fastapi.under_test.models import DeviceSpec
from glu_fastapi.under_test.router import BotoSessionDep
from glu_fastapi.websocket_utils import SocketResponse


router = APIRouter()
logger = structlog.get_logger()


@router.websocket("/add_spec")
async def test_bookworm(
    current_user: LoggedInUserWsDep,
    settings: SettingsDep,
    boto: BotoSessionDep,
    llm_client: LlmDependency,
    sql_session: WsSqlSessionDep,
    websocket: WebSocket,
    embedding_client: EmbeddingsDependency,
) -> None:
    logger.debug("Checkpoint Alpha")
    await websocket.accept()
    logger.debug("Checkpoint Bravo")
    try:
        # Receive the initial payload with all the metadata
        metadata = await websocket.receive_json()
        logger.debug("Checkpoint Charlie", metadata=metadata)
        await websocket.send_text("ACK")
        logger.debug("Checkpoint Delta", metadata=metadata)

        # Receive the file
        filedata = await websocket.receive_bytes()
        logger.debug("Checkpoint Echo", num_bytes=len(filedata))

        # Build a DeviceSpec with the metadata
        spec = DeviceSpec(
            filename=metadata["filename"],
            device_under_test_id=metadata["device_under_test_id"],
        )
        sql_session.add(spec)
        sql_session.flush()
        logger.debug("Checkpoint Foxtrot", spec=spec)

        # Process per-page, and send an update to the client after each page
        bookish = ImplBookwormService(
            current_user=current_user,
            boto_session=boto,
            llm_client=llm_client,
            settings=settings,
            websocket=websocket,
            spec=spec,
            session=sql_session,
            embedding_client=embedding_client,
        )
        # NOTE: ``parse_pdf`` is in charge of sending status updates down the socket.
        await bookish.parse_pdf(filedata)
        logger.debug("Checkpoint Golf")

        sql_session.flush()

        await websocket.send_text(
            SocketResponse(
                is_error=False,
                code=status.HTTP_200_OK,
                payload=DocumentProcessedEvent(
                    devicespec_id=spec.id,
                ).model_dump(),
            ).model_dump_json()
        )
    except WebSocketDisconnect:
        logger.info("Client closed connection. I think.")
    except Exception as e:  # noqa
        logger.exception("That sucks!")
        print(e)
        raise WebSocketException(1008, getattr(e, "message", repr(e)))
    finally:
        try:
            await websocket.close()
        except Exception:  # noqa
            logger.info("Websocket was already closed, or something", exc_info=True)
