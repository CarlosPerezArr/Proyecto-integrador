"""Service objects that are related to devices being tested."""

import base64
import itertools
from asyncio import Semaphore, TaskGroup
from collections import defaultdict
from typing import List, Union, Dict, Tuple, Iterable, Annotated
import json
import aioboto3
import structlog
from langchain_openai import ChatOpenAI
from sqlalchemy import func, Text
from sqlmodel import Session, select
from ..bookworm.models_implementation import Feature

from glu_fastapi.config import Settings
from glu_fastapi.external_services import get_embeddings
from glu_fastapi.auth import User
from glu_fastapi.exceptions import NotFoundException
from glu_fastapi.under_test.models import (
    DeviceSpec,
    DeviceSpecChunk,
    DeviceUnderTest,
    FunctionSpec,
    DeviceSpecPage,
    DeviceSpecTocEntry,
    DeviceSpecPageReadWithData,
    DeviceSpecPageReadWithRemoteUrl,
)

logger = structlog.get_logger()


class FunctionSpecService:
    """Business logic related to ``FeatureSpec``."""

    def __init__(
        self,
        sql_session: Session,
        llm: ChatOpenAI,
    ):
        self.sql_session: Session = sql_session
        self.llm: ChatOpenAI = llm.with_structured_output(method="json_mode")

    async def find(self, function_spec_id: int) -> FunctionSpec:
        function_spec = self.sql_session.exec(
            select(FunctionSpec).where(FunctionSpec.id == function_spec_id)
        ).one_or_none()
        if function_spec is None:
            raise NotFoundException(f"No such FunctionSpec(id={function_spec_id}).")
        return function_spec

    # this is old now, we have it in bookworm instead
    # async def extract_and_save_function_specs(
    #     self, device_spec_id: int
    # ) -> List[FunctionSpec]:
    #     """Ask the LLM to identify features for testing, and save the answers."""

    #     # Fetch the DeviceSpec to ensure it exists
    #     device_spec = self.sql_session.exec(
    #         select(DeviceSpec).where(DeviceSpec.id == device_spec_id)
    #     ).one_or_none()
    #     if device_spec is None:
    #         raise NotFoundException(f"No such DeviceSpec(id=#{device_spec_id}).")

    #     # Turn the ToC entries for this spec into a string suitable for
    #     # sending to the model.
    #     lines = [
    #         f"{toc_entry.section_number} -> {toc_entry.section_title}"
    #         for toc_entry in device_spec.table_of_contents
    #     ]
    #     toc_string = "\n".join(lines)
    #     prompt = f"""Below is the table of contents for the specification document for a device under test. Come up with a list of functions of the device that you should write test plans for. Your list will serve as the outline for a new test plan document. Do not include anything in the list that is not a function of the device that you intend to test. Categorize the test appropriately, but don't include section numbers in your list.

    #     Return the list as a JSON Array object. Do not wrap the Array in an Object. Try to standardize naming. Do not combine the tests. Each entry in the list should be of the form:

    #         Category > Function (combined into one field) > Sub-function (if any)

    #     If there are no logical tests or the Table of Contents is empty, please return an empty list.

    #     Only include the JSON list in your answer. Your answer will be parsed by a JSON parser, so it should be conformant.

    #     ### TABLE OF CONTENTS

    #     {toc_string}

    #     """

    #     logger.debug("LLM prompt", prompt=prompt)

    #     messages = [
    #         SystemMessage(
    #             content="You are an assistant hardware test developer. Your job is to interpret feature specifications and test plans for hardware in development/pre-production and work with a test engineer to develop a robust sequence of test steps using the equipment they have available, as well as any supporting code to automate the testing when possible."
    #         ),
    #         HumanMessage(content=prompt),
    #     ]

    #     # NOTE: We have used the LangChain helper that will use OpenAI's
    #     # ``response_format: { type: "json_object" }`` feature, so we don't
    #     # have to manually parse the results.
    #     function_names = await self.llm.ainvoke(messages)
    #     logger.debug("LLM response", response=function_names)

    #     # Create FunctionSpec objects for each function name
    #     created_function_specs = []
    #     for name in function_names:
    #         new_func_spec = FunctionSpec(
    #             name=name.strip(),  # Strip to remove any surrounding whitespace
    #             original_text="TBD",
    #             device_spec_id=device_spec_id,
    #         )
    #         self.sql_session.add(new_func_spec)
    #         created_function_specs.append(new_func_spec)

    #     self.sql_session.flush()

    #     return created_function_specs


class DeviceSpecTocEntryService:
    """Business logic related to ``DeviceSpecTocEntry."""

    def __init__(
        self,
        sql_session: Session,
    ):
        self.sql_session: Session = sql_session

    async def best_match_from_toc_entries(
        self, device_spec_id: int, query: str
    ) -> DeviceSpecTocEntry:
        """Given ``query``, find the Table of Contents whose ``section_title`` most closely matches.

        On our first attempt, we will leverage Postgres string similarity stuff.

        .. todo:: Determine whether we need to impose a threshold for relevance, and if so, what that threshold should be.
        """
        logger.debug("Find best match for query", query=query)
        # NOTE: That little bit of line noise (``<<<->``) is an operator (hence the ``$COLUMN_NAME.op``) provided by the
        #       pg_trgm extension to calculate the "strict word similarity". If that turns out to be too restrictive, we
        #       could consider the standard "word similarity". For more details see:
        #       https://www.postgresql.org/docs/current/pgtrgm.html#PGTRGM-FUNCS-OPS
        distance_calculation = DeviceSpecTocEntry.section_title.op("<<<->")(query)
        select_stmt = (
            select(DeviceSpecTocEntry)
            .where(DeviceSpecTocEntry.device_spec_id == device_spec_id)
            .order_by(distance_calculation)
        )
        best_match = self.sql_session.exec(select_stmt).first()
        logger.debug("This was the best we could do", best_match=best_match)
        return best_match


class DeviceSpecPageService:
    """Business logic related to ``DeviceSpecPage``."""

    def __init__(
        self,
        settings: Settings,
        sql_session: Session,
        boto_session: aioboto3.Session,
        toc_entry_service: DeviceSpecTocEntryService,
    ):
        self.settings: Settings = settings
        self.sql_session: Session = sql_session
        self.boto_session: aioboto3.Session = boto_session
        self.toc_entry_service: DeviceSpecTocEntryService = toc_entry_service

    async def fetch_bare_page(
        self,
        device_spec_id: int,
        page_number: int,
    ) -> DeviceSpecPage:
        db_page = self.sql_session.exec(
            select(DeviceSpecPage)
            .where(DeviceSpecPage.device_spec_id == device_spec_id)
            .where(DeviceSpecPage.page_number == page_number)
        ).one_or_none()
        if db_page is None:
            raise NotFoundException(
                f"No such DeviceSpecPage(device_spec_id=#{device_spec_id}, page_number=#{page_number})."
            )
        return db_page

    async def search_pages_by_header(
        self, function_spec: FunctionSpec
    ) -> List[DeviceSpecPage] | None:
        """Look up the pages that whose headings are a good semantic match for the name of the ``FunctionSpec``."""
        # 1) Do a keyword search
        logger.debug("search -> keyword 1", function_spec=function_spec)
        name_as_fulltext_query = func.plainto_tsquery(function_spec.name)
        logger.debug("search -> keyword 2")
        headings_as_text = DeviceSpecPage.headings_on_page.cast(Text)
        full_text_match = headings_as_text.op("@@")(name_as_fulltext_query)
        logger.debug("search -> keyword 3")
        kw_search = (
            select(DeviceSpecPage)
            .where(DeviceSpecPage.device_spec_id == function_spec.device_spec_id)
            .where(full_text_match)
        )  # noqa
        logger.debug("search -> keyword 4")
        kw_search = kw_search.order_by(
            func.ts_rank(
                func.to_tsvector(headings_as_text), name_as_fulltext_query
            ).desc()
        ).limit(5)
        logger.debug("search -> keyword 5")
        kw_results = self.sql_session.exec(kw_search).all()
        logger.warn("search -> keyword 6", results=kw_results)

        # 2) Do a "semantic" search using the pgvector (try setting a similarity
        #    filter around 0.8? See also:
        #    https://stackoverflow.com/questions/77047661/is-there-a-threshold-we-can-set-for-search-score-azure-vector-search-to-ignore)
        logger.debug("search -> semantic 1", function_spec=function_spec)
        name_as_embeddings = (await get_embeddings([function_spec.name]))[0]
        logger.debug("search -> semantic 2")
        semantic_search = select(DeviceSpecPage).where(
            DeviceSpecPage.device_spec_id == function_spec.device_spec_id
        )
        logger.debug("search -> semantic 3")
        cosine_similarity = DeviceSpecPage.heading_embeddings.op("<=>")(
            name_as_embeddings
        ).desc()
        logger.debug("search -> semantic 4")
        semantic_search = semantic_search.order_by(cosine_similarity).limit(5)
        logger.debug("search -> semantic 5")
        semantic_results = self.sql_session.exec(semantic_search).all()
        logger.warn("search -> semantic 6", results=semantic_results)

        # 3) Use Reciprocal Rank Fusion
        pages_by_id: Dict[int, DeviceSpecPage] = {}
        for page in kw_results:
            pages_by_id[page.id] = page
        for page in semantic_results:
            if page.id in pages_by_id:
                continue
            pages_by_id[page.id] = page
        ranking_factors: Dict[int, Dict[str, float]] = defaultdict(
            lambda: defaultdict(lambda: 0.0)
        )

        for i, kw_result_page in enumerate(kw_results):
            ranking_factors[kw_result_page.id]["kw_factor"] = self._calculate_factor(i)
        for i, semantic_result_page in enumerate(semantic_results):
            ranking_factors[semantic_result_page.id]["semantic_factor"] = (
                self._calculate_factor(i)
            )

        toc_pages = set(
            toc_entry.toc_page_number
            for toc_entry in function_spec.device_spec.table_of_contents
        )
        ranked_results: List[Tuple[float, DeviceSpecPage]] = []
        for k, v in ranking_factors.items():
            score = v["kw_factor"] + v["semantic_factor"]
            item = pages_by_id[k]
            if item.page_number in toc_pages:
                continue
            ranked_results.append((score, item))
        ranked_results.sort(key=lambda x: x[0])
        return [item for score, item in ranked_results]

    async def fetch_pages_for_toc_entry(
        self, device_spec: DeviceSpec, toc_entry: DeviceSpecTocEntry
    ) -> List[DeviceSpecPage] | None:
        """Look up the pages that contain relevant info for a given ``DeviceSpecTocEntry``.

        The way this works is we start on the page indicated by ``toc_entry``, and then we scan to the next entry the
        ``table_of_contents`` on ``device_spec`` to find what page we should stop on.
        """
        if toc_entry is None:
            return None

        if toc_entry.section_page_number is None:
            return None

        page_nums = [toc_entry.section_page_number]
        logger.debug("Need at least the following pages", page_nums=page_nums)

        # NOTE: This loop is horrifying; it is here because ``item == toc_entry`` (which is what we'd be doing if we
        #       used the built in ``.index()`` method) is exploding for ``DeviceSpecTocEntry``. I'm not entirely sure
        #       why, but at this point, I just need something functional.
        for index, item in enumerate(device_spec.table_of_contents):
            if item.model_dump() == toc_entry.model_dump():
                break
        else:
            logger.info(
                "Well this isn't good; the entry supposedly doesn't exist in the Table of Contents."
            )
            return None

        place_in_line = index
        logger.debug("This entry is where?", place_in_line=place_in_line)
        if place_in_line < len(device_spec.table_of_contents) - 1:
            next_entry = device_spec.table_of_contents[place_in_line + 1]
            logger.debug(
                "Here's the next ToC entry",
                next_entry=next_entry,
            )
            next_referenced_page = next_entry.section_page_number
            if next_referenced_page > toc_entry.section_page_number:
                page_nums.extend(
                    range(toc_entry.section_page_number + 1, next_referenced_page)
                )
        logger.debug(
            "After scanning forward in the Table of Contents, we need THESE pages.",
            page_nums=page_nums,
        )

        db_pages = await self.fetch_pages_by_page_num(
            device_spec_id=device_spec.id, page_nums=page_nums
        )
        logger.debug("Got the pages, don't have the data (YET).", pages=db_pages)

        return db_pages

    async def fetch_pages_by_page_num(
        self, device_spec_id: int, page_nums: list[int] = []
    ) -> List[DeviceSpecPage]:
        select_stmt = (
            select(DeviceSpecPage)
            .where(DeviceSpecPage.device_spec_id == device_spec_id)
            .where(DeviceSpecPage.page_number.in_(page_nums))
        )
        db_pages = self.sql_session.exec(select_stmt)
        return db_pages

    async def fetch_fully_loaded_pages_for_function_spec(
        self,
        function_spec: FunctionSpec,
    ) -> List[DeviceSpecPageReadWithRemoteUrl]:
        """Look up 'all' the pages of the spec that relate to ``function_spec`` complete with presigned URLs for OpenAI to download the images from S3."""

        function_spec_name = function_spec.name
        logger.debug(
            "About to try to find a ToC match for this function spec",
            function_spec_name=function_spec_name,
        )
        toc_entry = await self.toc_entry_service.best_match_from_toc_entries(
            function_spec.device_spec_id, function_spec_name
        )
        logger.debug("This is what we got", toc_entry=toc_entry)
        logger.debug(
            "About to look up pages (with data) for this entry.", toc_entry=toc_entry
        )
        pages_from_toc_search = await self.fetch_pages_for_toc_entry(
            function_spec.device_spec, toc_entry
        )
        pages_from_header_search = await self.search_pages_by_header(function_spec)
        if pages_from_toc_search is None and pages_from_header_search is None:
            raise NotFoundException(
                "We encountered an error trying to look up the data you requested."
            )

        pages_from_llm_section_relationships = []
        try:
            fut_def = Feature.from_json_str(json_str=function_spec.original_text)
            pages_from_llm_section_relationships = await self.fetch_pages_by_page_num(
                device_spec_id=function_spec.device_spec_id,
                page_nums=fut_def.get_all_page_numbers(),
            )
        except json.JSONDecodeError:
            logger.warn(
                "Couldn't load JSON from the original text, maybe it is an older spec?"
            )

        visited_ids = set()
        all_pages = itertools.chain(
            # pages_from_toc_search or [], pages_from_header_search or []
            pages_from_llm_section_relationships
            or []
        )
        unique_pages = []
        for page in all_pages:
            if page.id not in visited_ids:
                unique_pages.append(page)
                visited_ids.add(page.id)
        urlified_pages = await self._urlify_pages(unique_pages)
        logger.debug("Fetched pages with data", page_count=len(urlified_pages))
        return urlified_pages

    async def urlify_page(
        self,
        db_page: DeviceSpecPage,
        expiry: Annotated[
            int, "The amount of time (in seconds) the S3 URL should be valid."
        ] = 300,
        limiter: Semaphore = None,
    ) -> DeviceSpecPageReadWithRemoteUrl:
        logger.debug(
            "We were asked to load this page with a presigned S3 URL.",
            page=db_page,
        )

        async def generate_signed_fetch_url():
            async with self.boto_session.client("s3") as s3:
                bucket = self.settings.glu_bucket
                key = db_page.s3_key
                if key.startswith("s3:"):
                    key = key[len(f"s3://{bucket}/") :]
                params = {
                    "Bucket": bucket,
                    "Key": key,
                }
                return await s3.generate_presigned_url(
                    ClientMethod="get_object",
                    Params=params,
                    ExpiresIn=expiry,
                    HttpMethod="GET",
                )

        async def generate_and_apply_url() -> DeviceSpecPageReadWithRemoteUrl:
            page_with_remote_url = DeviceSpecPageReadWithRemoteUrl.model_validate(
                db_page
            )
            page_with_remote_url.presigned_s3_url = await generate_signed_fetch_url()
            return page_with_remote_url

        if limiter is not None:
            return await generate_and_apply_url()
        async with limiter:
            return await generate_and_apply_url()

    async def _load_data_onto_pages(
        self, db_pages: Iterable[DeviceSpecPage]
    ) -> List[DeviceSpecPageReadWithData] | None:
        if db_pages is None:
            return None

        # OK, time to get fancy: we're going to do all the pages
        # concurrently. To do this, we're using a new (as of 3.11)
        # Python feature called TaskGroup. It's an async context manager
        # that will treat any Tasks created inside it as a group,
        # and await all of them before it exits. To be even fancier, we're going
        # to limit the parallelism by using an async semaphore. I picked 5 here
        # because it seemed like a reasonable limit, but we could tune it pretty easily.
        rate_limiter = Semaphore(5)
        tasks = []
        async with TaskGroup() as group:
            for db_page in db_pages:
                tasks.append(
                    group.create_task(self._load_data_onto_page(db_page, rate_limiter))
                )

        # We're outside the ``TaskGroup``, so the pages have
        # all been loaded with their raw data and the new DeviceSpecPageWithData
        # should be sitting in the ``result`` of each ``Task`` object. Loop
        # across the tasks and grab the results to return.
        results = [t.result() for t in tasks if t.done() and not t.cancelled()]
        logger.debug(f"OK, we get {len(results)} pages worth of data.")
        return results

    async def _urlify_pages(
        self,
        db_pages: Iterable[DeviceSpecPage],
    ) -> List[DeviceSpecPageReadWithRemoteUrl]:
        if db_pages is None:
            return []

        # OK, time to get fancy: we're going to do all the pages
        # concurrently. To do this, we're using a new (as of 3.11)
        # Python feature called TaskGroup. It's an async context manager
        # that will treat any Tasks created inside it as a group,
        # and await all of them before it exits. To be even fancier, we're going
        # to limit the parallelism by using an async semaphore. I picked 5 here
        # because it seemed like a reasonable limit, but we could tune it pretty easily.
        rate_limiter = Semaphore(5)
        tasks = []
        async with TaskGroup() as group:
            for db_page in db_pages:
                tasks.append(
                    group.create_task(self.urlify_page(db_page, limiter=rate_limiter))
                )
        # We're outside the ``TaskGroup``, so the pages have
        # all been loaded with their urls and the new DeviceSpecPageWithRemoteUrl
        # should be sitting in the ``result`` of each ``Task`` object. Loop
        # across the tasks and grab the results to return.
        results = [t.result() for t in tasks if t.done() and not t.cancelled()]
        logger.debug(f"OK, we get {len(results)} pages with URLs.")
        return results

    async def _load_data_onto_page(
        self,
        db_page: DeviceSpecPage,
        limiter: Semaphore = None,
    ) -> DeviceSpecPageReadWithData:
        logger.debug(
            "We were asked to load this page with its data (in base64-encoded form).",
            page=db_page,
        )
        if limiter is None:
            page_with_data = DeviceSpecPageReadWithData.model_validate(db_page)
            page_with_data.encoded_data = await self.fetch_encoded_page_data(db_page)
            return page_with_data

        async with limiter:
            page_with_data = DeviceSpecPageReadWithData.model_validate(db_page)
            page_with_data.encoded_data = await self.fetch_encoded_page_data(db_page)
            return page_with_data

    async def fetch_encoded_page_data(self, device_spec_page: DeviceSpecPage) -> str:
        """Fetch the binary page data for ``device_spec_page`` from S3 and base64-encode it."""
        async with self.boto_session.client("s3") as s3:
            bucket = self.settings.glu_bucket
            key = device_spec_page.s3_key
            if key.startswith("s3:"):
                key = key[len(f"s3://{bucket}/") :]

            try:
                logger.debug("Fetch me my data!", bucket=bucket, key=key)
                s3_obj = await s3.get_object(Bucket=bucket, Key=key)
                logger.debug("Fetched!", data=s3_obj)
            except Exception:  # noqa
                logger.error(
                    "Failed to fetch data for page",
                    exc_info=True,
                    page=device_spec_page,
                )
                raise NotFoundException(f"Could not find S3 object for page: {key}")
            else:
                data = await s3_obj["Body"].read()
                return base64.b64encode(data).decode("ascii")

    def _calculate_factor(self, index: int) -> float:
        # NOTE: 60 is just a very common k-value that people seem to have arrived at empirically.
        return 1.0 / (60 + index)


class DeviceSpecChunkService:
    """Business logic related to ``DeviceSpecChunk``."""

    def __init__(
        self,
        sql_session: Session,
    ):
        self.sql_session = sql_session

    async def find(self, chunk_id: int) -> DeviceUnderTest:
        """Find a ``DeviceSpecChunk`` by its PK (``id``)."""
        return self.sql_session.exec(
            select(DeviceSpecChunk).where(DeviceSpecChunk.id == chunk_id)
        ).one()

    async def get_chunks_for_spec(
        self,
        device_spec_id: int,
        offset: int,
        limit: int,
        requested_pages: Union[List[int], None],
    ) -> List[DeviceSpecChunk]:
        """Fetch a page of ``DeviceSpecChunk`` objects for a given ``DeviceSpec``."""
        select_stmt = select(DeviceSpecChunk).where(
            DeviceSpecChunk.device_spec_id == device_spec_id
        )
        if requested_pages is not None:
            select_stmt = select_stmt.where(
                DeviceSpecChunk.chunk_metadata["page_number"]
                .as_integer()
                .in_(requested_pages)
            )
        import logging

        logging.basicConfig()
        sqlalchemy_logger = logging.getLogger("sqlalchemy.engine")
        sqlalchemy_logger.setLevel(logging.DEBUG)
        return self.sql_session.exec(select_stmt.offset(offset).limit(limit)).all()


class DeviceUnderTestService:
    """Business logic related to ``DeviceUnderTest``."""

    def __init__(
        self,
        current_user: User,
        settings: Settings,
        sql_session: Session,
        boto_session: aioboto3.Session,
    ):
        self.current_user = current_user
        self.settings = settings
        self.sql_session = sql_session
        self.boto_session = boto_session

    async def find(self, device_id: int) -> DeviceUnderTest:
        """Find a ``DeviceUnderTest`` by its PK (``id``)."""
        return self.sql_session.exec(
            select(DeviceUnderTest).where(DeviceUnderTest.id == device_id)
        ).one()
