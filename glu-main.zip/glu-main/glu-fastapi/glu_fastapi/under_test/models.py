"""SQLModel models for devices under test (and various concepts that fall under that umbrella)."""

from typing import Optional, List

from numpy import float32
from numpy.typing import NDArray
from pgvector.sqlalchemy import Vector
from pydantic import field_serializer, computed_field

from sqlalchemy import (
    Column,
    JSON,
    UniqueConstraint,
    Integer,
    ForeignKey,
    Index,
    func,
    text,
)
from sqlmodel import Field, Relationship
from sqlmodel._compat import SQLModelConfig


from glu_fastapi.per_tenant_models import CommonDevice, OPENAI_DIMENSIONALITY, BaseTable
from glu_fastapi.test_plan.models import TestPlan, TestScript


class DeviceUnderTestBase(CommonDevice):
    """Base class for devices under test; for use with *Read/*Create subclasses."""

    pass


class DeviceUnderTest(DeviceUnderTestBase, table=True):
    """A device to be tested."""

    id: int | None = Field(default=None, primary_key=True)
    device_specs: List["DeviceSpec"] = Relationship(  # noqa: F821
        back_populates="device_under_test",
        sa_relationship_kwargs={
            "cascade": "save-update, merge, expunge, delete, delete-orphan"
        },
    )


class DeviceUnderTestCreate(DeviceUnderTestBase):
    """A model so we can have a clean contract for POSTs to create a ``DeviceUnderTest``."""

    pass


class DeviceUnderTestRead(DeviceUnderTestBase):
    """A model so we can have a clean contract for GETs to read ``DeviceUnderTest`` records."""

    id: int


class DeviceUnderTestReadWithDeviceSpecs(DeviceUnderTestRead):
    """Like ``DeviceUnderTestRead``, but with the related ``DeviceSpecReads`` included."""

    device_specs: List["DeviceSpecRead"] = []


class DeviceSpecBase(BaseTable):
    """The spec for a ``DeviceUnderTest``.

    This will include the URL for the spec the user uploaded, and a collection of
    ``FunctionSpec``s that we create from that document.
    """

    s3_key: Optional[str]
    filename: str = Field(max_length=1024)
    device_under_test_id: int = Field(
        sa_column=Column(
            Integer,
            ForeignKey(
                "deviceundertest.id",
                name="fk__devicespec__deviceundertest",
                ondelete="CASCADE",
            ),
            index=True,
            nullable=False,
        )
    )


class DeviceSpec(DeviceSpecBase, table=True):
    id: int | None = Field(default=None, primary_key=True)

    device_under_test: DeviceUnderTest = Relationship(back_populates="device_specs")
    function_specs: List["FunctionSpec"] = Relationship(
        back_populates="device_spec",
        sa_relationship_kwargs={
            "cascade": "save-update, merge, expunge, delete, delete-orphan"
        },
    )
    device_spec_chunks: List["DeviceSpecChunk"] = Relationship(
        back_populates="device_spec",
        sa_relationship_kwargs={
            "cascade": "save-update, merge, expunge, delete, delete-orphan"
        },
    )
    table_of_contents: List["DeviceSpecTocEntry"] = Relationship(
        back_populates="device_spec",
        sa_relationship_kwargs={
            "cascade": "save-update, merge, expunge, delete, delete-orphan"
        },
    )
    pages: List["DeviceSpecPage"] = Relationship(
        back_populates="device_spec",
        sa_relationship_kwargs={
            "cascade": "save-update, merge, expunge, delete, delete-orphan"
        },
    )

    @property
    def chunk_count(self):
        return len(self.device_spec_chunks)

    @property
    def page_count(self):
        return len(self.pages)


class DeviceSpecCreate(DeviceSpecBase):
    pass


class DeviceSpecRead(DeviceSpecBase):
    """A representation of a ``DeviceSpec`` that is suitable for exposure in the API."""

    id: int


class DeviceSpecReadWithFunctionSpecs(DeviceSpecRead):
    """Like ``DeviceSpecRead``, but with the related ``FunctionSpecReads`` included."""

    function_specs: List["FunctionSpecRead"] = []


class DeviceSpecChunkBase(BaseTable):
    """A chunk of a ``DeviceSpec``."""

    device_spec_id: int = Field(
        sa_column=Column(
            Integer,
            ForeignKey(
                "devicespec.id",
                name="fk__devicespecchunk__devicespec",
                ondelete="CASCADE",
            ),
            index=True,
            nullable=False,
        )
    )
    element_id: str = Field(default=None, nullable=False)
    chunk_metadata: dict = Field(sa_column=Column(JSON), default_factory=dict)
    chunk_text: str = Field(default=None, nullable=False)

    @computed_field(return_type=int)
    @property
    def page_number(self) -> int:
        return self.chunk_metadata["page_number"]


class DeviceSpecChunk(DeviceSpecChunkBase, table=True):
    """The DB-side representation of ``DeviceSpecChunkBase``."""

    model_config = SQLModelConfig(arbitrary_types_allowed=True)  # type: ignore

    __table_args__ = (
        UniqueConstraint(
            "device_spec_id", "element_id", name="UC_DEVICE_SPEC_CHUNK_SPEC_AND_ELEMENT"
        ),
    )

    id: int = Field(default=None, primary_key=True)
    chunk_embeddings: List[float] | None = Field(
        default=None, sa_column=Column(Vector(OPENAI_DIMENSIONALITY))
    )

    device_spec: DeviceSpec = Relationship(back_populates="device_spec_chunks")

    @field_serializer("chunk_embeddings")
    def serialize_chunk_embeddings(
        self, chunk_embeddings: NDArray[float32], _info
    ) -> List[float] | None:
        if chunk_embeddings is None:
            return None

        return chunk_embeddings.tolist()


class DeviceSpecChunkCreate(DeviceSpecChunkBase):
    pass


class DeviceSpecChunkRead(DeviceSpecChunkBase):
    id: int


class DeviceSpecTocEntryBase(BaseTable):
    """A Table of Contents for a ``DeviceSpec``."""

    device_spec_id: int = Field(
        sa_column=Column(
            Integer,
            ForeignKey(
                "devicespec.id",
                name="fk__devicespectocentry__devicespec",
                ondelete="CASCADE",
            ),
            index=True,
            nullable=False,
        )
    )
    section_title: str | None = Field(default=None, nullable=True)
    section_number: str | None = Field(default=None, nullable=True)
    section_page_number: int | None = Field(default=None, nullable=True)
    toc_page_number: int = Field(
        nullable=False, sa_column_kwargs={"server_default": text("-1")}
    )


class DeviceSpecTocEntry(DeviceSpecTocEntryBase, table=True):
    id: int | None = Field(default=None, primary_key=True)
    device_spec: DeviceSpec = Relationship(back_populates="table_of_contents")

    __table_args__ = (
        Index(
            "ix_gin__devicespectocentry__section_title",
            "section_title",
            postgresql_ops={"section_title": "gin_trgm_ops"},
            postgresql_using="gin",
        ),
    )


class DeviceSpecTocEntryCreate(DeviceSpecTocEntryBase):
    pass


class DeviceSpecTocEntryRead(DeviceSpecTocEntryBase):
    id: int


class DeviceSpecPageBase(BaseTable):
    """A page from a ``DeviceSpec``."""

    device_spec_id: int = Field(
        sa_column=Column(
            Integer,
            ForeignKey(
                "devicespec.id",
                name="fk__devicespecpage__devicespec",
                ondelete="CASCADE",
            ),
            index=True,
            nullable=False,
        )
    )
    s3_key: str
    page_number: int
    headings_on_page: List[str] = Field(sa_column=Column(JSON), default_factory=list)


class DeviceSpecPage(DeviceSpecPageBase, table=True):
    """A page from a ``DeviceSpec``."""

    id: int | None = Field(default=None, primary_key=True)
    device_spec: DeviceSpec = Relationship(back_populates="pages")
    heading_embeddings: List[float] | None = Field(
        default=None, sa_column=Column(Vector(OPENAI_DIMENSIONALITY))
    )

    __table_args__ = (
        UniqueConstraint(
            "device_spec_id",
            "page_number",
            name="uc_devicespecpage_devicespecid_pagenumber",
        ),
        Index(
            "ix_hnsw__devicespecpage__heading_embeddings",
            "heading_embeddings",
            unique=False,
            postgresql_using="hnsw",
            postgresql_with={"m": 16, "ef_construction": 64},
            postgresql_ops={"heading_embeddings": "vector_cosine_ops"},
        ),
        Index(
            "ix_gin__devicespecpage__headings_on_page",
            func.json_to_tsvector("english", Column("headings_on_page"), '"all"'),
            unique=False,
            postgresql_using="gin",
        ),
        # CREATE INDEX IF NOT EXISTS ix_gin__devicespecpage__headings_on_page
        # ON development3.devicespecpage
        # USING GIN (json_to_tsvector('english', headings_on_page, '"all"'))
        # ;
    )


class DeviceSpecPageCreate(DeviceSpecPageBase):
    pass


class DeviceSpecPageRead(DeviceSpecPageBase):
    id: int


class DeviceSpecPageReadWithData(DeviceSpecPageRead):
    encoded_data: Optional[str] = Field(default=None)


class DeviceSpecPageReadWithRemoteUrl(DeviceSpecPageRead):
    """A view of a persisted ``DeviceSpecPage`` that has a presigned S3 URL for fetching the original page image."""

    presigned_s3_url: Optional[str] = Field(default=None)


class FunctionSpecBase(BaseTable):
    """The detailed specifications for a single function to be tested."""

    name: str = Field(index=True)
    original_text: str
    device_spec_id: int = Field(
        sa_column=Column(
            Integer,
            ForeignKey(
                "devicespec.id", name="fk__functionspec__devicespec", ondelete="CASCADE"
            ),
            index=True,
            nullable=False,
        )
    )


class FunctionSpec(FunctionSpecBase, table=True):
    id: int | None = Field(default=None, primary_key=True)

    device_spec: DeviceSpec = Relationship(back_populates="function_specs")
    test_plan: Optional["TestPlan"] = Relationship(
        back_populates="function_spec",
        sa_relationship_kwargs={
            "uselist": False,
            "cascade": "save-update, merge, expunge, delete, delete-orphan",
        },
    )
    test_script: Optional["TestScript"] = Relationship(
        back_populates="function_spec",
        sa_relationship_kwargs={
            "uselist": False,
            "cascade": "save-update, merge, expunge, delete, delete-orphan",
        },
    )
    ai_messages: Optional[List["AiMessage"]] = Relationship(  # noqa: F821
        back_populates="function_spec",
        sa_relationship_kwargs={
            "cascade": "save-update, merge, expunge, delete, delete-orphan"
        },
    )

    # NOTE: We will probably want to vectorize ``original_text`` on every save and
    #       persist using the vector extensions to Postgres.


class FunctionSpecCreate(FunctionSpecBase):
    pass


class FunctionSpecRead(FunctionSpecBase):
    id: int
    test_plan: Optional[TestPlan] = None
    test_script: Optional[TestScript] = None
