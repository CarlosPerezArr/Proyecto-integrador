from enum import Enum
from typing import Any

import sentry_sdk
import structlog
import uvicorn

from asgi_correlation_id import CorrelationIdMiddleware
from fastapi import (
    Depends,
    FastAPI,
    Request,
    Response,
)
from fastapi.middleware.trustedhost import TrustedHostMiddleware
from fastapi_pagination import add_pagination
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

from glu_fastapi.external_services import LlmDependency
from glu_fastapi.auth import (
    require_logged_in_user,
    UserRead,
    LoggedInUserDep,
    require_logged_in_user_ws,
)
from glu_fastapi.ai.router import router as ai_router
from glu_fastapi.auth.router import router as auth_router
from glu_fastapi.middleware_utils import (
    install_session_middleware,
    install_cors_middleware,
    StructlogMiddleware,
    get_allowed_hosts,
    AttachUserToScopeMiddleware,
    MixPanelMiddleware,
    Middleware,
)
from glu_fastapi.lab_bench.router import router as test_bench_router
from glu_fastapi.lab_bench.router_ws import router as test_bench_router_ws

from glu_fastapi.under_test.router import (
    router as device_under_test_router,
)
from glu_fastapi.under_test.router_ws import router as device_under_test_router_ws
from glu_fastapi.test_plan.router import router as testing_router
from glu_fastapi.test_plan.router_ws import router as testing_router_ws

sentry_sdk.init(
    dsn="https://b616c255ae5bf639236cd52b9fb7d23d@o4507381136228352.ingest.us.sentry.io/4507381428453376",
    # Set traces_sample_rate to 1.0 to capture 100%
    # of transactions for performance monitoring.
    traces_sample_rate=1.0,
    # Set profiles_sample_rate to 1.0 to profile 100%
    # of sampled transactions.
    # We recommend adjusting this value in production.
    profiles_sample_rate=1.0,
)
logger = structlog.get_logger()
app = FastAPI(title="GLU", debug=False)
add_pagination(app)

install_cors_middleware(app)
allow_us = get_allowed_hosts()
logger.debug("Deny other hosts.", allowed=allow_us)
app.add_middleware(TrustedHostMiddleware, allowed_hosts=allow_us)
app.add_middleware(MixPanelMiddleware)
app.add_middleware(AttachUserToScopeMiddleware)


@app.middleware("http")
async def log_host_header(request: Request, call_next: Middleware) -> Response:
    """Middleware function that logs the ``Host`` header on each request."""
    logger.debug("Header check!", host_header=request.headers.get("Host", None))
    return await call_next(request)


install_session_middleware(app)
app.add_middleware(StructlogMiddleware)
# Finally, we add our CorrelationIdMiddleware. It has to be last because middlewares
# are processed in reverse order, and we need that correlation ID in pretty much
# all our other middleware.
app.add_middleware(CorrelationIdMiddleware)


class Tags(Enum):
    """Ways of categorizing the API endpoints."""

    lab_bench = "lab_bench"
    lab_bench_ws = "lab_bench_ws"
    under_test = "under_test"
    under_test_ws = "under_test_ws"
    testing = "testing"
    testing_ws = "testing_ws"
    llm = "llm"
    info = "info"
    auth = "auth"
    ai = "ai"


app.include_router(auth_router, tags=[Tags.auth])
app.include_router(
    test_bench_router,
    prefix=f"/{Tags.lab_bench.value}",
    # NOTE: We can't actually *reference* the ``require_logged_in_user`` dependency in our path operations for the
    #       router, but specifying it here means auth is required for all the included path operations.
    dependencies=[Depends(require_logged_in_user)],
    tags=[Tags.lab_bench],
)
app.include_router(
    test_bench_router_ws,
    prefix=f"/{Tags.lab_bench_ws.value}",
    dependencies=[Depends(require_logged_in_user_ws)],
    tags=[Tags.lab_bench_ws],
)
app.include_router(
    device_under_test_router,
    prefix=f"/{Tags.under_test.value}",
    dependencies=[Depends(require_logged_in_user)],
    tags=[Tags.under_test],
)
app.include_router(
    device_under_test_router_ws,
    prefix=f"/{Tags.under_test_ws.value}",
    dependencies=[Depends(require_logged_in_user_ws)],
    tags=[Tags.under_test_ws],
)
app.include_router(
    testing_router,
    prefix=f"/{Tags.testing.value}",
    dependencies=[Depends(require_logged_in_user)],
    tags=[Tags.testing],
)
app.include_router(
    testing_router_ws,
    prefix=f"/{Tags.testing_ws.value}",
    dependencies=[Depends(require_logged_in_user_ws)],
    tags=[Tags.testing_ws],
)
app.include_router(
    ai_router,
    prefix=f"/{Tags.ai.value}",
    dependencies=[Depends(require_logged_in_user)],
    tags=[Tags.ai],
)


@app.get("/user_info", tags=[Tags.info], response_model=UserRead)
async def get_user_info(current_user: LoggedInUserDep) -> Any:
    return current_user


@app.get("/langchain_hello/{name}", tags=[Tags.llm])
async def get_langchain_hello(
    _current_user: LoggedInUserDep, llm: LlmDependency, name: str
) -> str:
    """Experience the gracious hospitality of your new AI overlords."""

    prompt = ChatPromptTemplate.from_template(
        "Say hello to {name} the friendly developer"
    )
    output_parser = StrOutputParser()
    chain = prompt | llm | output_parser
    return chain.invoke({"name": name})


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000)  # nosec
