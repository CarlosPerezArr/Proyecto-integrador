"""Example of how to use langgraph."""

import functools
import json
import operator
import uuid
from typing import (
    Annotated,
    TypedDict,
    Dict,
    List,
    Sequence,
    Optional,
    Union,
    Callable,
    Literal,
    Any,
    Type,
)

import jsonpatch
import structlog
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import (
    BaseMessage,
    AnyMessage,
    AIMessage,
    HumanMessage,
    ToolMessage,
    ToolCall,
)
from langchain_core.prompt_values import PromptValue
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import Runnable, RunnableLambda, RunnableSerializable
from langgraph.checkpoint.base import BaseCheckpointSaver
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langchain_openai import ChatOpenAI
from langgraph.graph.state import CompiledStateGraph
from langgraph.prebuilt import ValidationNode
from openai import BadRequestError
from pydantic import BaseModel, field_validator, Field

from glu_fastapi.test_plan.models import TestPlan

EXIT_CONDITIONS = ["quit", "exit", "q"]
logger = structlog.get_logger()


# Basic structure of all these bots:
# 0) __start__
# 1) Initial prompt the system generates
# 2) Chatbot responds (async stream this to front-end over websocket)
# 3) interrupt so we can add human yay-or-nay(with feedback)
# 4) Conditional Edge
#   case yay) goto 5
#   case nay) append human message to state, goto 3
# 5) tool to generate output to DB
# 6) __end__

# Things to put here:
# 1. Test Plan generator bot
# 2. Test Bench generator bot
# 3. Test Script generator bot


class State(TypedDict):
    messages: Annotated[list, add_messages]


def _chatbot(llm: ChatOpenAI, state: State) -> Dict[str, List[BaseMessage]]:
    return {
        "messages": [llm.invoke(state["messages"])],
    }


def _default_aggregator(messages: Sequence[AnyMessage]) -> AIMessage:
    """Grab the first ``AIMessage`` in ``messages``."""
    for msg in messages:
        if msg.type == "ai":
            return msg
    else:
        raise ValueError("No AI message found in the sequence.")


class RetryStrategy(TypedDict, total=False):
    """Define the retry strategy for a tool call."""

    max_attempts: int
    """The maximum number of attempts to make."""

    fallback: Optional[
        Union[
            Runnable[Sequence[AnyMessage], AIMessage],
            Runnable[
                Sequence[AnyMessage], BaseMessage
            ],  # This is actively annoying to me; I wish we had more consistent types to work with, here.
            Callable[[Sequence[AnyMessage]], AIMessage],
        ]
    ]
    """The 'function' to use once validation fails."""

    aggregate_messages: Optional[Callable[[Sequence[AnyMessage]], AIMessage]]


class JsonPatch(BaseModel):
    """A JSON Patch document represents an operation to be performed on a JSON document.

    Note that the op and path are ALWAYS required. Value is required for ALL operations except 'remove'.
    Examples:

    ```json
    {"op": "add", "path": "/a/b/c", "patch_value": 1}
    {"op": "replace", "path": "/a/b/c", "patch_value": 2}
    {"op": "remove", "path": "/a/b/c"}
    ```
    """

    op: Literal["add", "remove", "replace"] = Field(
        ...,
        description="The operation to be performed. Must be one of 'add', 'remove', 'replace'.",
    )
    path: str = Field(
        ...,
        description="A JSON Pointer path that references a location within the target document where the operation is performed.",
    )
    value: Any = Field(
        ...,
        description="The value to be used within the operation. REQUIRED for 'add', 'replace', and 'test' operations.",
    )


class PatchFunctionParameters(BaseModel):
    """Respond with all JSONPatch operation to correct validation errors caused by passing in incorrect or incomplete parameters in a previous tool call."""

    tool_call_id: str = Field(
        ...,
        description="The ID of the original tool call that generated the error. Must NOT be an ID of a PatchFunctionParameters tool call.",
    )
    reasoning: str = Field(
        ...,
        description="Think step-by-step, listing each validation error and the JSONPatch operation needed to correct it. Cite the fields in the JSONSchema you referenced in developing this plan.",
    )
    patches: list[JsonPatch] = Field(
        ...,
        description="A list of JSONPatch operations to be applied to the previous tool call's response.",
    )


def _bind_validator_with_retries(
    llm: Union[
        Runnable[Sequence[AnyMessage], AIMessage],
        Runnable[Sequence[BaseMessage], BaseMessage],
    ],
    *,
    validator: ValidationNode,
    retry_strategy: RetryStrategy,
    tool_choice: Optional[str] = None,
) -> Runnable[Union[List[AnyMessage], PromptValue], AIMessage]:
    """Does all the work of ``bind_validator_with_retries``.

    Args:
        llm (Runnable): The llm that will generate the initial messages (and optionally fallback)
        validator (ValidationNode): The validation logic.
        retry_strategy (RetryStrategy): The retry strategy to use.
            Possible keys:
            - max_attempts: The maximum number of attempts to make.
            - fallback: The LLM or function to use in case of validation failure.
            - aggregate_messages: A function to aggregate the messages over multiple turns.
                Defaults to fetching the last AI message.
        tool_choice: Which tool to invoke (I think)?

    Returns:
        Runnable: A runnable that can be invoked with a list of messages and returns a single AI message.
    """

    fancy_builder = build_tool_call_based_llm_with_validation_and_retries(
        llm,
        retry_strategy=retry_strategy,
        validator=validator,
        tool_choice=tool_choice,
    )

    def encode(x: Union[Sequence[AnyMessage], PromptValue]) -> dict:
        """Ensure the input is in the correct format."""
        if isinstance(x, PromptValue):
            return {"messages": x.to_messages(), "input_format": "list"}

        if isinstance(x, list):
            return {"messages": x, "input_format": "list"}

        raise ValueError(f"Unexpected input type: {type(x)}")

    def decode(x: State) -> AIMessage:
        """Ensure the output is in the expected format."""
        return x["messages"][-1]

    return (
        encode
        | fancy_builder.compile().with_config(run_name="ValidationGraph")
        | decode
    ).with_config(run_name="ValidateWithRetries")


def build_tool_call_based_llm_with_validation_and_retries(
    llm: Union[
        Runnable[Sequence[AnyMessage], AIMessage],
        Runnable[Sequence[BaseMessage], BaseMessage],
    ],
    *,
    validator: ValidationNode,
    retry_strategy: RetryStrategy,
    tool_choice: Optional[str] = None,
) -> StateGraph:

    def add_or_overwrite_messages(left: list, right: Union[list, dict]) -> list:
        """Append messages. If the update is a 'finalized' output, replace the whole list."""
        if isinstance(right, dict) and "finalize" in right:
            finalized = right["finalize"]
            if not isinstance(finalized, list):
                finalized = [finalized]
            for m in finalized:
                if m.id is None:
                    m.id = str(uuid.uuid4())
            return finalized
        res = add_messages(left, right)
        if not isinstance(res, list):
            return [res]

        return res

    class StateWithValidationAndRetries(TypedDict):
        messages: Annotated[list, add_or_overwrite_messages]
        attempt_number: Annotated[int, operator.add]
        initial_num_messages: int
        input_format: Literal["list", "dict"]

    def dedict(x: State) -> list:
        """Get the messages from the state."""
        return x["messages"]

    fallback_runnable = retry_strategy.get("fallback")
    if fallback_runnable is None:
        fallback_runnable = llm
    elif isinstance(fallback_runnable, Runnable):
        # no-op
        ...
    else:
        fallback_runnable = RunnableLambda(fallback_runnable)

    def count_messages(state: StateWithValidationAndRetries) -> dict[str, int]:
        return {"initial_num_messages": len(state.get("messages", []))}

    # To support patch-based retries, we need to be able to aggregate the messages
    # over multiple turns. The next sequence selects only the relevant messages
    # and then applies the validator.
    select_messages = retry_strategy.get("aggregate_messages") or _default_aggregator

    def select_generated_messages(state: StateWithValidationAndRetries) -> list:
        """Select only the messages generated within this loop."""
        selected = state["messages"][state["initial_num_messages"] :]
        logger.info("Picking generated messages 1", selected=selected)
        selected_messages = [select_messages(selected)]
        logger.info("Picking generated messages 2", selected_messages=selected_messages)
        return selected_messages

    def endict_validator_output(x: Sequence[AnyMessage]) -> dict:
        """Either tell the LLM to respond with a tool call, or wrap ``x`` in a ``dict`` so it fulfills the ``State`` contract."""
        if tool_choice and not x:
            logger.debug("endict says make a tool_call")
            return {
                "messages": [
                    HumanMessage(
                        content=f"ValidationError: please respond with a valid tool call [tool_choice={tool_choice}]",
                        additional_kwargs={"is_error": True},
                    )
                ]
            }
        logger.debug("endict is making a dict")
        return {"messages": x}

    # FIXME: Validate the full-text of the response is actually Markdown?
    validator_runnable = select_generated_messages | validator | endict_validator_output

    def validator_or_end(state: State) -> Literal["validator", "__end__"]:
        if state["messages"][-1].tool_calls or tool_choice is not None:
            return "validator"
        return "__end__"

    max_attempts = retry_strategy.get("max_attempts", 3)

    def fallback_or_end(
        state: StateWithValidationAndRetries,
    ) -> Literal["fallback", "__end__"]:
        if state["attempt_number"] > max_attempts:
            raise ValueError(
                f"Could not extract a valid value in {max_attempts} attempts."
            )

        for msg in state["messages"][::-1]:
            if msg.type in ("ai", "tool_call"):
                break

            if msg.additional_kwargs.get("is_error", False):
                return "fallback"
        return "__end__"

    fancy_builder = StateGraph(StateWithValidationAndRetries)
    fancy_builder.add_node("count_messages", count_messages)
    fancy_builder.add_edge(START, "count_messages")
    model = dedict | llm | (lambda msg: {"messages": [msg], "attempt_number": 1})
    fancy_builder.add_node("llm", model)
    fancy_builder.add_edge("count_messages", "llm")
    fancy_builder.add_node("validator", validator_runnable)
    fancy_builder.add_conditional_edges("llm", validator_or_end, ["validator", END])
    fallback = (
        dedict
        | fallback_runnable
        | (lambda msg: {"messages": [msg], "attempt_number": 1})
    )
    fancy_builder.add_node("fallback", fallback)
    fancy_builder.add_edge("fallback", "validator")

    fancy_builder.add_conditional_edges(
        "validator",
        fallback_or_end,
        ["fallback", END],
    )

    return fancy_builder


async def build_copilot_graph_with_structured_output(
    llm: BaseChatModel,
    checkpointer: BaseCheckpointSaver,
    tools: List[Any],
    human_in_the_loop: bool = True,
) -> CompiledStateGraph:
    bound_llm = llm.bind_tools(tools, tool_choice=None)
    fallback_llm = llm.bind_tools([PatchFunctionParameters])

    def format_exception(error: BaseException, call: ToolCall, schema: Type[BaseModel]):
        return (
            f"Error:\n\n```\n{repr(error)}\n```\n"
            "Expected Parameter Schema:\n\n" + f"```json\n{schema.schema_json()}\n```\n"
            f"Please respond with a JSONPatch to correct the error for tool_call_id=[{call['id']}]."
        )

    def aggregate_messages(messages: Sequence[AnyMessage]) -> AIMessage:
        # Get all the AI messages and apply JSON patches.
        resolved_tool_calls: Dict[Union[str, None], ToolCall] = {}
        content: Union[str, List[Union[str, dict]]] = ""
        for msg in messages:
            if msg.type != "ai":
                continue

            if not content:
                content = msg.content
            for tc in msg.tool_calls:
                if tc["name"] == PatchFunctionParameters.__name__:
                    tc_id = tc["args"]["tool_call_id"]
                    if tc_id not in resolved_tool_calls:
                        logger.info(
                            f"""
                            JsonPatch tool call ID {tc['args']['tool_call_id']} not found.
                            Valid tool call IDs: {list(resolved_tool_calls.keys())}
                            """,
                        )
                    orig_tool_call = resolved_tool_calls[tc_id]
                    current_args = orig_tool_call["args"]
                    patches = tc["args"].get("patches", [])
                    orig_tool_call["args"] = jsonpatch.apply_patch(
                        current_args, patches
                    )
                    orig_tool_call["id"] = tc["id"]
                else:
                    resolved_tool_calls[tc["id"]] = tc.copy()
        return AIMessage(content=content, tool_calls=list(resolved_tool_calls.values()))

    def format_messages(messages):
        formatted_messages = []
        pending_tool_calls = {}

        for message in messages:
            if isinstance(message, AIMessage) and message.additional_kwargs.get(
                "tool_calls"
            ):
                formatted_messages.append(message)
                for tool_call in message.additional_kwargs["tool_calls"]:
                    pending_tool_calls[tool_call["id"]] = tool_call
            elif isinstance(message, ToolMessage):
                if message.tool_call_id in pending_tool_calls:
                    formatted_messages.append(message)
                    del pending_tool_calls[message.tool_call_id]
            else:
                formatted_messages.append(message)

        # Add dummy tool responses for any pending tool calls
        for tool_call_id, tool_call in pending_tool_calls.items():
            dummy_response = ToolMessage(
                tool_call_id=tool_call_id,
                content="No response provided for this tool call.",
                name=tool_call["function"]["name"],
            )
            formatted_messages.append(dummy_response)

        return formatted_messages

    formatted_llm = RunnableLambda(format_messages) | bound_llm

    def log_messages(messages):
        logger.debug(
            f"Messages being sent to OpenAI: {json.dumps([m.dict() for m in messages], indent=2)}"
        )
        return messages

    logged_formatted_llm = RunnableLambda(log_messages) | formatted_llm

    graph = build_tool_call_based_llm_with_validation_and_retries(
        logged_formatted_llm,
        validator=ValidationNode(
            tools + [PatchFunctionParameters],
            format_error=format_exception,
        ),
        retry_strategy=RetryStrategy(
            max_attempts=3,
            fallback=fallback_llm,
            aggregate_messages=aggregate_messages,
        ),
    )
    if human_in_the_loop:
        return graph.compile(
            checkpointer=checkpointer,
            interrupt_after=["validator"],
        ).with_config(metadata={"retry_strategy": "jsonpatch"})
    else:
        return graph.compile(
            checkpointer=checkpointer,
        ).with_config(metadata={"retry_strategy": "jsonpatch"})


def bind_validator_with_retries(
    llm: BaseChatModel,
    *,
    tools: list,
    tool_choice: Optional[str] = None,
    max_attempts: int = 3,
) -> Runnable[Union[List[AnyMessage], PromptValue], AIMessage]:
    """Binds a tool validators + retry logic to create a runnable validation graph.

    LLMs that support tool calling can generate structured JSON. However, they may not always
    perfectly follow your requested schema, especially if the schema is nested or has complex
    validation rules. This method allows you to bind a validation function to the LLM's output,
    so that any time the LLM generates a message, the validation function is run on it. If
    the validation fails, the method will retry the LLM with a fallback strategy, the simplest
    being just to add a message to the output with the validation errors and a request to fix them.

    The resulting runnable expects a list of messages as input and returns a single AI message.
    By default, the LLM can optionally NOT invoke tools, making this easier to incorporate into
    your existing chat bot. You can specify a tool_choice to force the validator to be run on
    the outputs.

    Args:
        llm (Runnable): The llm that will generate the initial messages (and optionally fallback)
        tools (list): The tools the LLM may invoke
        tool_choice (str | None): Which tool to invoke and validate
        max_attempts (int): The maximum number of times to invoke the tool

    Returns:
        Runnable: A runnable that can be invoked with a list of messages and returns a single AI message.
    """
    bound_llm = llm.bind_tools(tools, tool_choice=tool_choice)
    retry_strategy = RetryStrategy(max_attempts=max_attempts)
    validator = ValidationNode(tools)
    return _bind_validator_with_retries(
        bound_llm,
        validator=validator,
        tool_choice=tool_choice,
        retry_strategy=retry_strategy,
    ).with_config(metadata={"retry_strategy": "default"})


class Respond(BaseModel):
    """Use to generate the response. Always use when responding to the user."""

    reason: str = Field(description="Step-by-step justification for the answer.")
    answer: str

    @field_validator("answer")
    def reason_contains_apology(cls, answer: str):
        if "llama" not in answer.lower():
            raise ValueError(
                "You MUST start with a gimmicky, rhyming advertisement for using a Llama V3 (an LLM) in your **answer** field. Must be an instant hit. Must be weaved into the answer."
            )


def get_poc_bot(llm: BaseChatModel) -> RunnableSerializable[dict, AIMessage]:
    bound_llm = bind_validator_with_retries(llm, tools=[Respond])
    prompt = ChatPromptTemplate.from_messages(
        [
            ("system", "Respond directly by calling the Respond function."),
            ("placeholder", "{messages}"),
        ]
    )
    return prompt | bound_llm


async def get_steps_generator_bot(
    llm: ChatOpenAI, checkpointer: AsyncPostgresSaver
) -> CompiledStateGraph:
    builder = StateGraph(State)
    _bound_chatbot = functools.partial(_chatbot, llm)

    builder.add_edge(START, "chatbot")
    builder.add_node("chatbot", _bound_chatbot)
    # interrupt_after chatbot - this will cause the `for evt in # graph.stream()` type logic to break the loop after the chatbot comes
    # back. I can then inspect the user feedback and if it's "DONE" (or
    # whatever other sentinel value), transition to end, and if it's actual
    # feedback, transition back to the chatbot.
    builder.add_edge("chatbot", END)
    return builder.compile(checkpointer=checkpointer, interrupt_after=["chatbot"])


async def config_for_picking_tools(test_plan: TestPlan) -> Dict[str, Any]:
    my_config = {
        "configurable": {
            "thread_id": f"TestPlan:{test_plan.id}::ToolPicker:{uuid.uuid4()}"
        }
    }
    return my_config


async def config_for_step_generation(fut):
    my_config = {
        "configurable": {
            "thread_id": f"FunctionSpec:{fut.id}::StepsGenerator:{uuid.uuid4()}"
        }
    }
    return my_config


async def run_graph(graph, graph_input, my_config) -> BaseMessage | None:
    cur_index = 0
    last_msg = None
    try:
        async for event in graph.astream(
            graph_input,
            my_config,
            stream_mode="values",
        ):
            logger.debug(
                "Stepping through the graph.",
                current_evt=event,
                cur_index=cur_index,
                last_msg=last_msg,
            )
            last_event = event
            last_msg = last_event["messages"][-1]
            cur_index += 1
    except BadRequestError:
        logger.exception(
            "Bad request to OpenAI", cur_index=cur_index, last_msg=last_msg
        )

    return last_msg
