import time
from http.cookies import SimpleCookie
from typing import List, Union, Callable, Awaitable

import structlog

from asgi_correlation_id.context import correlation_id
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from mixpanel import Mixpanel
from mixpanel_async import AsyncBufferedConsumer
from starlette.datastructures import Headers
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.middleware.sessions import SessionMiddleware
from starlette.types import Scope, Receive, Send

from glu_fastapi.auth import User, get_user_from_extracted_cookie_data
from glu_fastapi.config import glu_settings


settings = glu_settings()


def get_allowed_hosts() -> List[str]:
    match settings.hosting_env:
        case "production":
            return [
                "glutest.ai",
                "*.glutest.ai",
            ]
        case "development":
            return [
                "test",
                "localhost",
                "*.glu.ngrok.dev",
            ]
        case _:
            return ["test"]


class StructlogMiddleware(BaseHTTPMiddleware):
    """Recreate the uvicorn access log, but with structlog-y goodness."""

    def __init__(
        self,
        app,
    ):
        super().__init__(app)

    async def dispatch(self, request: Request, call_next):
        logger = structlog.get_logger()
        structlog.contextvars.clear_contextvars()
        # These context vars will be added to all log entries emitted during the request
        request_id = correlation_id.get()
        structlog.contextvars.bind_contextvars(request_id=request_id)

        start_time = time.perf_counter_ns()
        # If the call_next raises an error, we still want to return our own 500 response,
        # so we can add headers to it (process time, request ID...)
        response = Response(status_code=500)
        try:
            response = await call_next(request)
        except Exception:
            logger.exception("Uncaught exception")
            raise
        finally:
            process_time = time.perf_counter_ns() - start_time
            status_code = response.status_code
            url = request.url
            client_host: Union[str, None] = None
            client_port: Union[int, None] = None
            if request.client is not None:
                client_host = request.client.host
                client_port = request.client.port
            http_method = request.method
            http_version = request.scope["http_version"]
            # Recreate the Uvicorn access log format, but add all parameters as structured information
            logger.info(
                f"""{client_host}:{client_port} - "{http_method} {url} HTTP/{http_version}" {status_code}""",
                http={
                    "url": str(request.url),
                    "status_code": status_code,
                    "method": http_method,
                    "request_id": request_id,
                    "version": http_version,
                },
                network={"client": {"ip": client_host, "port": client_port}},
                duration=process_time,
            )
            response.headers["X-Process-Time"] = str(process_time / 10**9)
            return response


class MixPanelMiddleware:
    """Fire a MixPanel event for each request that passes through the middleware."""

    def __init__(self, app):
        self.app = app
        s = glu_settings()
        self.mp = Mixpanel(s.mixpanel_token, consumer=AsyncBufferedConsumer())

    async def __call__(self, scope: Scope, receive: Receive, send: Send):
        logger = structlog.get_logger()
        logger.debug("MixPanelMiddleware 1!", scope=scope)

        user_id = ""
        u: User = scope.get("user", None)
        if u is not None:
            user_id = f"{u.org_id}::{u.email}"
            self.mp.people_set(
                user_id,
                {
                    "$name": u.name,
                    "$email": u.email,
                },
            )
        req_path = scope.get("path", "")
        logger.debug("MixPanelMiddleware 2!", user_id=user_id, req_path=req_path)
        if user_id != "" or req_path != "":
            self.mp.track(
                user_id,
                "API Hit",
                {
                    "api_endpoint": req_path,
                },
            )

        await self.app(scope, receive, send)


class AttachUserToScopeMiddleware:
    """Look up the ``User`` as stick it in ``scope``.

    The mechanism for looking up the ``User`` varies based on whether this is an HTTP request, or a WebSocket request.

    If there is no ``User`` detected, we simply assign ``None`` to ``scope["user"]``.
    """

    def __init__(self, app):
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send):
        logger = structlog.get_logger()
        logger.debug("AttachUserToScopeMiddleware 1!", scope=scope)

        s = glu_settings()
        user = None
        try:
            if scope["type"] in ("websocket", "http"):
                headers = Headers(scope=scope)
                logger.debug(
                    "Extract User from raw request (HTTP *or* WebSocket)",
                    headers=headers,
                )
                cookie_header = headers.get("cookie", "")
                logger.debug("Extracted b'cookie' header", cookie_header=cookie_header)
                cookies = SimpleCookie(cookie_header)
                session_cookie = cookies.get("session", None)
                logger.debug(
                    "Extracted b'session' cookie", session_cookie=session_cookie
                )
                if session_cookie is None:
                    user = None
                else:
                    encoded_session = session_cookie.value.encode("utf-8")
                    user = await get_user_from_extracted_cookie_data(encoded_session, s)
                logger.debug("Got the user", user=user)
        except Exception:
            logger.exception("Error extracting User in middleware.", scope=scope)
        scope["user"] = user
        logger.debug("AttachUserToScopeMiddleware 2!", scope=scope)

        await self.app(scope, receive, send)


def get_cookie_domain() -> Union[str, None]:
    match settings.hosting_env:
        case "production":
            return "glutest.ai"
        case "development":
            return "glu.ngrok.dev"
        case _:
            return None


def install_session_middleware(app: FastAPI) -> None:
    my_kwargs = {
        "secret_key": settings.auth0_client_secret,
        "https_only": True,
        "domain": get_cookie_domain(),
        "max_age": 24 * 60 * 60,  # 1 day expiration, to match auth0.
    }
    app.add_middleware(SessionMiddleware, **my_kwargs)


def get_permitted_origins() -> List[str]:
    match settings.hosting_env:
        case "production":
            return [
                "https://glutest.ai",
                "https://api.glutest.ai",
            ]
        case "development":
            return [
                "http://localhost:3001",
                "https://api1.glu.ngrok.dev",
                "https://web1.glu.ngrok.dev",
                "https://api2.glu.ngrok.dev",
                "https://web2.glu.ngrok.dev",
                "https://api3.glu.ngrok.dev",
                "https://web3.glu.ngrok.dev",
                "https://api4.glu.ngrok.dev",
                "https://web4.glu.ngrok.dev",
            ]
        case _:
            return []


def install_cors_middleware(app: FastAPI) -> None:
    app.add_middleware(
        CORSMiddleware,
        allow_origins=get_permitted_origins(),
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        allow_origin_regex=r"https?://.+\.glutest\.ai",
    )


Middleware = Callable[[Request], Awaitable[Response]]
