from typing import Annotated
from functools import partial

import aioboto3
from fastapi import Depends
from langchain_openai import ChatOpenAI

from langchain_openai import OpenAIEmbeddings
from langchain_core.embeddings import Embeddings
from langchain_core.language_models import BaseChatModel

from glu_fastapi.config import SettingsDep
from pydantic import BaseModel, Field
from typing import Optional
from typing import List


async def get_boto_session() -> aioboto3.Session:
    """A basic (async) Boto3 ``Session``."""
    settings = SettingsDep()
    return aioboto3.Session(
        aws_access_key_id=settings.aws_access_key_id,
        aws_secret_access_key=settings.aws_secret_access_key,
        region_name=settings.aws_default_region,
    )


class ChatConfig(BaseModel):
    """Configuration for ChatOpenAI client."""

    model: str = Field(default="gpt-4o-2024-08-06")
    temperature: float = Field(default=0.1, ge=0.0, le=2.0)
    streaming: bool = Field(default=False)
    max_retries: int = Field(default=3, ge=0)
    timeout: int = Field(default=60, ge=1)


def get_llm_chat_service(
    streaming: bool = False, config: Optional[ChatConfig] = None
) -> ChatOpenAI:
    """
    Create a ChatOpenAI instance with proper configuration and error handling.

    Args:
        streaming: Whether to enable streaming mode
        config: Optional custom configuration

    Returns:
        ChatOpenAI: Configured chat instance

    Raises:
        ValueError: If API key is missing
        Exception: If chat initialization fails
    """
    try:
        api_key = SettingsDep().openai_api_key
        if not api_key:
            raise ValueError("OpenAI API key not found in settings")

        # Use default config if none provided
        chat_config = config or ChatConfig()

        # Override streaming if explicitly requested
        if streaming:
            chat_config.streaming = True

        # Create chat instance with all config parameters
        return ChatOpenAI(
            api_key=api_key,
            model=chat_config.model,
            temperature=chat_config.temperature,
            streaming=chat_config.streaming,
            max_retries=chat_config.max_retries,
            request_timeout=chat_config.timeout,
        )

    except Exception as e:
        # Log the error or handle it according to your needs
        raise Exception(f"Failed to initialize ChatOpenAI: {str(e)}") from e


class EmbeddingsConfig(BaseModel):
    """Configuration for embeddings client."""

    model: str = Field(default="text-embedding-3-small")
    chunk_size: int = Field(default=1000, ge=1)
    max_retries: int = Field(default=3, ge=0)
    timeout: int = Field(default=60, ge=1)


def get_embeddings_service(config: Optional[EmbeddingsConfig] = None) -> Embeddings:
    """
    Create an embeddings instance with proper configuration and error handling.

    Args:
        config: Optional custom configuration

    Returns:
        Embeddings: Configured embeddings instance

    Raises:
        ValueError: If API key is missing
        Exception: If embeddings initialization fails
    """
    try:
        api_key = SettingsDep().openai_api_key
        if not api_key:
            raise ValueError("OpenAI API key not found in settings")

        # Use default config if none provided
        embeddings_config = config or EmbeddingsConfig()

        # Create embeddings instance with all config parameters
        return OpenAIEmbeddings(
            api_key=api_key,
            model=embeddings_config.model,
            chunk_size=embeddings_config.chunk_size,
            max_retries=embeddings_config.max_retries,
            timeout=embeddings_config.timeout,
        )

    except Exception as e:
        # Log the error or handle it according to your needs
        raise Exception(f"Failed to initialize Embeddings: {str(e)}") from e


async def get_embeddings(chunks_o_text: List[str]) -> List[List[float]]:
    """Get the OpenAI embeddings for ``chunks_o_text``."""

    embeddings_model: Embeddings = get_embeddings_service()
    return await embeddings_model.aembed_documents(texts=chunks_o_text)


# FastAPI dependency
LlmDependency = Annotated[BaseChatModel, Depends(get_llm_chat_service)]

# FastAPI dependency
EmbeddingsDependency = Annotated[Embeddings, Depends(get_embeddings_service)]

# FastAPI dependency
StreamingLlmDependency = Annotated[
    BaseChatModel, Depends(partial(get_llm_chat_service, streaming=True))
]

BotoSessionDep = Annotated[aioboto3.Session, Depends(get_boto_session)]
