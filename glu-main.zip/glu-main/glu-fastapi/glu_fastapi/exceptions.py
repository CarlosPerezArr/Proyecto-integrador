from fastapi import HTTPException
from starlette import status


class UnauthorizedException(HTTPException):
    """``HTTPException`` for unauthorized requests."""

    def __init__(self, detail: str = "Forbidden", **kwargs):
        """Returns HTTP 403"""
        super().__init__(status_code=status.HTTP_403_FORBIDDEN, detail=detail, **kwargs)


class UnauthenticatedException(HTTPException):
    """``HTTPException`` for unauthenticated requests."""

    def __init__(self):
        """Returns HTTP 401"""
        super().__init__(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Requires authentication",
        )


class NotFoundException(HTTPException):
    """``HTTPException`` for when a request needed data that could not be found."""

    def __init__(self, detail: str = "Not Found", **kwargs):
        """Returns HTTP 404"""
        super().__init__(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=detail,
            **kwargs,
        )
