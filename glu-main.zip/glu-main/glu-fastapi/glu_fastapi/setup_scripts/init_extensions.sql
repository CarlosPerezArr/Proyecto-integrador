-- Run this as your DB superuser while connected to the ``glu_test`` DB, e.g.,
-- ``psql -d glu_test -f glu_fastapi/setup_scripts/init_pgvector.sql``.

CREATE EXTENSION IF NOT EXISTS vector schema pg_catalog;
CREATE EXTENSION IF NOT EXISTS pg_trgm schema pg_catalog;
