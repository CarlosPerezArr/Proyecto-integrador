-- Run this as your DB superuser while connected to the postgres DB, e.g.,
-- ``psql postgres -f glu_fastapi/setup_scripts/init_test_user_and_db.sql``

-- NOTE: Yes, that's a password. I determined it was alright, because this is the test user, who only has access to the
-- test database, which gets created and blown away repeatedly, and never exists on a shared server.
CREATE USER glu_test WITH PASSWORD 'yzZfUjSUbdLbPUKCHDxY6z';
CREATE DATABASE glu_test WITH OWNER 'glu_test' ENCODING 'UTF8' LC_COLLATE = 'en_US.UTF-8' LC_CTYPE = 'en_US.UTF-8' TEMPLATE template0;
