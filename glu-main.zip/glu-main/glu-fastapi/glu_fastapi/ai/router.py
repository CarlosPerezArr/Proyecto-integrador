import uuid
from typing import Any, List, Annotated

from fastapi import APIRouter, status, Query, Path, Response, HTTPException
import structlog
from pydantic import ValidationError
from sqlmodel import select, delete

from glu_fastapi.external_services import get_embeddings, LlmDependency
from glu_fastapi.ai.services import AiMemoryService
from glu_fastapi.config import SettingsDep
from glu_fastapi.database.session import SqlSessionDep
from glu_fastapi.exceptions import NotFoundException
from glu_fastapi.ai.models import (
    AiMessage,
    AiMessageRead,
    AiMessageCreate,
    AiMemoryRead,
    AiMemory,
    AiMemoryCreate,
)

logger = structlog.get_logger()
router = APIRouter()


@router.post(
    "/message/",
    status_code=status.HTTP_201_CREATED,
    response_model=AiMessageRead,
)
async def create_aimessage(
    settings: SettingsDep,
    ai_message: AiMessageCreate,
    sql_session: SqlSessionDep,
    response: Response,
) -> Any:
    """Create a log of a message sent in a conversation to AI."""

    try:
        db_aimessage = AiMessage.model_validate(ai_message)
    except ValidationError as e:
        logger.error(f"Failed to validate AIMessage: {str(e)}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))

    embeddings = await get_embeddings([ai_message.message_content])
    db_aimessage.msg_embeddings = embeddings[0]
    sql_session.add(db_aimessage)
    sql_session.flush()
    sql_session.refresh(db_aimessage)

    response.headers["Location"] = router.url_path_for(
        "view_aimessage", aimessage_id=db_aimessage.id
    )

    return db_aimessage


@router.get(
    "/messages_in_session/{session_uuid}",
    response_model=List[AiMessageRead],
)
async def get_messages_in_session(
    sql_session: SqlSessionDep,
    session_uuid: str,
) -> Any:
    """List the ``AiMessage``s in a given session."""

    parsed_session_uuid = uuid.UUID(session_uuid)
    aimessages = sql_session.exec(
        select(AiMessage)
        .where(AiMessage.session_id == parsed_session_uuid)
        .order_by(AiMessage.created.desc())
    ).all()
    return aimessages


@router.get("/messages", response_model=List[AiMessageRead])
async def list_aimessages(
    sql_session: SqlSessionDep,
    offset: int = 0,
    limit: int = Query(default=20, le=20),
) -> Any:
    """List all the ``AiMessage``s."""

    return sql_session.exec(select(AiMessage).offset(offset).limit(limit)).all()


@router.get(
    "/messages/{aimessage_id}",
    response_model=AiMessageRead,
)
async def view_aimessage(
    sql_session: SqlSessionDep,
    aimessage_id: Annotated[int, Path(title="The ID of the AIMessage to be fetched.")],
) -> Any:
    """Retrieve a single ``AiMessage``."""

    ai_message = sql_session.exec(
        select(AiMessage).where(AiMessage.id == aimessage_id)
    ).one_or_none()
    if ai_message is not None:
        return ai_message

    raise NotFoundException(f"No such AiMessage(id={aimessage_id}).")


@router.delete(
    "/messages/{aimessage_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_aimessage(
    sql_session: SqlSessionDep,
    aimessage_id: Annotated[int, Path(title="The ID of the AiMessage to delete.")],
):
    """Delete a single ``AiMessage``."""

    delete_stmt = delete(AiMessage).where(AiMessage.id == aimessage_id)
    result = sql_session.exec(delete_stmt).first()
    logger.info(f"Deleted {result.rowcount} AiMessage record(s) for id={aimessage_id}")
    sql_session.flush()


@router.post(
    "/memories/",
    status_code=status.HTTP_201_CREATED,
    response_model=AiMemoryRead,
)
async def create_aimemory(
    ai_memory: AiMemoryCreate,
    sql_session: SqlSessionDep,
    response: Response,
) -> Any:
    """Create a memory."""

    db_aimemory = AiMemory.model_validate(ai_memory)
    sql_session.add(db_aimemory)
    sql_session.flush()
    sql_session.refresh(db_aimemory)

    response.headers["Location"] = router.url_path_for(
        "view_aimemory", aimemory_id=db_aimemory.id
    )

    return db_aimemory


@router.get(
    "/memories/{aimemory_id}", response_model=AiMemoryRead, name="view_aimemory"
)
async def view_aimemory(
    sql_session: SqlSessionDep,
    aimemory_id: int,
) -> Any:
    """Retrieve a single ``AiMemory``."""

    query = select(AiMemory).where(AiMemory.id == aimemory_id)
    ai_memory = sql_session.exec(query).one_or_none()
    if ai_memory is not None:
        return ai_memory

    raise NotFoundException("Memory not found")


@router.get(
    "/memories",
    response_model=List[AiMemoryRead],
)
async def view_aimemories(
    sql_session: SqlSessionDep,
) -> Any:
    """Retrieve all ``AiMemory`` records."""

    query = select(AiMemory)
    ai_memories = sql_session.exec(query).all()

    return ai_memories


@router.post(
    "/memories/summarize",
    response_model=AiMemoryRead,
)
async def summarize_aimemories(
    sql_session: SqlSessionDep,
    llm: LlmDependency,
) -> Any:
    """Summarize all ``AiMemory`` records."""

    memory_service = AiMemoryService(sql_session, llm)
    try:
        summary_memory = await memory_service.summarize_memories()
    except ValidationError as e:
        logger.error(f"Failed to validate AiMemory: {str(e)}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(e))
    else:
        return summary_memory
