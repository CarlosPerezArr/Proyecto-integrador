"""SQLModel models for AI-related things we need to store in our persistent storage."""

import enum
import uuid
from typing import Optional, List

from numpy import float32
from numpy._typing import NDArray
from pgvector.sqlalchemy import Vector
from pydantic import field_serializer

from sqlalchemy import Column, Uuid, Index, Integer, ForeignKey
from sqlmodel import Field, Relationship

from glu_fastapi.under_test.models import FunctionSpec, DeviceUnderTest
from glu_fastapi.per_tenant_models import OPENAI_DIMENSIONALITY, BaseTable


class AiMessageRole(enum.Enum):
    """The 'role' of an ``AiMessage``."""

    System = "system"
    User = "user"
    Assistant = "assistant"


class AiMessageBase(BaseTable):
    """Part of a 'conversation' between a User and the LLM."""

    email: str = Field(max_length=320, nullable=False)
    session_uuid: uuid.UUID = Field(
        sa_column=Column(Uuid, nullable=False), default_factory=uuid.uuid4
    )
    message_role: AiMessageRole
    # I picked the following arbitrary limit using the following heuristic:
    # 1. Start with the token limit for gpt-4-turbo as of 2024-04-28 (128k tokens)
    # 2. Half for input, half for output, so 64k tokens per message
    # 3. Each token is ~4 characters, so 262,144 characters in 64k tokens
    message_content: str = Field(max_length=262_144)
    functionspec_id: int = Field(
        sa_column=Column(
            Integer,
            ForeignKey(
                "functionspec.id",
                name="fk__aimessage__functionspec",
                ondelete="CASCADE",
            ),
            index=True,
            nullable=False,
        )
    )


class AiMessage(AiMessageBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    msg_embeddings: Optional[List[float]] = Field(
        default=None, sa_column=Column(Vector(OPENAI_DIMENSIONALITY))
    )

    function_spec: FunctionSpec = Relationship(back_populates="ai_messages")

    __table_args__ = (
        Index(
            "aimessage_email_created_at_index",
            "email",
            "created_at",
        ),
        Index(
            "aimessage_session_uuid_created_at_index",
            "session_uuid",
            "created_at",
        ),
        Index(
            "aimessage_functionspec_id_created_at_index",
            "functionspec_id",
            "created_at",
        ),
    )

    @field_serializer("msg_embeddings")
    def serialize_msg_embeddings(
        self, msg_embeddings: NDArray[float32], _info
    ) -> Optional[List[float]]:
        if msg_embeddings is None:
            return None

        return msg_embeddings.tolist()


class AiMessageCreate(AiMessageBase):
    pass


class AiMessageRead(AiMessageBase):
    id: int


class AiMemoryBase(BaseTable):
    """A little something for Brian Fioca."""

    notes: str = Field(nullable=False)


class AiMemory(AiMemoryBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)

class AiMemoryCreate(AiMemoryBase):
    pass


class AiMemoryUpdate(AiMemoryBase):
    pass


class AiMemoryRead(AiMemoryBase):
    id: int
