"""Service objects that are related to our records of AI interactions."""

from typing import List

import structlog
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_openai import ChatOpenAI
from sqlmodel import Session, delete, select

from glu_fastapi.ai.models import AiMemory, AiMemoryCreate

logger = structlog.get_logger()


# TODO: Update this with LangChain and injected dependencies
class AiMemoryService:
    """Business logic related to ``AiMemory``."""

    def __init__(
        self,
        sql_session: Session,
        llm: ChatOpenAI,
    ):
        self.sql_session = sql_session
        self.llm = llm

    async def get_user_notes_for_prompt(self):
        user_notes = "\n - ".join(
            memory.notes for memory in await self.fetch_all_memories()
        )
        return user_notes

    async def create_memory(self, ai_memory: AiMemoryCreate) -> AiMemory:
        """Create a new AiMemory."""
        db_aimemory = AiMemory.model_validate(ai_memory)
        self.sql_session.add(db_aimemory)
        self.sql_session.flush()
        self.sql_session.refresh(db_aimemory)
        return db_aimemory

    async def fetch_all_memories(self) -> List[AiMemory]:
        """Get all of our ``AiMemory`` records."""
        return self.sql_session.exec(select(AiMemory)).all()

    async def summarize_memories(self) -> AiMemory | None:
        """Summarize all of our ``AiMemory`` records down into one summary memory."""
        memories = self.sql_session.exec(select(AiMemory)).all()

        # If there are no memories to summarize, dip out right here.
        if len(memories) == 0:
            return None

        # Stringify the memories for the LLM.
        condensed_list = "\n".join(memory.notes for memory in memories)
        notes = f"""
        Notes:
        {condensed_list}
        """

        # TODO: Update this with more specific details about what we're looking for

        # summarize them with the LLM
        prompt = f"""
        Summarize the following list of notes taken during conversations with users working on writing test plans for electronics hardware.
        When possible, come up with categories for organizing the notes.
        If there are conflicting notes, take the most recent (ordered from top to bottom) as the note to keep.
        Remove any notes that aren't useful or unclear.
        If there are already categorize but they can be reorganized or additional ones can be created, please do so.
        The goal is to keep these to a single page.

        {notes}
        """

        messages = [
            SystemMessage(
                content="""
                You are an assistant.
                Your job is to organize notes about previous interactions for future reference when writing test plans for electronic hardware.
                """
            ),
            HumanMessage(content=prompt),
        ]

        logger.debug("About to invoke LLM", prompt=prompt)
        structured_llm = self.llm.with_structured_output(AiMemoryCreate)
        summarized_memory = await structured_llm.ainvoke(messages)
        logger.debug("LLM is back", results=summarized_memory)

        # Make sure what they gave us back is a valid memory. If it fails validation, let the exception propagate back
        # up to the router layer, where we will translate it into an HTTP error.
        db_memory = AiMemory.model_validate(summarized_memory)

        # Delete the old memories.
        self.sql_session.exec(delete(AiMemory))

        # Insert the new memory.
        self.sql_session.add(db_memory)
        self.sql_session.flush()
        self.sql_session.refresh(db_memory)

        # Return it.
        return db_memory
