from itertools import zip_longest
from typing import Union, List, Tuple, Optional
import magic
import pypdfium2 as pdfium
from PIL import Image
import pandas as pd
import docx2pdf
import io
import tempfile
import os
from langchain_core.messages import HumanMessage
import base64
from docx import Document
import math
import logging

logger = logging.getLogger(__name__)


class DocumentProcessor:
    """Base class for processing various document types."""

    SUPPORTED_IMAGE_TYPES = {
        "application/pdf",
        "application/msword",  # .doc
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",  # .docx
    }

    SUPPORTED_TEXT_TYPES = {
        "text/plain",
        "text/csv",
        "application/json",
        "text/markdown",
        "application/xml",
        "text/xml",
        "application/vnd.ms-excel",  # .xls
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",  # .xlsx
    }

    def __init__(self):
        self.mime = magic.Magic(mime=True)

    def process_files(
        self,
        files: Union[bytes, List[bytes]],
        descriptions: Union[str, List[str]],
        lines_per_page: int = 30,
    ) -> List[Tuple[Union[List[Image.Image], List[str]], str]]:
        """
        Process one or multiple files with their descriptions

        Args:
            files: Single file content or list of file contents as bytes
            descriptions: Single description or list of descriptions
            lines_per_page: Number of lines per page for text documents

        Returns:
            List of tuples containing (processed_content, description)
            processed_content is either:
                - Tuple[List[Image.Image], List[str]] for image documents
                - List[str] for text documents (paginated)
        """
        if not isinstance(files, list):
            files = [files]
        if not isinstance(descriptions, list):
            descriptions = [descriptions] * len(files)

        if len(files) != len(descriptions):
            raise ValueError("Number of files and descriptions must match")

        results = []
        for file_content, description in zip(files, descriptions):
            processed = self._process_single_file(file_content, lines_per_page)
            results.append((processed, description))

        return results

    def _process_single_file(
        self, content: bytes, lines_per_page: int
    ) -> Union[Tuple[List[Image.Image], List[str]], List[str]]:
        """Process a single file based on its type"""
        mime_type = self.mime.from_buffer(content)

        if mime_type in self.SUPPORTED_IMAGE_TYPES:
            return self._process_document_to_images_and_text(content, mime_type)
        elif mime_type in self.SUPPORTED_TEXT_TYPES:
            text_content = self._process_text_document(
                content, mime_type, lines_per_page
            )
            return (
                ([], text_content)
                if isinstance(text_content, list)
                else ([], [text_content])
            )
        else:
            raise ValueError(f"Unsupported file type: {mime_type}")

    def _extract_text_from_pdf(self, content: bytes) -> str:
        """Extract text from PDF using PDFium"""
        pdf = pdfium.PdfDocument(content)
        text_content = []

        for page_number in range(len(pdf)):
            page = pdf.get_page(page_number)
            textpage = page.get_textpage()
            text = textpage.get_text_range()
            text_content.append(text)

        return "\n".join(text_content)

    def _extract_text_from_docx(self, content: bytes) -> List[str]:
        """Extract text directly from a Word document, split by sections/pages"""
        doc = Document(io.BytesIO(content))

        pages = []
        current_page = []
        current_length = 0
        avg_chars_per_page = 3000  # Approximate characters per page

        def add_to_current_page(text: str):
            nonlocal current_length
            current_page.append(text)
            current_length += len(text)

            # If we've exceeded the average page length, start a new page
            if current_length >= avg_chars_per_page:
                pages.append("\n".join(current_page))
                current_page.clear()
                current_length = 0

        # Process paragraphs and tables
        for element in doc.element.body:
            if element.tag.endswith("p"):  # Paragraph
                paragraph = element.text.strip()
                if paragraph:
                    add_to_current_page(paragraph)

            elif element.tag.endswith("tbl"):  # Table
                table_text = []
                for row in element.findall(
                    ".//w:tr",
                    {
                        "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
                    },
                ):
                    cells = [
                        cell.text.strip()
                        for cell in row.findall(
                            ".//w:t/..",
                            {
                                "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
                            },
                        )
                    ]
                    if any(cells):
                        table_text.append(" | ".join(filter(None, cells)))
                if table_text:
                    add_to_current_page("\n".join(table_text))

            # Check for explicit page breaks
            if (
                element.tag.endswith("sectPr")
                or element.find(
                    './/w:br[@w:type="page"]',
                    {
                        "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
                    },
                )
                is not None
            ):
                if current_page:
                    pages.append("\n".join(current_page))
                    current_page.clear()
                    current_length = 0

        # Add any remaining content as the last page
        if current_page:
            pages.append("\n".join(current_page))

        return (
            pages if pages else [""]
        )  # Return at least one empty page if document is empty

    def _process_document_to_images_and_text(
        self, content: bytes, mime_type: str
    ) -> Tuple[List[Image.Image], List[str]]:
        """Convert document pages to both images and text"""
        images = []
        text_pages = []

        if mime_type == "application/pdf":
            images = self._pdf_to_images(content)
            text_content = self._extract_text_from_pdf(content)
            # Split PDF text by form feeds or a reasonable number of newlines
            text_pages = (
                text_content.split("\f")
                if "\f" in text_content
                else text_content.split("\n\n\n")
            )

        elif mime_type in {
            "application/msword",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        }:
            # Get text content
            text_pages = self._extract_text_from_docx(content)

            # Convert to PDF for images
            pdf_content = self._word_to_pdf(content)
            images = self._pdf_to_images(pdf_content)

        # Ensure we have same number of text pages as images
        # If not, pad shorter list with empty content
        if len(images) > len(text_pages):
            text_pages.extend([""] * (len(images) - len(text_pages)))
        elif len(text_pages) > len(images):
            text_pages = text_pages[: len(images)]

        return images, text_pages

    def _pdf_to_images(self, content: bytes) -> List[Image.Image]:
        """Convert PDF to list of images using pypdfium"""
        pdf = pdfium.PdfDocument(content)
        images = []

        for page_number in range(len(pdf)):
            page = pdf.get_page(page_number)
            pil_image = page.render(scale=1).to_pil()
            images.append(pil_image)

        return images

    def _word_to_pdf(self, content: bytes) -> bytes:
        """Convert Word document to PDF"""
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as temp_docx:
            temp_docx.write(content)
            docx_path = temp_docx.name

        pdf_path = docx_path + ".pdf"
        docx2pdf.convert(docx_path, pdf_path)

        with open(pdf_path, "rb") as pdf_file:
            pdf_content = pdf_file.read()

        os.unlink(docx_path)
        os.unlink(pdf_path)

        return pdf_content

    def _paginate_text(self, text: str, lines_per_page: int) -> List[str]:
        """Split text into pages based on number of lines"""
        lines = text.split("\n")
        total_pages = math.ceil(len(lines) / lines_per_page)
        pages = []

        for page_num in range(total_pages):
            start_idx = page_num * lines_per_page
            end_idx = start_idx + lines_per_page
            page_content = "\n".join(lines[start_idx:end_idx])
            pages.append(page_content)

        return pages

    def _normalize_newlines(self, text: str) -> str:
        """Normalize multiple consecutive newlines to maximum of 2"""
        import re

        return re.sub(r"\n{3,}", "\n\n", text)

    def _excel_to_csv(self, content: bytes) -> str:
        """Convert any Excel file (xls or xlsx) to CSV string"""
        try:
            # Try reading as xlsx first
            df = pd.read_excel(io.BytesIO(content), engine="openpyxl", sheet_name=None)
        except Exception:
            # Fall back to xlrd for xls files
            df = pd.read_excel(io.BytesIO(content), engine="xlrd", sheet_name=None)

        # Combine all sheets and remove empty rows
        combined_df = pd.concat(df.values(), ignore_index=True)
        combined_df = combined_df.dropna(how="all")

        # Convert to CSV string
        csv_buffer = io.StringIO()
        combined_df.to_csv(csv_buffer, index=False)
        return csv_buffer.getvalue()

    def _process_csv(self, content: str) -> str:
        """Process CSV content with standardized handling"""
        df = pd.read_csv(io.StringIO(content), skip_blank_lines=True)
        df = df.dropna(how="all")

        csv_buffer = io.StringIO()
        df.to_csv(csv_buffer, index=False)
        return self._normalize_newlines(csv_buffer.getvalue())

    def _process_text_document(
        self, content: bytes, mime_type: str, lines_per_page: int
    ) -> List[str]:
        """Process text-based documents with pagination and normalized newlines"""
        text_content = ""

        if mime_type in {
            "application/vnd.ms-excel",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        }:
            # Convert Excel to CSV first
            csv_content = self._excel_to_csv(content)
            text_content = self._process_csv(csv_content)
        elif mime_type == "text/csv":
            text_content = self._process_csv(content.decode("utf-8"))
        elif mime_type in {"text/plain", "text/markdown", "application/json"}:
            text_content = self._normalize_newlines(
                content.decode("utf-8", errors="replace")
            )
        elif mime_type in {"application/xml", "text/xml"}:
            text_content = self._normalize_newlines(self._process_xml(content))

        return self._paginate_text(text_content, lines_per_page)


class LangChainDocumentProcessor(DocumentProcessor):
    """Extension of DocumentProcessor for LangChain integration with proper pagination."""

    def process_to_messages(
        self,
        files: Union[bytes, List[bytes]],
        descriptions: Union[str, List[str]] = [],
        lines_per_page: int = 20,
    ) -> List[HumanMessage]:
        """
        Process files and convert them to LangChain HumanMessages with pagination.
        Creates one message per page.

        Args:
            files: Single file content or list of file contents as bytes
            descriptions: Single description or list of descriptions
            lines_per_page: Number of lines per page for text documents

        Returns:
            List of LangChain HumanMessages, one per page
        """
        if not isinstance(files, list):
            files = [files]

        if not isinstance(descriptions, list):
            descriptions = [descriptions] * len(files)
        elif len(descriptions) < len(files):
            descriptions.extend([None] * (len(files) - len(descriptions)))

        results = self.process_files(files, descriptions, lines_per_page)
        messages = []

        for (images, text_pages), description in results:
            # Create messages for each page in the document
            file_messages = self._create_paginated_messages(
                images, text_pages, description
            )
            messages.extend(file_messages)

        return messages

    def _create_paginated_messages(
        self,
        images: List[Image.Image],
        text_pages: List[str],
        description: Optional[str] = None,
    ) -> List[HumanMessage]:
        """
        Create separate HumanMessages for each page of content.

        Args:
            images: List of page images
            text_pages: List of page texts
            description: Optional document description

        Returns:
            List of HumanMessages, one per page
        """
        messages = []

        # Handle empty documents
        if not images and not text_pages:
            return [
                HumanMessage(
                    content=[{"type": "text", "text": description or "Empty document"}]
                )
            ]

        # Process each page
        for page_num, (image, text) in enumerate(zip_longest(images, text_pages), 1):
            message_content = []

            # Add description only to first page
            if page_num == 1 and description:
                message_content.append(
                    {"type": "text", "text": f"Document content: {description}"}
                )

            # Add page number and text if available
            if text is not None:
                message_content.append(
                    {"type": "text", "text": f"Page {page_num} Text:\n{text}"}
                )

            # Add image if available
            if image is not None:
                buffer = io.BytesIO()
                image.save(buffer, format="JPEG")
                img_str = base64.b64encode(buffer.getvalue()).decode()

                message_content.append(
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{img_str}",
                            "detail": "high",
                        },
                    }
                )

            # Only create a message if we have content
            if message_content:
                messages.append(HumanMessage(content=message_content))

        return messages
