"""Internal models for GLU (multitenancy machinery, mostly)."""

from typing import Optional

from sqlmodel import Field, SQLModel


class Tenant(SQLModel, table=True):
    """Represents a customer with their own tenancy in our db."""

    id: Optional[int] = Field(default=None, primary_key=True)
    name: str = Field(nullable=False, unique=True, max_length=255)
    their_schema: str = Field(nullable=False, unique=True, max_length=1023)
    host: str = Field(nullable=False, index=True, unique=True, max_length=1023)
    org_id: str = Field(nullable=True, index=True, unique=True, max_length=64)

    # NOTE: This is hardwired to appear only in the 'shared' schema.
    __table_args__ = {"schema": "shared"}
