"""Functions that are more implementation-related than business logic-related."""

from urllib.parse import urlparse

import structlog
from fastapi import HTTPException, Request, status
from sqlmodel import select, Session, SQLModel
from sqlalchemy import MetaData

from glu_fastapi.config import glu_settings
from glu_fastapi.database import get_engine
from glu_fastapi.shared_models import Tenant


logger = structlog.get_logger()


def tenant_for_user(user: "User") -> Tenant:  # noqa: F821
    """Given the info on ``user``, look up the relevant ``Tenant``."""

    return _look_up_tenant_by_org_id(user.org_id)


def tenant_for_request(req: Request) -> Tenant:
    """Inspect ``request`` and figure out which ``Tenant`` it should operate against."""
    referer = req.headers.get("referer", None)
    redirect_from_query_param = req.query_params.get("redirect_to", None)
    redirect_from_session = req.session.get("redirect_to", None)
    logger.debug("REFERER", referer=referer)
    logger.debug("QUERY_PARAM", query_param=redirect_from_query_param)
    logger.debug("SESSION", session=redirect_from_session)
    on_behalf_of = (
        redirect_from_session  # /callback
        or redirect_from_query_param  # /login
        or referer  # Everything else.
    )
    logger.debug("Come on, buddy!", on_behalf_of=on_behalf_of)

    if on_behalf_of is None:
        logger.debug("None of the standard/common request auth stuff was there.")
        # Maybe this is the super-special case of accepting an invitation? Don't raise a 401 until we check.
        if (
            req.url.path == "/login"
            and req.query_params.get("invitation", None) is not None
        ):
            logger.debug("Because it is them trying to accept an invite")
            org_id = req.query_params.get("organization", None)
            if org_id is None:
                logger.warn("Nope! Chuck Testa!")
                # Well if they're trying to accept an invitation, they forgot to bring it with them.
                raise HTTPException(status.HTTP_401_UNAUTHORIZED)

            logger.debug("Yep! Let's see if it pays off for them, Cotton.")
            t = _look_up_tenant_by_org_id(org_id)
            if t is None:
                # They brought an invitation, it's just fake/expired/hosed-in-some-other-way.
                logger.warn(
                    "User tried to accept invitation to Org we can't find.",
                    invite_params=req.query_params,
                )
                raise HTTPException(status.HTTP_401_UNAUTHORIZED)

            return t

    host_without_port = _extract_host_sans_port(urlparse(on_behalf_of).hostname)
    t = _look_up_tenant_by_host(host_without_port)
    if t is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED)

    return t


def _extract_host_sans_port(host_header: str) -> str | None:
    if host_header is None:
        return None

    host_without_port = host_header.split(":", 1)[0]
    # It's a bit of a dirty hack, but for now: treat 'localhost' the same as we treat the develop preview deployment.
    if host_without_port == "localhost":
        host_without_port = "api3.glu.ngrok.dev"
    return host_without_port


def _look_up_tenant_by_org_id(org_id: str) -> Tenant:
    engine = get_engine(glu_settings())
    with Session(engine) as session:
        select_stmt = select(Tenant).where(Tenant.org_id == org_id)
        t = session.exec(select_stmt).first()
    return t


def _look_up_tenant_by_host(host_without_port: str) -> Tenant | None:
    if host_without_port is None:
        return None

    engine = get_engine(glu_settings())
    with Session(engine) as session:
        select_stmt = select(Tenant).where(Tenant.host == host_without_port)
        t = session.exec(select_stmt).first()
    return t


def get_per_tenant_metadata() -> MetaData:
    """Get the SQLModel metadata for *ONLY* the per-tenant tables, etc."""

    meta = MetaData()
    for table in SQLModel.metadata.tables.values():
        if table.schema is None:
            table.tometadata(meta)
    return meta
