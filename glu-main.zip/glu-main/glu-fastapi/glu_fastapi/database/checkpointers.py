from typing import Annotated

from fastapi import Depends
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from psycopg import AsyncConnection

from glu_fastapi.auth import WsTenantDep, TenantDep
from glu_fastapi.config import glu_settings


async def get_http_async_checkpointer(tenant: TenantDep) -> AsyncPostgresSaver:
    s = glu_settings()
    schema_specific_conn_string = (
        f"{s.psycopg_url} options='-c search_path={tenant.their_schema}'"
    )
    # NOTE: Autocommit is required for this to function
    async with await AsyncConnection.connect(
        conninfo=schema_specific_conn_string,
        autocommit=True,
        prepare_threshold=0,
    ) as aconn:
        yield AsyncPostgresSaver(aconn)


async def get_ws_async_checkpointer(tenant: WsTenantDep) -> AsyncPostgresSaver:
    s = glu_settings()
    schema_specific_conn_string = (
        f"{s.psycopg_url} options='-c search_path={tenant.their_schema}'"
    )
    # NOTE: Autocommit is required for this to function
    async with await AsyncConnection.connect(
        conninfo=schema_specific_conn_string,
        autocommit=True,
        prepare_threshold=0,
    ) as aconn:
        yield AsyncPostgresSaver(aconn)


HttpAsyncCheckpointerDep = Annotated[
    AsyncPostgresSaver, Depends(get_ws_async_checkpointer)
]
WsAsyncCheckpointerDep = Annotated[
    AsyncPostgresSaver, Depends(get_ws_async_checkpointer)
]
