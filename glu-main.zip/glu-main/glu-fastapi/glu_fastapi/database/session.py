from typing import Generator, Annotated

import structlog
from fastapi import Depends
from sqlmodel import Session

from glu_fastapi.auth import TenantDep, WsTenantDep
from glu_fastapi.database import EngineDep


logger = structlog.get_logger()


def get_sqlmodel_session(
    tenant: TenantDep, engine: EngineDep
) -> Generator[Session, None, None]:
    host_to_schema = {None: tenant.their_schema}
    logger.info("Setting up schema translation for tenant.", mapping=host_to_schema)
    engine.update_execution_options(schema_translate_map=host_to_schema)
    with Session(engine) as session:
        try:
            yield session
        except Exception as e:
            session.rollback()
            raise e
        else:
            session.commit()


def get_sqlmodel_session_for_websocket(
    tenant: WsTenantDep, engine: EngineDep
) -> Generator[Session, None, None]:
    host_to_schema = {None: tenant.their_schema}
    logger.info("Setting up schema translation for tenant.", mapping=host_to_schema)
    engine.update_execution_options(schema_translate_map=host_to_schema)
    with Session(engine) as session:
        try:
            yield session
        except Exception as e:
            session.rollback()
            raise e
        else:
            session.commit()


SqlSessionDep = Annotated[Session, Depends(get_sqlmodel_session)]
WsSqlSessionDep = Annotated[Session, Depends(get_sqlmodel_session_for_websocket)]
