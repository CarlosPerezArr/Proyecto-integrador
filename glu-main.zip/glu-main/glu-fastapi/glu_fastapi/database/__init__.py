from typing import Annotated

from fastapi import Depends
from sqlalchemy import Engine, create_engine
from sqlmodel import Session

from glu_fastapi.config import SettingsDep


def get_engine(settings: SettingsDep) -> Engine:
    connect_args = {}
    if settings.sqlalchemy_url.startswith("sqlite"):
        connect_args["check_same_thread"] = False
    return create_engine(settings.sqlalchemy_url, echo=True, connect_args=connect_args)


EngineDep = Annotated[Session, Depends(get_engine)]
