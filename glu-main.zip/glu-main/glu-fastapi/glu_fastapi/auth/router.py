import secrets
from urllib.parse import urlparse, urlencode
from typing import Annotated, Optional

import structlog
from authlib.integrations.starlette_client import OAuth
from fastapi import Request, Depends, APIRouter, HTTPException, status
from fastapi.responses import RedirectResponse

from glu_fastapi.auth import get_auth0_oauth_client
from glu_fastapi.config import SettingsDep
from glu_fastapi.middleware_utils import get_allowed_hosts
from glu_fastapi.multitenancy import tenant_for_request
from glu_fastapi.shared_models import Tenant


logger = structlog.get_logger()
OauthDep = Annotated[OAuth, Depends(get_auth0_oauth_client)]
TenantDep = Annotated[Tenant, Depends(tenant_for_request)]
router = APIRouter()


@router.get("/login")
async def login(
    request: Request,
    oauth: OauthDep,
    tenant: TenantDep,
    redirect_to: Optional[str] = None,
    invitation: Optional[str] = None,
    organization: Optional[str] = None,
    organization_name: Optional[str] = None,
) -> RedirectResponse:
    logger.debug(
        "logging in",
        invitation_id=invitation,
        org_id=organization,
        org_name=organization_name,
    )
    callback_url = request.url_for("callback")
    if organization is None:
        organization = tenant.org_id

    try:
        # OAuth2 uses a special 'state' param to protect against CSRF. They recommend doing this before taking any
        # action based on session state that might predate auth.
        nonce = secrets.token_urlsafe(16)
        request.session["nonce"] = nonce
        logger.debug("login: Just put 'nonce' in session.", we_stored=nonce)
        logger.debug(
            "login: Checking the store has it now.", they_have=request.session["nonce"]
        )
        logger.debug("login: Show me the /login cookies!.", cookies=request.cookies)
        if redirect_to is not None:
            logger.debug(
                "They *SHOULD* get redirected after login.", redirect_to=redirect_to
            )
            request.session["redirect_to"] = redirect_to
        elif invitation is not None:
            logger.debug(
                "They're accepting an invitation, so we will redirect to the index page of their tenant."
            )
            request.session["redirect_to"] = f"https://{tenant.host}/"
        logger.debug(
            "About to do the authorize_redirect dance.",
            state=nonce,
            redirect_to=redirect_to,
        )

        redirect = await oauth.auth0.authorize_redirect(
            request,
            redirect_uri=callback_url,
            organization=organization,
            invitation=invitation,
            state=nonce,
        )
    except Exception as e:  # noqa
        logger.exception("Unexpected error during auth.")
        bail_to_here = request.url_for("list_test_bench_devices")
        return RedirectResponse(url=bail_to_here)
    else:
        return redirect


@router.get("/callback")
@router.post("/callback")
async def callback(
    settings: SettingsDep, oauth: OauthDep, request: Request
) -> RedirectResponse:
    # Give ourselves a good fallback in case we can't redirect to the originally requested page for whatever reason.
    # TODO: create a config for these endpoints vs hardcoded
    landing_page = (
        "https://web4.glu.ngrok.dev/"
        if settings.hosting_env == "development"
        else "https://glutest.ai/"
    )

    try:
        # First up, verify *our* nonces match.
        nonce_from_req = request.query_params["state"]
        logger.debug("callback: They called us back.", state=nonce_from_req)
        logger.debug(
            "callback: Show me the /callback cookies!.", cookies=request.cookies
        )
        nonce_from_session = request.session["nonce"]
        if nonce_from_session != nonce_from_req:
            logger.debug(
                "Unfortunate: the nonces don't match.",
                incoming=nonce_from_req,
                locally_stored=nonce_from_session,
            )
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST)

        # If our nonces match, then verify everything with Auth0.
        token = await oauth.auth0.authorize_access_token(request)
        logger.debug("Got a token from auth0", token=token)
    except Exception as e:  # noqa
        logger.exception("Unexpected error during auth.")
        return RedirectResponse(url=landing_page)

    # Look up tenant *NOW*, when we should have a redirect target. If we do
    # it during the dependency injection phase, it won't work because the
    # session will not be properly set up yet.
    tenant = tenant_for_request(request)
    token["tenant_info"] = {"name": tenant.name}
    request.session["user"] = token
    requested_redirect_target = request.session.get("redirect_to", landing_page)
    logger.debug("They asked for it.", redirect_to=requested_redirect_target)
    host_allow_list = get_allowed_hosts()
    redirect_target_host = urlparse(requested_redirect_target).hostname

    for pattern in host_allow_list:
        if redirect_target_host == pattern or (
            pattern.startswith("*") and redirect_target_host.endswith(pattern[1:])
        ):
            logger.debug(
                "Valid redirect request.",
                redirect_to=requested_redirect_target,
                allowed_hosts=host_allow_list,
            )
            landing_page = requested_redirect_target

    return RedirectResponse(url=landing_page)


@router.get("/logout")
async def logout(request: Request, settings: SettingsDep) -> RedirectResponse:
    request.session.clear()

    # After they log out, send them to the "hello" endpoint.
    # TODO: create a config for these endpoints vs hardcoded
    if settings.hosting_env == "development":
        come_back_to_me = "https://web1.glu.ngrok.dev/"
    else:
        come_back_to_me = "https://glutest.ai/"
    redirect_params = {
        "returnTo": come_back_to_me,
        "client_id": settings.auth0_client_id,
    }
    qs = urlencode(redirect_params)
    redirect_url = f"https://{settings.auth0_domain}/v2/logout?{qs}"
    return RedirectResponse(url=redirect_url)
