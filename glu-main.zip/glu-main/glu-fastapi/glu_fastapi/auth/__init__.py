from base64 import b64decode
from typing import Optional, List, Annotated, Union

import itsdangerous
import orjson as json
import pendulum
import structlog
import os

from authlib.integrations.starlette_client import OAuth
from fastapi import Depends, Request, WebSocket, WebSocketException, status
from itsdangerous import BadSignature
from pydantic import BaseModel, Field

from glu_fastapi.config import SettingsDep
from glu_fastapi.exceptions import UnauthorizedException, UnauthenticatedException
from glu_fastapi.multitenancy import tenant_for_request, tenant_for_user
from glu_fastapi.shared_models import Tenant


logger = structlog.get_logger()
TenantDep = Annotated[Tenant, Depends(tenant_for_request)]


class UserRead(BaseModel):
    name: str
    email: str
    email_verified: bool = False
    company_name: Optional[str] = Field(default=None)
    avatar_url: Optional[str] = Field(default=None)


class User(UserRead):
    org_id: str
    scopes: List[str] = Field(default_factory=list)


def get_auth0_oauth_client(settings: SettingsDep) -> OAuth:
    """Get an OAuth client for Auth0."""
    oauth = OAuth()
    oauth.register(
        "auth0",
        client_id=settings.auth0_client_id,
        client_secret=settings.auth0_client_secret,
        client_kwargs={
            "scope": "openid profile email",
        },
        server_metadata_url=f"https://{settings.auth0_domain}/.well-known/openid-configuration",
    )
    return oauth


async def get_current_user_for_ws(web_socket: WebSocket) -> Optional[User]:
    """Pull the current `User` out of the session."""
    return web_socket.scope.get("user", None)


async def get_user_from_extracted_cookie_data(data, settings):
    signer = itsdangerous.TimestampSigner(settings.auth0_client_secret)
    try:
        data = signer.unsign(data, max_age=24 * 60 * 60)
        cookie_as_dict = json.loads(b64decode(data))
        logger.debug(
            "Decoded, verified, and parsed the cookie payload.", cookie=cookie_as_dict
        )
        return _user_from_parsed_auth0_token(cookie_as_dict.get("user", None))
    except BadSignature:
        logger.error("Tampering with cookies!? Bad user! No biscuit!")
        return None


async def get_current_user(request: Request) -> Optional[User]:
    """Pull the current `User` out of the session."""
    return request.scope.get("user", None)


# function that only exists when we're using PYTEST: PYTEST=True poetry run pytest
if os.getenv("PYTEST"):

    def user_from_parsed_auth0_token(token):
        print("user_from_parsed_auth0_token only available during testing.")
        return _user_from_parsed_auth0_token(token)


def _user_from_parsed_auth0_token(token):
    """Turn an auth0 user token (previously decoded) into a ``User``.

    The following is a sample of an actual token that we got from Auth0::

        {
          'access_token': 'eyJhbGciOiJkaXIiLCJlbmMiOiJBMjU2R0NNIiwiaXNzIjoiaHR0cHM6Ly9nbHV0ZXN0LnVzLmF1dGgwLmNvbS8ifQ..rpCE9q90JpskvTsY.pM5DCTAUJAwAEaszv-k7z-mLPcR5GvRwUeBVjrsc_i3KKhUNH80GKkEvsB-V-MFSUubRoUatz1T69Tsq5zOoxAVGaN7nkXp7IUc5EujeX7dcJ75F7UMsOYKFEMJzT1AxgbkleUOP2iVkbfePEMFitsmxuY4EonWhltVaLMb6Q-hWVVD93mJCgP5I5TCG0MNAyv2ppC1xcb0D2DhXgUFZHn8rF6qup5VPzSJCdCJHTzp0RJ4F9YfP2DGAtE3MY3-hJWnzwwmVxhNuc2y4ilUuwa4X2EAdWMszmWdjRUjt-jOFHZTVKT9zEvNju-tus2uLPob9gPpNUZWXB4_JEmcUZQcWlFjh5awgLMGNZpQ.9BsnjJ_G29gXxU-3lyq6BA',
          'id_token': 'eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IllLaDNEQUJJaVhUckJlb0JfaUYxaCJ9.eyJnaXZlbl9uYW1lIjoiQnJpYW4iLCJmYW1pbHlfbmFtZSI6IkZpb2NhIiwibmlja25hbWUiOiJicmlhbiIsIm5hbWUiOiJCcmlhbiBGaW9jYSIsInBpY3R1cmUiOiJodHRwczovL2xoMy5nb29nbGV1c2VyY29udGVudC5jb20vYS9BQ2c4b2NMU3BxVmVBZ1Q3TkpXVXZ4SVZtSUJWcUhiOHhtM2VaNDBXdGk0a3dXdjIwQlgyYjhrPXM5Ni1jIiwibG9jYWxlIjoiZW4iLCJ1cGRhdGVkX2F0IjoiMjAyNC0wNC0xMFQyMjoyODozNy4zOTlaIiwiZW1haWwiOiJicmlhbkBwaW9uZWVyc3F1YXJlbGFicy5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwiaXNzIjoiaHR0cHM6Ly9nbHV0ZXN0LnVzLmF1dGgwLmNvbS8iLCJhdWQiOiJLZ3gzWXRLeFpzSHp5NEcwQVlKUTlpSEVMQjJxV0FtRSIsImlhdCI6MTcxMjc4ODExOCwiZXhwIjoxNzEyODI0MTE4LCJzdWIiOiJnb29nbGUtb2F1dGgyfDEwODkwMzI0MDcyMTg1MjEwMTU5OSIsInNpZCI6ImwyUTAwQThMU2Rud3dmb2RBOGVZR3RQWU5xcGFaYWZ5Iiwibm9uY2UiOiJHQ0c4NnV0OUV1dmlCOEN4OTc4TyIsIm9yZ19pZCI6Im9yZ19IaWY5ZTB3Z1JQa0FYSzcwIn0.NBEg2LuK-jIvr7RIIK9GD0MUYRr_7FXedIr-Jd776sWHYjYaE26s5Rg7g3tMefs02X09zJ5pVtNhalxsb-wh505DShpbLUpu7OFmYgi7Lv79QwtmV8Ahip5F0b0WHQmHgyxz_tLH8q6WXUBD8LITlT5WUoVMloHafbXrUw7WmcqWiO--2Gn4uK4ky9R5yXrgKwkkoN96WU8hT70TlLAREQJ90V-fimFzZd3Wn9De5X7QBSYp_RMqwCDIOZaK63LCNNSIcLX1mgEDNlWMBUfLf7fC61lqUOvmjssBZ_TjDhAQd0nGrwTEcsY_2Q7_pXsL071UiZYz0zP_jdHQ3vqFeQ',
          'scope': 'openid profile email',
          'expires_in': 86400,
          'token_type': 'Bearer',
          'expires_at': 1712874518,
          'userinfo': {
            'given_name': 'Brian',
            'family_name': 'Fioca',
            'nickname': 'brian',
            'name': 'Brian Fioca',
            'picture': 'https://lh3.googleusercontent.com/a/ACg8ocLSpqVeAgT7NJWUvxIVmIBVqHb8xm3eZ40Wti4kwWv20BX2b8k=s96-c',
            'locale': 'en',
            'updated_at': '2024-04-10T22:28:37.399Z',
            'email': 'brian@pioneersquarelabs.com',
            'email_verified': True,
            'iss': 'https://glutest.us.auth0.com/',
            'aud': 'Kgx3YtKxZsHzy4G0AYJQ9iHELB2qWAmE',
            'iat': 1712788118,
            'exp': 1712824118,
            'sub': 'google-oauth2|108903240721852101599',
            'sid': 'l2Q00A8LSdnwwfodA8eYGtPYNqpaZafy',
            'nonce': 'GCG86ut9EuviB8Cx978O',
            'org_id': 'org_Hif9e0wgRPkAXK70'
          }
        }
    """
    if token is None:
        logger.info("No token on the request, so no user.")
        return None
    expiry = token["expires_at"]
    expiry = pendulum.from_timestamp(expiry, tz="UTC")
    now = pendulum.now("UTC")
    if expiry < now:
        logger.info("The token was expired, so no user.")
        return None
    userinfo = token["userinfo"]
    user = User(
        name=userinfo["name"],
        email=userinfo["email"],
        email_verified=userinfo["email_verified"],
        scopes=token["scope"].split(" "),
        org_id=userinfo["org_id"],
        avatar_url=userinfo.get("picture", None),
    )
    logger.debug("We extracted a User from the token", user=user)
    return user


async def require_logged_in_user(request: Request, tenant: TenantDep) -> User:
    """Get the current user, or raise HTTPExceptions if not logged in or the Tenant and User orgs don't match."""

    user = await get_current_user(request)

    if user is None:
        logger.error("no user")
        raise UnauthenticatedException()

    if tenant.org_id != user.org_id:
        logger.error(
            "Auth for HTTP failed: user-tenant mismatch", user=user, tenant=tenant
        )
        raise UnauthorizedException()

    user.company_name = tenant.name
    return user


async def require_logged_in_user_ws(web_socket: WebSocket) -> User:
    """Get the current user, or raise WebSocketException if not logged in or the Tenant and User orgs don't match."""

    user = await get_current_user_for_ws(web_socket)
    if user is None:
        logger.error("no user")
        raise WebSocketException(
            code=status.WS_1008_POLICY_VIOLATION, reason="No valid user on the socket."
        )

    t = tenant_for_user(user)
    if t is None:
        logger.error("Auth for WS failed: user-tenant mismatch", user=user, tenant=t)
        raise WebSocketException(
            code=status.WS_1008_POLICY_VIOLATION,
            reason="Invalid User-Host combination.",
        )

    return user


LoggedInUserDep = Annotated[Union[User, None], Depends(require_logged_in_user)]
LoggedInUserWsDep = Annotated[Union[User, None], Depends(require_logged_in_user_ws)]


async def tenant_for_ws(user: LoggedInUserWsDep) -> Tenant:
    return tenant_for_user(user)


WsTenantDep = Annotated[Tenant, Depends(tenant_for_ws)]
