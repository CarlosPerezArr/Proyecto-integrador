import datetime
import uuid
from fastapi import WebSocket, status, APIRouter
from typing import Dict, Any
import json
import asyncio
from logging import getLogger

from .models import TestBench, TestBenchDevice, ToolExtractionResult
from .services import LabBenchToolsService

from glu_fastapi.external_services import LlmDependency
from glu_fastapi.database.session import WsSqlSessionDep

logger = getLogger(__name__)
router = APIRouter()


class WebSocketFileUploadHandler:
    def __init__(self, websocket: WebSocket):
        self.websocket = websocket

    async def receive_json_or_binary(self) -> Dict[str, Any]:
        """Receive either JSON metadata or binary file content."""
        message = await self.websocket.receive()

        if message["type"] == "websocket.receive":
            if "text" in message:
                return json.loads(message["text"])
            elif "bytes" in message:
                return {"type": "binary", "content": message["bytes"]}
        return {"type": "error", "content": "Invalid message format"}

    async def send_error(
        self, message: str, code: int = status.HTTP_400_BAD_REQUEST
    ) -> None:
        """Send an error message through the WebSocket."""
        await self.websocket.send_json(
            {
                "type": "error",
                "is_error": True,
                "code": code,
                "payload": {"error": message},
            }
        )


def datetime_to_isoformat(obj):
    if obj is None:
        return None
    if isinstance(obj, datetime.datetime):
        return obj.isoformat()
    return obj


# TODO: Figure out logic for this. Do we want to create a new test bench? Override the existing one?
# I think currently create a new one... but then we only want to show the latest tools with our current customer asks
# We'll have a lot of repeated tools if we start showing old test benches... which I'm fine with
# But discuss this logic
@router.websocket("/upload")
async def combined_upload_and_status(
    websocket: WebSocket,
    llm: LlmDependency,
    sql_session: WsSqlSessionDep,
) -> None:
    """Combined WebSocket endpoint for file upload and processing status.

    Handles:
    1. Initial connection
    2. Receiving device metadata
    3. Receiving file content
    4. Processing the document
    5. Streaming status updates
    """

    await websocket.accept()

    handler = WebSocketFileUploadHandler(websocket)
    processing_task = None

    try:
        # First message should be metadata
        metadata = await handler.receive_json_or_binary()
        if "type" not in metadata or metadata["type"] != "metadata":
            await handler.send_error("First message must be metadata")
            return

        # Validate title in metadata
        if "device" not in metadata or "title" not in metadata["device"]:
            await handler.send_error("Metadata must include device title")
            return

        # Second message should be file content
        file_message = await handler.receive_json_or_binary()
        if file_message["type"] != "binary":
            await handler.send_error("Second message must be file content")
            return

        # Initialize service
        service = LabBenchToolsService(sql_session=sql_session, llm=llm)

        random_uuid: str = str(uuid.uuid4())

        # Send acknowledgment
        await websocket.send_json(
            {"type": "upload_complete", "job_id": str(random_uuid)}
        )

        # PARSE THE TOOLS FROM THE FILE
        # Start processing in background without awaiting
        processing_task = asyncio.create_task(
            service.process_tools_document(
                file_message["content"],
                metadata.get("device", {}).get("filename", "uploaded_file"),
            )
        )

        # Stream status updates while processing runs
        try:
            async for status_update in service.get_processing_status(random_uuid):
                await websocket.send_json(
                    {
                        "type": "status_update",
                        "is_error": False,
                        "code": status.HTTP_200_OK,
                        "payload": status_update,
                    }
                )

                # If processing is complete, break the status update loop
                if status_update.get("status") == "completed":
                    break

            # Wait for processing to complete and check for errors
            result: ToolExtractionResult = await processing_task

            # Send acknowledgment
            await websocket.send_json(
                {
                    "type": "parse_complete",
                    "job_id": str(random_uuid),
                }
            )

            # TODO: What do we want to use for this? I don't trust ChatGPT based on initial testing,
            # but do we want to complicate w/ another AI/search service?

            # GET ADDITIONAL INFORMATION ABOUT EACH TOOL
            # Start processing in background without awaiting
            # tool_specifics_task = asyncio.create_task(
            #     service.get_tools_specifics(tools=result)
            # )

            # async for status_update in service.get_processing_status(
            #     db_bench.identifier
            # ):
            #     await websocket.send_json(
            #         {
            #             "type": "status_update",
            #             "is_error": False,
            #             "code": status.HTTP_200_OK,
            #             "payload": status_update,
            #         }
            #     )

            #     # If processing is complete, break the status update loop
            #     if status_update.get("status") == "completed":
            #         break

            # # Wait for processing to complete and check for errors
            # tool_specific_result: ToolExtractionResult = await tool_specifics_task

            # Only create a test bench if we have tools :(
            # TODO: Send error if no tools found

            tools = []
            if len(result.tools) > 0:
                test_bench = TestBench(
                    identifier=metadata["device"][
                        "title"
                    ]  # Use the title as identifier
                )

                # Create database entry
                db_bench = TestBench.model_validate(test_bench)

                # TODO: go through each of the new devices and add to our new test bench
                # TODO: Make sure this works as expected
                # TODO: Figure out how to combine tool_specific_results and results
                for tool in result.tools:
                    test_bench_device = TestBenchDevice(
                        name=tool.name,
                        description=tool.description,
                        manufacturer=tool.manufacturer,
                        category=tool.category,
                    )
                    db_bench.test_bench_devices.append(test_bench_device)

                # TODO: Save to DB and verify working correctly across the board (when doing test bench, e.g.)
                sql_session.add(db_bench)
                sql_session.flush()
                sql_session.refresh(db_bench)
                tools = [
                    {
                        **device.dict(),
                        **{
                            k: datetime_to_isoformat(v)
                            for k, v in device.dict().items()
                        },
                    }
                    for device in db_bench.test_bench_devices
                ]

            # Send acknowledgment
            await websocket.send_json(
                {
                    "type": "specifics_complete",
                    "job_id": str(random_uuid),
                    # TODO: Is there a more elegant way to do this?
                    "payload": {"tools": tools, "bench_id": db_bench.id},
                }
            )

        except Exception:
            # Cancel processing task if status streaming fails
            if processing_task:
                processing_task.cancel()
                try:
                    await processing_task
                except asyncio.CancelledError:
                    pass
            logger.exception("Error during processing status updates")
            await handler.send_error(
                "Error during processing", status.HTTP_500_INTERNAL_SERVER_ERROR
            )

    except Exception as e:
        logger.exception("Error during WebSocket communication")
        if processing_task and not processing_task.done():
            processing_task.cancel()
            try:
                await processing_task
            except asyncio.CancelledError:
                pass
        await handler.send_error(str(e), status.HTTP_500_INTERNAL_SERVER_ERROR)
    finally:
        # Ensure the WebSocket is closed
        try:
            await websocket.close()
        except Exception:
            logger.exception("Error closing WebSocket connection")
