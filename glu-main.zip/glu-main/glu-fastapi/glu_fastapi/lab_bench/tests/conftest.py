# conftest.py
from dotenv import load_dotenv
from pathlib import Path
import pytest

import os
import sys

from ..services import LabBenchToolsService
from langchain.chat_models.base import BaseChatModel
from langchain.embeddings.base import Embeddings
from glu_fastapi.external_services import get_llm_chat_service, get_embeddings_service
from tests.test_api import device_spec, testing_sqlsession, device_under_test  # noqa


def pytest_configure(config):
    print("Loading configuration")
    # Check if file exists, assumes you're at the glu level for your workspace
    if Path("glu-fastapi/.env").exists():
        print(".env file exists")
    else:
        print("No .env file, you'll want to fix that")
    """Load env variables before running tests"""
    load_dotenv("glu-fastapi/.env")

    """Create cache directory if it doesn't exist"""
    config.cache_dir = Path(".pytest_cache/pages")
    config.cache_dir.mkdir(parents=True, exist_ok=True)

    print(f"Current working directory: {os.getcwd()}")
    print(f"Env ENVIRONMENT: {os.getenv('ENVIRONMENT')}")
    print(f"Python path: {sys.path}")


# For testing, create an actual instance or mock
@pytest.fixture(scope="module")
def mock_llm() -> BaseChatModel:
    """Create a LLM for testing."""
    return get_llm_chat_service()


# For testing, create an actual instance or mock
@pytest.fixture(scope="module")
def mock_embeddings() -> Embeddings:
    """Create an embeddings for testing."""
    return get_embeddings_service()


@pytest.fixture(scope="function")
def test_bench_tools_service(mock_llm: BaseChatModel) -> LabBenchToolsService:
    return LabBenchToolsService(sql_session=None, llm=mock_llm)
