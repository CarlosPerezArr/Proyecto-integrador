from glu_fastapi.lab_bench.models import ToolExtractionResult
from glu_fastapi.lab_bench.services import LabBenchToolsService
from glu_fastapi.lab_bench.tests.common import (
    get_inventory_example_csv,
    get_inventory_example_csv_name,
    get_inventory_example_pdf,
    get_inventory_example_pdf_name,
    get_inventory_example_pdf_short,
    get_inventory_example_pdf_short_name,
    get_inventory_example_xlsx,
    get_inventory_example_xlsx_name,
    get_inventory_example_xlsx_short,
    get_inventory_example_xlsx_short_name,
)
import pytest


@pytest.mark.asyncio
async def test_inventory_example_pdf(
    test_bench_tools_service: LabBenchToolsService,
):
    # Test data
    file = await get_inventory_example_pdf()

    result: ToolExtractionResult = (
        await test_bench_tools_service.process_tools_document(
            content=file, filename=get_inventory_example_pdf_name()
        )
    )
    assert len(result.tools) == 87  # nosec B101


@pytest.mark.asyncio
async def test_inventory_example_pdf_short(
    test_bench_tools_service: LabBenchToolsService,
):
    # Test data
    file = await get_inventory_example_pdf_short()

    result: ToolExtractionResult = (
        await test_bench_tools_service.process_tools_document(
            content=file, filename=get_inventory_example_pdf_short_name()
        )
    )
    assert len(result.tools) == 10  # nosec B101


@pytest.mark.asyncio
async def test_inventory_example_xlsx_short(
    test_bench_tools_service: LabBenchToolsService,
):
    # Test data
    file = await get_inventory_example_xlsx_short()

    result: ToolExtractionResult = (
        await test_bench_tools_service.process_tools_document(
            content=file, filename=get_inventory_example_xlsx_short_name()
        )
    )

    assert len(result.tools) == 10  # nosec B101


@pytest.mark.asyncio
async def test_inventory_example_csv(
    test_bench_tools_service: LabBenchToolsService,
):
    # Test data
    file = await get_inventory_example_csv()

    result: ToolExtractionResult = (
        await test_bench_tools_service.process_tools_document(
            file, get_inventory_example_csv_name()
        )
    )
    assert len(result.tools) == 87  # nosec B101


@pytest.mark.asyncio
async def test_inventory_example_xlsx(
    test_bench_tools_service: LabBenchToolsService,
):
    # Test data
    file = await get_inventory_example_xlsx()

    result: ToolExtractionResult = (
        await test_bench_tools_service.process_tools_document(
            file, get_inventory_example_xlsx_name()
        )
    )

    assert len(result.tools) == 87  # nosec B101
