import os
import aiofiles


def get_inventory_example_pdf_name() -> str:
    return "Inventory example.pdf"


async def get_inventory_example_pdf() -> bytes:
    return await _get_file(get_inventory_example_pdf_name())


def get_inventory_example_pdf_short_name() -> str:
    return "Inventory example-short.pdf"


async def get_inventory_example_pdf_short() -> bytes:
    return await _get_file(get_inventory_example_pdf_short_name())


def get_inventory_example_xlsx_short_name() -> str:
    return "Inventory example-short.xlsx"


async def get_inventory_example_xlsx_short() -> bytes:
    return await _get_file(get_inventory_example_xlsx_short_name())


def get_inventory_example_xlsx_name() -> str:
    return "Inventory example.xlsx"


async def get_inventory_example_xlsx() -> bytes:
    return await _get_file(get_inventory_example_xlsx_name())


def get_inventory_example_csv_name() -> str:
    return "Inventory example.xlsx"


async def get_inventory_example_csv() -> bytes:
    return await _get_file(get_inventory_example_csv_name())


async def _get_file(file_name: str) -> bytes:
    current_dir = os.path.dirname(__file__)
    relative_path = os.path.join(current_dir, "files", file_name)

    async with aiofiles.open(relative_path, "rb") as pdf_file:
        data = await pdf_file.read()

    return data
