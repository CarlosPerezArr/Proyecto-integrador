from typing import Any, List, Annotated

from sqlalchemy import ChunkedIteratorResult
import structlog
from fastapi import (
    APIRouter,
    Body,
    status,
    Query,
    Path,
    Response,
    UploadFile,
    File,
    WebSocket,
)
from sqlmodel import select, delete
from glu_fastapi.external_services import LlmDependency
from glu_fastapi.database.session import SqlSessionDep, WsSqlSessionDep
from glu_fastapi.exceptions import NotFoundException
from glu_fastapi.websocket_utils import SocketResponse
from glu_fastapi.lab_bench.services import LabBenchToolsService
from glu_fastapi.lab_bench.models import (
    TestBenchDevice,
    TestBenchDeviceCreate,
    TestBenchDeviceRead,
    TestBenchRead,
    TestBench,
    TestBenchCreate,
    TestBenchResponse,
)
from glu_fastapi.lab_bench.services import TestBenchDeviceService

logger = structlog.get_logger()
router = APIRouter()


@router.get(
    "/devices",
    response_model=List[TestBenchDeviceRead],
)
async def list_test_bench_devices(sql_session: SqlSessionDep) -> Any:
    """List off the ``TestBenchDevices`` in the system."""

    service = TestBenchDeviceService(sql_session)
    return await service.fetch_all()


@router.delete(
    "/devices/{device_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_test_bench_device(
    sql_session: SqlSessionDep,
    device_id: Annotated[int, Path(title="The ID of the TestBenchDevice to delete.")],
) -> None:
    """Delete a single ``TestBenchDevice``."""

    delete_stmt = delete(TestBenchDevice).where(TestBenchDevice.id == device_id)
    result = sql_session.exec(delete_stmt)
    logger.info(
        f"Deleted {result.rowcount} TestBenchDevice record(s) for id={device_id}"
    )
    sql_session.flush()


@router.put(
    "/devices/{device_id}",
    response_model=TestBenchDeviceRead,
)
async def update_test_bench_device(
    sql_session: SqlSessionDep,
    device_id: Annotated[int, Path(title="The ID of the TestBenchDevice to update.")],
    updated_device: TestBenchDeviceRead,
) -> Any:
    """Total update for a single ``TestBenchDevice``."""

    select_stmt = select(TestBenchDevice).where(TestBenchDevice.id == device_id)
    update_me = sql_session.exec(select_stmt).one_or_none()
    if update_me is None:
        raise NotFoundException(f"No such TestBenchDevice(id={device_id}).")

    attrs = updated_device.model_dump(
        exclude={
            "id",
            "created_at",
            "updated_at",
        }
    )
    for name, value in attrs.items():
        setattr(update_me, name, value)
    sql_session.add(update_me)
    sql_session.flush()

    return update_me


@router.post(
    "/devices/{device_id}/test-benches",
    response_model=TestBenchDevice,
)
async def add_test_bench_to_device(
    sql_session: SqlSessionDep,
    device_id: Annotated[int, Path(title="The ID of the TestBenchDevice to update.")],
    test_bench_id: Annotated[int, Body(title="The ID of the TestBench to add.")],
) -> Any:
    """Add a TestBench to a TestBenchDevice."""

    select_stmt = select(TestBenchDevice).where(TestBenchDevice.id == device_id)
    device = sql_session.exec(select_stmt).one_or_none()
    if device is None:
        raise NotFoundException(f"No such TestBenchDevice(id={device_id}).")

    test_bench_stmt = select(TestBench).where(TestBench.id == test_bench_id)
    test_bench = sql_session.exec(test_bench_stmt).one_or_none()
    if test_bench is None:
        raise NotFoundException(f"No such TestBench(id={test_bench_id}).")

    device.test_benches.append(test_bench)
    sql_session.add(device)
    sql_session.flush()

    return device


@router.get(
    "/devices/{device_id}",
    response_model=TestBenchDeviceRead,
)
async def view_test_bench_device(
    sql_session: SqlSessionDep,
    device_id: Annotated[int, Path(title="The ID of the TestBenchDevice to get.")],
) -> Any:
    """Fetch the details of a single ``TestBenchDevice``."""

    select_stmt = select(TestBenchDevice).where(TestBenchDevice.id == device_id)
    db_device = sql_session.exec(select_stmt).one_or_none()
    if db_device is not None:
        return db_device

    raise NotFoundException(f"No such TestBenchDevice(id={device_id}.)")


@router.post(
    "/devices/",
    status_code=status.HTTP_201_CREATED,
    response_model=TestBenchDeviceRead,
)
async def create_test_bench_device(
    device: TestBenchDeviceCreate,
    sql_session: SqlSessionDep,
    response: Response,
) -> Any:
    """Create a device that can be used on the test bench."""

    db_device = TestBenchDevice.model_validate(device)
    sql_session.add(db_device)
    sql_session.flush()
    sql_session.refresh(db_device)

    response.headers["Location"] = router.url_path_for(
        "view_test_bench_device", device_id=db_device.id
    )

    return db_device


@router.get(
    "/test_benches",
    response_model=List[TestBenchRead],
)
async def list_test_benches(
    sql_session: SqlSessionDep,
    offset: int = 0,
    limit: int = Query(default=20, le=20),
) -> Any:
    """List off the ``TestBench``es in the system."""

    devices = sql_session.exec(select(TestBench).offset(offset).limit(limit)).all()

    # If we have no test bench, create a default, empty one for us, please!
    # TODO: Check the logic of adding multiple devices to the test bench
    if len(devices) == 0:
        bench = TestBench(identifier="Default Tool Collection")
        sql_session.add(bench)
        sql_session.flush()
        sql_session.refresh(bench)
        devices = [bench]
    return devices


@router.delete(
    "/test_benches/{bench_id}",
    status_code=status.HTTP_204_NO_CONTENT,
)
async def delete_test_bench(
    sql_session: SqlSessionDep,
    bench_id: Annotated[int, Path(title="The ID of the TestBench to delete.")],
) -> None:
    """Delete a single ``TestBenchDevice``."""

    delete_stmt: delete = delete(TestBench).where(TestBench.id == bench_id)
    result: ChunkedIteratorResult = sql_session.exec(delete_stmt)
    logger.info(
        f"Deleted {result.rowcount} TestBenchDevice record(s) for id={bench_id}"
    )
    sql_session.flush()


@router.get(
    "/test_benches/{bench_id}",
    response_model=TestBenchResponse,
)
async def view_test_bench(
    sql_session: SqlSessionDep,
    bench_id: Annotated[int, Path(title="The ID of the TestBench to get.")],
) -> Any:
    """Fetch the details of a single ``TestBench``."""

    service = TestBenchDeviceService(sql_session=sql_session)
    test_bench = await service.fetch_test_bench(test_bench_id=bench_id)

    if test_bench is not None:
        return test_bench

    raise NotFoundException("No latest test bench found.")


@router.get(
    "/test_benches/latest",
    response_model=TestBench,
)
async def view_latest_test_bench(
    sql_session: SqlSessionDep,
) -> Any:
    """Fetch the details of the latest ``TestBench``."""

    service = TestBenchDeviceService(sql_session=sql_session)
    test_bench = await service.fetch_latest_test_bench()

    if test_bench is not None:
        return test_bench

    raise NotFoundException("No latest test bench found.")


@router.put(
    "/test_benches/{bench_id}",
    response_model=TestBench,
)
async def update_test_bench(
    sql_session: SqlSessionDep,
    bench_id: Annotated[int, Path(title="The ID of the TestBench to update.")],
    updated_bench: TestBench,
) -> Any:
    """Total update for a single ``TestBenchDevice``."""

    select_stmt = select(TestBench).where(TestBench.id == bench_id)
    update_me = sql_session.exec(select_stmt).one_or_none()
    if update_me is None:
        raise NotFoundException(f"No such TestBenchDevice(id={bench_id}).")

    attrs = updated_bench.model_dump(
        exclude={"id", "created_at", "updated_at", "test_bench_devices", "test_plans"}
    )
    for name, value in attrs.items():
        setattr(update_me, name, value)
    sql_session.add(update_me)
    sql_session.flush()

    return update_me


@router.post(
    "/test_benches/",
    status_code=status.HTTP_201_CREATED,
    response_model=TestBenchRead,
)
async def create_test_bench(
    device: TestBenchCreate,
    sql_session: SqlSessionDep,
    response: Response,
) -> Any:
    """Create a device that can be used on the test bench."""

    db_bench = TestBenchDevice.model_validate(device)
    sql_session.add(db_bench)
    sql_session.flush()
    sql_session.refresh(db_bench)

    response.headers["Location"] = router.url_path_for(
        "view_test_bench", device_id=db_bench.id
    )

    return db_bench


@router.post(
    "/test_benches/upload",
    status_code=status.HTTP_202_ACCEPTED,
)
async def upload_tools_document(
    llm: LlmDependency, file: UploadFile = File(...), sql_session: SqlSessionDep = None
) -> Any:
    """Upload a document containing test bench tools information for processing."""

    logger.info("Starting document upload")
    # Read the file content
    content = await file.read()

    # Initialize the service
    service = LabBenchToolsService(sql_session=sql_session, llm=llm)

    # Start processing the document
    job_id = await service.process_tools_document(content, file.filename)

    return {"job_id": job_id, "message": "Document received and processing started"}


@router.websocket("/tools/process/{job_id}")
async def tools_processing_status(
    websocket: WebSocket,
    job_id: str,
    sql_session: WsSqlSessionDep,
) -> None:
    """WebSocket endpoint for receiving updates about tools document processing."""

    await websocket.accept()

    try:
        service = TestBenchDeviceService(sql_session)
        async for status_update in service.get_processing_status(job_id):
            await websocket.send_json(
                SocketResponse(
                    is_error=False, code=status.HTTP_200_OK, payload=status_update
                ).dict()
            )
    except Exception as e:
        logger.exception("Error during tools processing")
        await websocket.send_json(
            SocketResponse(
                is_error=True,
                code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                payload={"error": str(e)},
            ).dict()
        )
    finally:
        await websocket.close()
