"""SQLModel models for test benches and closely related concepts."""

from dataclasses import dataclass, field
import uuid
from typing import Optional, List, TYPE_CHECKING

from pydantic import BaseModel
from sqlalchemy import Column, Integer, ForeignKey, Index
from sqlalchemy.dialects.postgresql import JSONB
from sqlmodel import Field, Relationship

from glu_fastapi.cross_functional_links import TestPlanTestBenchLink
from glu_fastapi.per_tenant_models import CommonDevice, BaseTable
from glu_fastapi.websocket_utils import SocketResponse


if TYPE_CHECKING:
    from glu_fastapi.test_plan.models import TestPlan


class TestBenchTestBenchDeviceLink(BaseTable, table=True):
    """Link table for ``TestBench`` and ``TestBenchDevice``."""

    test_bench_id: int | None = Field(
        sa_column=Column(
            Integer,
            ForeignKey(
                "testbench.id",
                name="fk__testbenchtestbenchdevicelink__testbench",
                ondelete="CASCADE",
            ),
            primary_key=True,
            default=None,
        )
    )
    test_bench_device_id: int | None = Field(
        sa_column=Column(
            Integer,
            ForeignKey(
                "testbenchdevice.id",
                name="fk__testbenchtestbenchdevicelink__testbenchdevice",
                ondelete="CASCADE",
            ),
            primary_key=True,
            default=None,
        )
    )


class TestBenchDeviceBase(CommonDevice):
    """Base class for devices under test; for use with *Read/*Create subclasses."""

    # NOTE: This is just a first draft of the category work. It's entirely
    #       possible we will want to move this up to the ``CommonDevice``
    #       level and/or make the modeling more normalized, or even M2M instead
    #       of 1:N.
    category: Optional[str] = Field(default=None, index=True)


class TestBenchDevice(TestBenchDeviceBase, table=True):
    """A device to be tested."""

    id: Optional[int] = Field(default=None, primary_key=True)
    # This field is for tracking the ivi tags that might apply to a
    # given piece of lab equipment. There's nothing I know that constrains
    # how many of these there are (NOTE: That's nothing **I** know; it's
    # entirely possible I'm just ignorant of it), so I modeled it as a list
    # stored in a JSON field.
    ivi_tags: List[str] = Field(sa_column=Column(JSONB), default_factory=list)

    test_benches: List["TestBench"] = Relationship(
        back_populates="test_bench_devices", link_model=TestBenchTestBenchDeviceLink
    )

    __table_args__ = (
        Index(
            "ix_gin__testbenchdevice__ivi_tags",
            "ivi_tags",
            unique=False,
            postgresql_using="gin",
        ),
    )


class TestBenchDeviceForLlm(BaseModel):
    """Stripped down version of ``TestBenchDevice`` for use w/ the LLM."""

    name: Optional[str] = Field(default=None)
    description: Optional[str] = Field(default=None)
    manufacturer: Optional[str] = Field(default=None)
    category: Optional[str] = Field(default=None)
    ivi_tags: Optional[List[str]] = Field(default_factory=list)
    reason: Optional[str] = Field(
        default=None,
        description="The reason why this device is the right device for this test and how it will be used. This should include specifics around the testing requirements that this device meets--be exact about the values (e.g. voltage, limits, etc.).",
    )


class TestBenchDeviceWithFeedback(TestBenchDeviceForLlm):
    reason: str = Field(
        description="The specific reason why this device is relevant or suggested. Be specific about what features and values (voltage, tolerance, time, waveforms, etc.) of the DUT that this will measure."
    )
    purpose: str = Field(
        description="The intended purpose or use case for this device in the test including why it has the right capabilities (be specific about values, tolerances, etc.). Include information about which ports, inputs, interfaces, etc. this will be attached to."
    )


class TestBenchDeviceCreate(TestBenchDeviceBase):
    """A model so we can have a clean contract for POSTs to create a ``TestBenchDevice``."""

    pass


class TestBenchDeviceRead(TestBenchDeviceBase):
    """A model so we can have a clean contract for GETs to read ``TestBenchDevice`` records."""

    id: Optional[int]


class TestBenchBase(BaseTable):
    """Base class for devices under test; for use with *Read/*Create subclasses."""

    identifier: str = Field(index=True, default_factory=lambda: str(uuid.uuid4()))


class TestBenchResponse(BaseModel):
    id: Optional[int]
    identifier: str
    test_bench_devices: List[TestBenchDevice]

    class Config:
        from_attributes = True


class TestBench(TestBenchBase, table=True):
    """A test bench with a collection of equipment."""

    id: Optional[int] = Field(default=None, primary_key=True)

    test_bench_devices: List["TestBenchDevice"] = Relationship(
        back_populates="test_benches", link_model=TestBenchTestBenchDeviceLink
    )
    test_plans: List["TestPlan"] = Relationship(
        back_populates="test_benches", link_model=TestPlanTestBenchLink
    )


class TestBenchCreate(TestBenchBase):
    """A model so we can have a clean contract for POSTs to create a ``TestBench``."""

    pass


class TestBenchRead(TestBenchBase):
    """A model so we can have a clean contract for GETs to read ``TestBench`` records."""

    id: int


class TestBenchReadWithDeviceInfo(TestBenchRead):
    """Like ``TestBenchRead``, but with the related ``TestBenchDeviceReads`` included."""

    test_bench_devices: List[TestBenchDeviceRead] = []


class ToolUploadResponse(SocketResponse):
    """Response model for tool upload status updates via WebSocket.

    Provides real-time updates about the progress of tool extraction from uploaded documents.

    Attributes:
        file_name: Name of the file being processed
        processing_status: Current status of the extraction (e.g., "started", "processing", "complete")
        total_tools: Total number of tools identified in the document
        processed_tools: Number of tools that have been processed so far
    """

    file_name: Optional[str] = Field(
        default=None, description="Name of the uploaded file being processed"
    )
    processing_status: Optional[str] = Field(
        default=None,
        description="Current status of the tool extraction process. Common values include: started, processing, complete, failed",
    )
    total_tools: Optional[int] = Field(
        default=None,
        description="Total number of tools identified in the document",
        ge=0,
    )
    processed_tools: Optional[int] = Field(
        default=None,
        description="Number of tools that have been processed so far",
        ge=0,
    )


class ExtractedTool(BaseModel):
    """Model representing a tool extracted from an uploaded document.

    Contains essential information about laboratory equipment or tools
    extracted from documentation.

    Attributes:
        name: Unique identifier/name of the tool
        part_number: System or manufacturer part number
        manufacturer: Company that manufactures the tool
        category: Classification or type of the tool
        description: Detailed description of the tool's functionality
        total_quantity: Total number of units in inventory
        available_quantity: Number of units currently available
        ivi_tags: List of IVI (Interchangeable Virtual Instrument) classification tags
    """

    name: str = Field(description="Name or identifier of the tool", min_length=1)
    part_number: str = Field(
        description="System or manufacturer part number of the tool"
    )
    manufacturer: Optional[str] = Field(
        default=None, description="Name of the tool's manufacturer"
    )
    category: Optional[str] = Field(
        default=None,
        description="Category or classification of the tool. Common categories include: oscilloscope, multimeter, power supply, rack mount, timer module, chassis, cable.",
    )
    description: Optional[str] = Field(
        default=None,
        description="Detailed description of the tool's functionality and features. If this is included in the original document, include it verbatim.",
    )
    total_quantity: int = Field(description="Total number of units in inventory", ge=0)
    available_quantity: int = Field(
        description="Number of units currently available for use", ge=0
    )
    ivi_tags: List[str] = Field(
        default_factory=list,
        description="IVI classification tags for the tool. Common tags include: IviDmm, IviScope, IviPwrMeter",
    )


class ExtractedToolWithSpecifics(ExtractedTool):
    tool_specifics: Optional[str] = Field(
        default=None,
        description="This tool's capabilities, tolerances, limits, maximums, minimums, inputs, outputs, etc.? Give me a detailed key:value JSON object of key numbers, details, specifics.",
    )


class ExcludedItem(BaseModel):
    """Model representing an item that was excluded during tool extraction.

    Tracks items that were found but not processed as valid tools, along with
    the reason for exclusion.

    Attributes:
        name: Name or identifier of the excluded item
        reason: Explanation for why the item was excluded
    """

    name: str = Field(
        description="Name or identifier of the excluded item", min_length=1
    )
    reason: str = Field(
        description="Reason why the item was excluded from processing. Common reasons include: Invalid format, Missing required fields, Duplicate entry"
    )


class ToolExtractionResult(BaseModel):
    """Model representing the complete result of tool extraction from a document.

    Contains the overall results of the extraction process, including both
    successfully extracted tools and excluded items.

    Attributes:
        excluded_items: List of items that were excluded during extraction
        tools: List of successfully extracted tools
        source_file: Name of the file that was processed
        extraction_complete: Whether the extraction process has finished
        error_message: Any error message if the extraction failed
    """

    excluded_items: List[ExcludedItem] = Field(
        description="Any line that's not included as part of the extraction."
    )
    tools: List[ExtractedTool] = Field(
        description="List of successfully extracted tools"
    )
    source_file: str = Field(
        description="Name of the source file that was processed", min_length=1
    )
    extraction_complete: bool = Field(
        default=False,
        description="Indicates whether the extraction process has completed",
    )
    error_message: Optional[str] = Field(
        default=None, description="Error message if the extraction process failed"
    )


@dataclass
class PartialResult:
    """Store partial results from processing each message chunk"""

    tools: List[ExtractedTool] = field(default_factory=list)
    excluded_items: List[ExcludedItem] = field(default_factory=list)
    source_file: str = ""
    error_messages: List[str] = field(default_factory=list)
    processed_chunks: int = 0
    total_chunks: int = 0
