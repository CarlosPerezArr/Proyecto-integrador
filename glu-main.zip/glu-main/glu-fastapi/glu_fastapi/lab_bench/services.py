"""Collection of service objects for biz logic relating to lab bench tools."""

import asyncio
from typing import List, Optional, Sequence

import backoff
from glu_fastapi.ai.doc_util import LangChainDocumentProcessor
import openai
from sqlalchemy import desc
import structlog
import math
from sqlmodel import Session, select
from langchain_core.language_models import BaseChatModel
from langchain.schema import SystemMessage
from langchain_core.messages import HumanMessage

from glu_fastapi.copilot.models import ToolList
from glu_fastapi.exceptions import NotFoundException
from glu_fastapi.lab_bench.models import (
    TestBenchDevice,
    TestBenchDeviceForLlm,
    TestBench,
    TestBenchDeviceRead,
    ToolExtractionResult,
)
from .models import ExtractedTool, ExtractedToolWithSpecifics, PartialResult
from glu_fastapi import prompts
import traceback


logger = structlog.get_logger()


class TestBenchService:
    """Business logic related to ``TestBench``."""

    def __init__(
        self,
        sql_session: Session,
    ):
        self.sql_session: Session = sql_session

    async def find(self, test_bench_id: int) -> TestBench:
        """Find a ``TestBench`` by its PK (``id``)."""

        test_bench = self.sql_session.exec(
            select(TestBench).where(TestBench.id == test_bench_id)
        ).one_or_none()
        if test_bench is None:
            raise NotFoundException(f"No such TestBench(id={test_bench_id}).")

        return test_bench


class TestBenchDeviceService:
    """Business logic related to ``TestBenchDevice``."""

    def __init__(
        self,
        sql_session: Session,
    ):
        self.sql_session: Session = sql_session

    async def get_all_available_tools_as_json_string(self) -> str:
        """Return ALL the tools that the tenant currently has"""
        tools = await self.fetch_all()
        logger.debug(
            "Got list of available tools for embedding in the prompt.",
            available_tools=tools,
        )
        tool_list = ToolList(
            available_tools=[TestBenchDeviceRead.model_validate(tool) for tool in tools]
        )
        return tool_list.model_dump_json()

    async def get_latest_bench_available_tools_as_json_string(self) -> str:
        """Return the tools from the latest test bench"""
        tools = await self.fetch_latest_test_bench_tools()
        logger.debug(
            "Got list of available tools for embedding in the prompt.",
            available_tools=tools,
        )
        tool_list = ToolList(
            available_tools=[TestBenchDeviceRead.model_validate(tool) for tool in tools]
        )
        return tool_list.model_dump_json()

    async def fetch_all(self) -> Sequence[TestBenchDevice]:
        """Get all the ``TestBenchDevice`` records."""

        return self.sql_session.exec(select(TestBenchDevice)).all()

    async def fetch_latest_test_bench(self) -> TestBench:
        """Find the last created Test Bench."""
        select_stmt = (
            select(TestBench)
            .where(TestBench.test_bench_devices)
            .order_by(desc(TestBench.created_at))
            .limit(1)
        )
        return self.sql_session.exec(select_stmt).one_or_none()

    async def fetch_test_bench(self, test_bench_id: int) -> TestBench:
        """Find the last created Test Bench."""
        select_stmt = select(TestBench).where(TestBench.id == test_bench_id).limit(1)
        return self.sql_session.exec(select_stmt).one_or_none()

    async def fetch_latest_test_bench_tools(self) -> Sequence[TestBenchDevice]:
        """Helper function to return the devices from the latest test bench"""
        bench: TestBench = await self.fetch_latest_test_bench()
        return bench.test_bench_devices

    async def find_matching_test_bench_device(
        self, llm_description: TestBenchDeviceForLlm
    ) -> TestBenchDevice:
        """Find the DB record that corresponds to ``llm_description``."""
        select_stmt = (
            select(TestBenchDevice)
            .where(TestBenchDevice.manufacturer == llm_description.manufacturer)
            .where(TestBenchDevice.name == llm_description.name)
        )
        return self.sql_session.exec(select_stmt).one_or_none()


class LabBenchToolsService:
    """Service for processing uploaded tool documents and extracting tool information."""

    page_current = 0
    page_total = 100

    def __init__(
        self, sql_session: Session, llm: BaseChatModel, max_concurrent_tasks: int = 5
    ):
        self.sql_session: Session = sql_session
        self.llm: BaseChatModel = llm
        self.max_concurrent_tasks = max_concurrent_tasks
        self.semaphore = asyncio.Semaphore(max_concurrent_tasks)
        self._tools_extraction_system_prompt: Optional[str] = None
        self._tools_specifics_system_prompt: Optional[str] = None

    @property
    def tools_extraction_system_prompt(self) -> SystemMessage:
        """Lazy load and cache the system prompt template."""
        if self._tools_extraction_system_prompt is None:
            try:
                self._tools_extraction_system_prompt = (
                    prompts.test_bench_tool_extractor()
                )
            except Exception as e:
                logger.error(f"Failed to load system prompt template: {e}")
                # Fallback to basic prompt if template fails
                self._tools_extraction_system_prompt = SystemMessage(
                    content="You are a test equipment expert. Extract test bench tool information "
                    "from the provided document. For each tool found, identify the name, "
                    "manufacturer, category, and description if available. Format the output "
                    "as a JSON array of tools."
                )
        return self._tools_extraction_system_prompt

    @property
    def tools_specifics_system_prompt(self) -> str:
        """Lazy load and cache the system prompt template."""
        if self._tools_specifics_system_prompt is None:
            try:
                self._tools_specifics_system_prompt = prompts.tool_specifics()
            except Exception as e:
                logger.error(f"Failed to load system prompt template: {e}")
                # Fallback to basic prompt if template fails
                self._tools_specifics_system_prompt = "What do you know about this tool? What are its capabilities, tolerances, limits, maximums, minimums, inputs, outputs, etc.? Give me a detailed key:value JSON object of key numbers, details, specifics. GIVE ME ONLY REAL, VERIFIABLE FACTS, DO NO MAKE ANYTHING UP! Return only JSON, this will be parsed by a API so anything else will break."
        return self._tools_specifics_system_prompt

    @backoff.on_exception(
        backoff.expo, openai.RateLimitError, max_tries=3, max_time=180
    )
    async def process_message_chunk(
        self,
        chunk: HumanMessage,
        structured_llm,
        chunk_index: int,
        total_chunks: int,
        filename: str,
    ) -> ToolExtractionResult:
        """Process a single message chunk with retry logic"""
        async with self.semaphore:
            try:
                messages = [
                    self.tools_extraction_system_prompt,
                    chunk,
                ]

                response: ToolExtractionResult = await structured_llm.ainvoke(
                    input=messages
                )

                # Ensure source file is set
                response.source_file = filename

                logger.info(
                    "Processed chunk",
                    chunk_index=chunk_index,
                    total_chunks=total_chunks,
                    response=response,
                )
                self.page_current += 1

                return response

            except Exception:
                error_msg = (
                    f"Error processing chunk {chunk_index}: {traceback.format_exc()}"
                )
                logger.error(error_msg)

                self.page_current += 1

                # Return a failed result
                return ToolExtractionResult(
                    tools=[],
                    excluded_items=[],
                    source_file=filename,
                    extraction_complete=False,
                    error_message=error_msg,
                )

    def combine_results(
        self, results: List[ToolExtractionResult], filename: str, total_chunks: int
    ) -> ToolExtractionResult:
        """
        Combine multiple ToolExtractionResults into a single result

        Args:
            results: List of ToolExtractionResult objects to combine
            filename: Original source filename
            total_chunks: Total number of chunks processed

        Returns:
            Combined ToolExtractionResult
        """
        combined = PartialResult(source_file=filename, total_chunks=total_chunks)

        for result in results:
            # Track processed chunks
            combined.processed_chunks += 1

            # Combine tools lists, avoiding duplicates by tool name
            existing_tool_names = {tool.name for tool in combined.tools}
            for tool in result.tools:
                if tool.name not in existing_tool_names:
                    combined.tools.append(tool)
                    existing_tool_names.add(tool.name)

            # Combine excluded items, avoiding duplicates by item name
            existing_excluded_names = {item.name for item in combined.excluded_items}
            for item in result.excluded_items:
                if item.name not in existing_excluded_names:
                    combined.excluded_items.append(item)
                    existing_excluded_names.add(item.name)

            # Collect error messages
            if result.error_message:
                combined.error_messages.append(result.error_message)

        # Create final result
        extraction_complete = (
            combined.processed_chunks == combined.total_chunks
            and not combined.error_messages
        )

        error_message = None
        if combined.error_messages:
            error_message = "; ".join(combined.error_messages)

        return ToolExtractionResult(
            tools=combined.tools,
            excluded_items=combined.excluded_items,
            source_file=combined.source_file,
            extraction_complete=extraction_complete,
            error_message=error_message,
        )

    @backoff.on_exception(
        backoff.expo, openai.RateLimitError, max_tries=3, max_time=300
    )
    async def process_tools_document(
        self, content: bytes, filename: str
    ) -> ToolExtractionResult:
        """Process an uploaded document to extract tool information.

        Args:
            content: The raw bytes of the uploaded document
            filename: Name of the uploaded file

        Returns:
            ToolExtractionResult: Combined results from processing all chunks
        """
        try:

            # Use the document processor to handle different file types
            processor = LangChainDocumentProcessor()
            messages = processor.process_to_messages(content)

            # Create structured LLM once to reuse
            structured_llm = self.llm.with_structured_output(ToolExtractionResult)

            self.page_total = len(messages)

            # Create tasks for each message chunk
            tasks = [
                self.process_message_chunk(
                    chunk, structured_llm, idx, len(messages), filename
                )
                for idx, chunk in enumerate(messages)
            ]

            # Process all chunks in parallel
            results = await asyncio.gather(*tasks)

            # Combine results from all chunks
            combined_result = self.combine_results(results, filename, len(messages))

            logger.info(
                "Processed tools document",
                filename=filename,
                num_chunks=len(messages),
                response=combined_result,
            )

            return combined_result

        except Exception as e:
            error_msg = f"Error processing document: {str(e)}"
            logger.error(error_msg)

            return ToolExtractionResult(
                tools=[],
                excluded_items=[],
                source_file=filename,
                extraction_complete=False,
                error_message=error_msg,
            )

    def convert_to_tools_with_specifics(
        tools: List[ExtractedTool],
    ) -> List[ExtractedToolWithSpecifics]:
        return [
            ExtractedToolWithSpecifics(
                name=tool.name,
                part_number=tool.part_number,
                manufacturer=tool.manufacturer,
                category=tool.category,
                description=tool.description,
                total_quantity=tool.total_quantity,
                available_quantity=tool.available_quantity,
                ivi_tags=tool.ivi_tags,
                tool_specifics=None,  # Initialize with None since it's a new field
            )
            for tool in tools
        ]

    async def get_tools_specifics(
        self, tools: ToolExtractionResult
    ) -> List[ExtractedToolWithSpecifics]:
        page_size = 3
        tools_list = tools.tools
        total_pages = math.ceil(len(tools_list) / page_size)

        self.page_total = total_pages
        self.page_current = 0

        tasks = []
        for i in range(0, len(tools_list), page_size):
            current_page = tools_list[i : i + page_size]
            tasks.append(
                self._get_tools_specifics_chunk(
                    tools=current_page, chunk_index=i, total_chunks=total_pages
                )
            )

        # Process all chunks in parallel
        results: List[List[ExtractedToolWithSpecifics]] = await asyncio.gather(*tasks)
        result: List[ExtractedToolWithSpecifics] = [
            item for sublist in results for item in sublist
        ]
        return result

    @backoff.on_exception(
        backoff.expo, openai.RateLimitError, max_tries=3, max_time=180
    )
    async def _get_tools_specifics_chunk(
        self, tools: List[ExtractedTool], chunk_index: int, total_chunks: int
    ) -> List[ExtractedToolWithSpecifics]:
        """Process a single message chunk with retry logic"""
        async with self.semaphore:
            try:
                structured_llm = self.llm.with_structured_output(
                    ExtractedToolWithSpecifics
                )

                messages = [
                    self.tools_extraction_system_prompt,
                ]

                for tool in tools:
                    messages.append(HumanMessage(content=tool.json()))

                response: ToolExtractionResult = await structured_llm.ainvoke(
                    input=messages
                )

                logger.info(
                    "Processed chunk",
                    chunk_index=chunk_index,
                    total_chunks=total_chunks,
                    response=response,
                )
                self.page_current += 1

                return response

            except Exception as e:

                self.page_current += 1

                error_msg = f"Error processing chunk {chunk_index}: {str(e)}"
                logger.error(error_msg)

                return self.convert_to_tools_with_specifics(tools=tools)

    async def get_processing_status(self, job_id: str):
        """Get status updates for a document processing job.

        Args:
            job_id: The ID of the processing job to check

        Yields:
            dict: Status information about the processing job
        """
        while self.page_current < self.page_total:
            status = {
                "status": "processing",
                "job_id": job_id,
                "progress": self.page_current * 100 // self.page_total,
                "page_count": self.page_total,
                "page_number": self.page_current,
            }
            yield status
            await asyncio.sleep(0.5)  # Add small delay between updates

        # Yield final completed status
        yield {"status": "completed", "job_id": job_id, "progress": 100}
