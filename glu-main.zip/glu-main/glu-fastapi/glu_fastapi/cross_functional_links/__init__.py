"""A collection of models that must be mutually shared across functional areas.

Mostly, this will be link models that connect models from different packages, e.g., ``TestPlanTestBenchLink`` is
required by models in both ``lab_bench`` and ``test_plan``, which means it can't be defined in either one without
causing circular imports. Hence, this package, which allows each of those packages to import what they need *WITHOUT*
circular import problems.
"""

from sqlalchemy import Column, Integer, ForeignKey
from sqlmodel import Field

from glu_fastapi.per_tenant_models import BaseTable


class TestPlanTestBenchLink(BaseTable, table=True):
    """Link table for ``TestPlan`` and ``TestBench``."""

    test_plan_id: int | None = Field(
        sa_column=Column(
            Integer,
            ForeignKey(
                "testplan.id",
                name="fk__testplantestbenchlink__testplan",
                ondelete="CASCADE",
            ),
            primary_key=True,
            default=None,
        )
    )
    test_bench_id: int | None = Field(
        sa_column=Column(
            Integer,
            ForeignKey(
                "testbench.id",
                name="fk__testplantestbenchlink__testbench",
                ondelete="CASCADE",
            ),
            primary_key=True,
            default=None,
        )
    )
