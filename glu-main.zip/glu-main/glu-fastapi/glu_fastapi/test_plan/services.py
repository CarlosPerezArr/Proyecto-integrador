"""Service objects that are related to the actual process of testing devices."""

from sqlmodel import Session, select

from glu_fastapi.exceptions import NotFoundException
from glu_fastapi.test_plan.models import TestPlan


class TestPlanService:
    """Business logic related to ``FeatureSpec``."""

    def __init__(self, sql_session: Session):
        self.sql_session: Session = sql_session

    async def find(self, test_plan_id: int) -> TestPlan:
        """PK-based lookup; will raise ``NotFoundException`` if no match."""
        test_plan = self.sql_session.exec(
            select(TestPlan).where(TestPlan.id == test_plan_id)
        ).one_or_none()
        if test_plan is None:
            raise NotFoundException(f"No such TestPlan(id={test_plan_id}).")

        return test_plan
