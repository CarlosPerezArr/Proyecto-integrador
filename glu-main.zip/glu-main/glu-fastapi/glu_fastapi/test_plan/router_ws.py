import logging
from typing import Any, Dict, Annotated, List, Optional

from glu_fastapi.bookworm.models_implementation import Feature
from pydantic import Field
import structlog

from fastapi import APIRouter, WebSocketException, status
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import (
    HumanMessage,
    BaseMessage,
    SystemMessage,
)

import json
from langgraph.checkpoint.base import BaseCheckpointSaver
from sqlmodel import Session
from starlette.websockets import WebSocket, WebSocketDisconnect

from glu_fastapi import prompts
from glu_fastapi.external_services import LlmDependency
from glu_fastapi.ai.models import AiMemory
from glu_fastapi.config import SettingsDep
from glu_fastapi.copilot.models import (
    ToolPickerResponse,
    StepsGeneratorResponse,
)
from glu_fastapi.database.checkpointers import WsAsyncCheckpointerDep
from glu_fastapi.database.session import WsSqlSessionDep
from glu_fastapi.exceptions import NotFoundException
from glu_fastapi.external_services import BotoSessionDep
from glu_fastapi.lab_bench.models import (
    TestBench,
    TestBenchDeviceWithFeedback,
    TestBenchReadWithDeviceInfo,
)
from glu_fastapi.lab_bench.services import TestBenchDeviceService
from glu_fastapi.langgraph_utils import (
    build_copilot_graph_with_structured_output,
    config_for_picking_tools,
    config_for_step_generation,
    run_graph,
)
from glu_fastapi.test_plan.models import TestPlan
from glu_fastapi.test_plan.services import TestPlanService
from glu_fastapi.under_test.models import (
    DeviceUnderTest,
    FunctionSpec,
)
from glu_fastapi.under_test.services import (
    FunctionSpecService,
    DeviceSpecPageService,
    DeviceSpecTocEntryService,
)
from glu_fastapi.websocket_utils import (
    ServerEventType,
    ClientEventType,
    ClientEventWithUserFeedback,
    ServerEvent,
    ClientEvent,
    SocketResponse,
)
from ..copilot.services import (
    StepsService,
    ToolsService,
    get_overview_and_title_from_function_spec,
)

logger = structlog.get_logger()
router = APIRouter()

# TODO: Remove
logging.getLogger("pydantic").setLevel(logging.DEBUG)


class ToolsSuggestedEvent(ServerEvent):
    event_type: ServerEventType = Field(
        default=ServerEventType.tools_suggested,
        description="Type identifier for the tools suggestion event",
    )
    description: str

    missing_tools: List[TestBenchDeviceWithFeedback] = Field(
        description='List of devices that are required but not currently available in the test bench. For each item, give a specific make and model that would meet this purpose.  Please suggest "A tool like [Tool Name]" and explain why that is the right tool based on its characteristics.',
        default_factory=list,
    )
    present_tools: List[TestBenchDeviceWithFeedback] = Field(
        description="List of devices that are currently available in the test bench. Wherever possible, use a tool that we already have!!!",
        default_factory=list,
    )


class ToolsAcceptedEvent(ClientEvent):
    event_type: ClientEventType = ClientEventType.tools_accepted


class ToolsRetryEvent(ClientEventWithUserFeedback):
    event_type: ClientEventType = ClientEventType.tools_retry


class TestBenchPersistedEvent(ServerEvent):
    event_type: ServerEventType = ServerEventType.test_bench_persisted
    test_bench: TestBenchReadWithDeviceInfo


class StepsAcceptedEvent(ClientEvent):
    event_type: ClientEventType = ClientEventType.steps_accepted


class StepsRetryEvent(ClientEventWithUserFeedback):
    event_type: ClientEventType = ClientEventType.steps_retry


class StepsGeneratedEvent(ServerEvent):
    event_type: ServerEventType = ServerEventType.steps_generated


class StepsPersistedEvent(ServerEvent):
    event_type: ServerEventType = ServerEventType.steps_persisted
    test_plan: TestPlan


@router.websocket("/test_plans/{test_plan_id}/pick_em")
async def pick_em(
    llm: LlmDependency,
    sql_session: WsSqlSessionDep,
    checkpointer: WsAsyncCheckpointerDep,
    websocket: WebSocket,
    test_plan_id: Annotated[
        int, "The ID of the TestPlan for which we need a TestBench"
    ],
    _test_bench_id: Annotated[
        int | None, "The ID of the TestBench we previously picked for this TestPlan"
    ] = None,
    _user_feedback: Annotated[
        str | None, "What the user wants to say to the LLM."
    ] = None,
    _user_annotations: Annotated[
        str, "Annotated feedback from the user on the existing."
    ] = None,
) -> None:
    await websocket.accept()
    await websocket.send_json({"message": "Socket Connected"})

    # FIXME: Figure out what to do if we already have a TestBench and/or user feedback.

    try:
        tools_service = ToolsService()
        system_message = await tools_service.build_system_message(llm, sql_session)
        logger.info(
            "Here's the formatted system message we will send.",
            formatted_sys_msg=system_message.content,
        )

        tp_service: TestPlanService = TestPlanService(sql_session)
        tp = await tp_service.find(test_plan_id=test_plan_id)
        human_message = await tools_service.build_human_message(sql_session, tp)

        await _handle_tool_picker_graph(
            checkpointer,
            human_message,
            system_message,
            tp,
            llm,
            sql_session,
            websocket,
        )
    except WebSocketDisconnect:
        logger.info("Client closed connection. I think.")
    except KeyError as ke:
        logger.exception("Missing parameter.")
        raise WebSocketException(1008, f"Missing parameter: {str(ke)}")
    except NotFoundException as nfe:
        logger.exception("Couldn't find referenced object.")
        raise WebSocketException(1008, f"Bad parameter. Details: {str(nfe)}")
    except Exception as e:  # noqa
        logger.exception("Unknown Exception")
        raise WebSocketException(1008, getattr(e, "message", repr(e)))
    finally:
        try:
            await websocket.close()
        except Exception:  # noqa
            logger.debug("Websocket was already closed, or something", exc_info=True)


@router.websocket("/test_plans/{test_plan_id}")
async def edit_steps_ws(
    settings: SettingsDep,
    llm: LlmDependency,
    sql_session: WsSqlSessionDep,
    checkpointer: WsAsyncCheckpointerDep,
    boto_session: BotoSessionDep,
    websocket: WebSocket,
    test_plan_id: Annotated[int, "The ID of the TestPlan to edit"],
    # FIXME: Delete these params once the front-end change is in place.
    user_feedback: Annotated[
        Optional[str], "What the user wants to say to the LLM."
    ] = None,
    user_annotations: Annotated[
        Optional[str], "Annotated feedback from the user on the existing."
    ] = None,
) -> None:
    await websocket.accept()
    await websocket.send_json({"message": "Socket Connected"})

    toc_entry_service = DeviceSpecTocEntryService(sql_session)
    try:
        steps_service = StepsService()
        system_message = await steps_service.build_system_message(llm, sql_session)

        tp_service: TestPlanService = TestPlanService(sql_session)
        og_tp = await tp_service.find(test_plan_id=test_plan_id)
        fut: FunctionSpec = og_tp.function_spec
        fut_overview, fut_title = await get_overview_and_title_from_function_spec(fut)
        dut: DeviceUnderTest = fut.device_spec.device_under_test

        # FIXME: Extract helper method for this next chunk. It should return the event object.
        user_input_of_some_kind: Dict[Any, Any] = await websocket.receive_json()
        logger.debug("User provided feedback", user_said=user_input_of_some_kind)
        match user_input_of_some_kind["event_type"]:
            case ClientEventType.steps_retry:
                retry_event = StepsRetryEvent.model_validate(user_input_of_some_kind)
                logger.debug("Parsed steps_retry event", retry_details=retry_event)
            case _:
                await websocket.send_text(
                    SocketResponse(
                        is_error=True,
                        code=status.HTTP_400_BAD_REQUEST,
                        payload={"errors": ["Unknown event type"]},
                    ).model_dump_json()
                )
                return
        general_feedback = (
            retry_event.user_feedback if retry_event.has_general_feedback else None
        )
        annotation_feedback = (
            retry_event.user_annotations
            if retry_event.has_specific_annotations
            else None
        )

        # TODO needs to be updated with the update/annotation logic from new_plan_for_function_ws()
        fut_title = fut.name
        fut_overview = ""
        try:
            fut_def = Feature.from_json_str(json_str=fut.original_text)
            fut_title = fut_def.title
            fut_overview = fut_def.content
        except json.JSONDecodeError:
            logger.warn(
                "Couldn't load JSON from the original text, maybe it is an older spec?"
            )

        page_service: DeviceSpecPageService = DeviceSpecPageService(
            settings, sql_session, boto_session, toc_entry_service
        )
        pages = await page_service.fetch_fully_loaded_pages_for_function_spec(fut)

        human_message = prompts.steps_editor_human_message(
            dut_name=dut.name,
            fut_name=fut_title,
            fut_overview=fut_overview,
            page_data=pages,
            current_version_of_the_steps=og_tp.full_text,
            user_feedback=general_feedback,
            annotated_content=annotation_feedback,
        )
        logger.info(
            "Here's the human message we will send.",
            formatted_human_msg=human_message.content,
        )

        await _handle_steps_generator_common_core(
            checkpointer,
            human_message,
            system_message,
            fut,
            llm,
            sql_session,
            websocket,
        )
    except WebSocketDisconnect:
        logger.info("Client closed connection. I think.")
    except KeyError as ke:
        logger.exception("Missing parameter.")
        raise WebSocketException(1008, f"Missing parameter: {str(ke)}")
    except NotFoundException as nfe:
        logger.exception("Couldn't find referenced object.")
        raise WebSocketException(1008, f"Bad parameter. Details: {str(nfe)}")
    except Exception as e:  # noqa
        logger.exception("Unknown Exception")
        raise WebSocketException(1008, getattr(e, "message", repr(e)))
    finally:
        try:
            await websocket.close()
        except Exception:  # noqa
            logger.debug("Websocket was already closed, or something", exc_info=True)


async def _handle_tool_picker_graph(
    checkpointer: BaseCheckpointSaver,
    formatted_human_msg: BaseMessage,
    formatted_sys_msg: BaseMessage,
    tp: TestPlan,
    llm: BaseChatModel,
    sql_session: Session,
    websocket: WebSocket,
):
    tools_service = ToolsService()
    graph = await build_copilot_graph_with_structured_output(
        llm,
        checkpointer,
        [ToolPickerResponse],
    )
    my_config = await config_for_picking_tools(tp)
    graph_input = {
        "messages": [formatted_sys_msg, formatted_human_msg],
    }

    # Store the most recent valid response
    current_tool_picker_response: ToolPickerResponse = (
        await _tool_picker_loop_generative_chunk(
            graph, graph_input, my_config, tools_service, websocket
        )
    )

    accepted_event = None
    while accepted_event is None:
        # NOTE: This is **NOT** supposed to be a string, and yet here we are: the
        #       app explodes because it is a string. Since none of this makes any
        #       sense, we're just gonna go with "detect it and try to work around it".
        user_input_of_some_kind: Dict[Any, Any] | str = await websocket.receive_json()
        if isinstance(user_input_of_some_kind, str):
            user_input_of_some_kind = json.loads(user_input_of_some_kind)
        logger.debug(
            "User provided feedback",
            user_said=user_input_of_some_kind,
            type_of_what_they_said=type(user_input_of_some_kind),
        )
        match user_input_of_some_kind["event_type"]:
            case ClientEventType.tools_retry:
                retry_event = ToolsRetryEvent.model_validate(user_input_of_some_kind)
                accepted_event = None
                logger.debug("Parsed tools_retry event", retry_details=retry_event)
            case ClientEventType.tools_accepted:
                retry_event = None
                accepted_event = ToolsAcceptedEvent.model_validate(
                    user_input_of_some_kind
                )
                logger.debug(
                    "Parsed tools_accepted event", accepted_details=accepted_event
                )
            case _:
                await websocket.send_text(
                    SocketResponse(
                        is_error=True,
                        code=status.HTTP_400_BAD_REQUEST,
                        payload={"errors": ["Unknown event type"]},
                    ).model_dump_json()
                )
                break

        if accepted_event is not None:
            logger.debug("Great success!")
            break

        if retry_event:
            await graph.aupdate_state(
                my_config,
                {
                    "messages": [HumanMessage(retry_event.user_feedback)],
                },
                as_node="__start__",
            )
            # Update the response with the new one from retry
            current_tool_picker_response = await _tool_picker_loop_generative_chunk(
                graph,
                None,  # graph_input is None for retries
                my_config,
                tools_service,
                websocket,
            )

    tbd_service = TestBenchDeviceService(sql_session)
    db_test_bench = TestBench()
    for device in current_tool_picker_response.present_tools:
        tbd = await tbd_service.find_matching_test_bench_device(device)
        db_test_bench.test_bench_devices.append(tbd)
    db_test_bench.test_plans.append(tp)
    sql_session.add(db_test_bench)

    if current_tool_picker_response.new_user_notes is not None:
        ai_memory = AiMemory(notes=current_tool_picker_response.new_user_notes)
        sql_session.add(ai_memory)

    sql_session.flush()
    sql_session.refresh(db_test_bench)
    dto = TestBenchReadWithDeviceInfo.model_validate(db_test_bench)
    await websocket.send_text(
        SocketResponse(
            is_error=False,
            code=status.HTTP_200_OK,
            payload=TestBenchPersistedEvent(test_bench=dto).model_dump(),
        ).model_dump_json()
    )


async def _tool_picker_loop_generative_chunk(
    graph, graph_input, my_config, tools_service: ToolsService, websocket
) -> ToolPickerResponse:
    last_msg = await run_graph(graph, graph_input, my_config)
    # Grab the info we need from the interrupted graph.
    tool_picker_response: ToolPickerResponse = await tools_service.handle_llm_response(
        last_msg
    )
    # OK, we extracted the data from the interrupted graph, tell the websocket about our progress.
    await websocket.send_text(
        SocketResponse(
            is_error=False,
            code=status.HTTP_200_OK,
            payload=ToolsSuggestedEvent(
                description=tool_picker_response.description,
                present_tools=tool_picker_response.present_tools,
                missing_tools=tool_picker_response.missing_tools,
            ).model_dump(),
        ).model_dump_json()
    )
    return ToolPickerResponse


async def _handle_steps_generator_common_core(
    checkpointer: BaseCheckpointSaver,
    formatted_human_msg: HumanMessage,
    formatted_sys_msg: SystemMessage,
    fut: FunctionSpec,
    llm: BaseChatModel,
    sql_session: Session,
    websocket: WebSocket,
):
    steps_service = StepsService()
    graph = await build_copilot_graph_with_structured_output(
        llm,
        checkpointer,
        [StepsGeneratorResponse],
    )
    my_config = await config_for_step_generation(fut)
    graph_input = {
        "messages": [formatted_sys_msg, formatted_human_msg],
    }

    last_msg = await run_graph(graph, graph_input, my_config)
    # Grab the info we need from the interrupted graph.
    last_tp, extracted_notes = await steps_service.handle_steps_generator_llm_response(
        fut, last_msg
    )

    await _send_generated_steps(last_tp, websocket)

    accepted_event = None
    while accepted_event is None:
        user_input_of_some_kind: Dict[Any, Any] = await websocket.receive_json()
        logger.debug("User provided feedback", user_said=user_input_of_some_kind)
        match user_input_of_some_kind["event_type"]:
            case ClientEventType.steps_retry:
                retry_event = StepsRetryEvent.model_validate(user_input_of_some_kind)
                accepted_event = None
                logger.debug("Parsed steps_retry event", retry_details=retry_event)
            case ClientEventType.steps_accepted:
                retry_event = None
                accepted_event = StepsAcceptedEvent.model_validate(
                    user_input_of_some_kind
                )
                logger.debug(
                    "Parsed steps_accepted event", accepted_details=accepted_event
                )
            case _:
                await websocket.send_text(
                    SocketResponse(
                        is_error=True,
                        code=status.HTTP_400_BAD_REQUEST,
                        payload={"errors": ["Unknown event type"]},
                    ).model_dump_json()
                )
                break

        if accepted_event is not None:
            logger.debug("Great success!")
            break

        general_feedback = (
            retry_event.user_feedback if retry_event.has_general_feedback else None
        )
        annotated_feedback = (
            retry_event.user_annotations
            if retry_event.has_specific_annotations
            else None
        )
        feedback_msg = prompts.steps_user_feedback_human_message(
            general_feedback=general_feedback,
            annotated_feedback=annotated_feedback,
        )
        logger.info(
            "HEY THERE! feedback_msg for feeding into the graph is ready",
            feedback_msg=feedback_msg,
        )

        await graph.aupdate_state(
            my_config,
            {
                "messages": [feedback_msg],
            },
            as_node="__start__",
        )
        graph_input = None
        # OK, the state has been edited (if needed), so let's just pick up again, shall we?
        last_msg = await run_graph(graph, graph_input, my_config)
        # Grab the info we need from the interrupted graph.
        last_tp, extracted_notes = (
            await steps_service.handle_steps_generator_llm_response(fut, last_msg)
        )

        await _send_generated_steps(last_tp, websocket)

    db_tp = TestPlan(
        function_spec_id=fut.id,
        full_text=last_tp.full_text,
    )
    sql_session.add(db_tp)
    if extracted_notes is not None:
        ai_memory = AiMemory(notes=extracted_notes)
        sql_session.add(ai_memory)
    sql_session.flush()
    sql_session.refresh(db_tp)
    await websocket.send_text(
        SocketResponse(
            is_error=False,
            code=status.HTTP_200_OK,
            payload=StepsPersistedEvent(
                test_plan=db_tp,
            ).model_dump(),
        ).model_dump_json()
    )


async def _send_generated_steps(last_tp, websocket):
    # FIXME: Figure out why we were doing this exception-swallowing stuff.
    try:
        # OK, we extracted the data from the interrupted graph, tell the websocket about our progress.
        await websocket.send_text(
            SocketResponse(
                is_error=False,
                code=status.HTTP_200_OK,
                payload=last_tp.model_dump(),
            ).model_dump_json(),
        )
        await websocket.send_text(
            SocketResponse(
                is_error=False,
                code=status.HTTP_200_OK,
                payload=StepsGeneratedEvent().model_dump(),
            ).model_dump_json()
        )
    except Exception as _e:  # noqa
        logger.exception("Error sending generated steps")


@router.websocket("/function_specs/{fut_id}/test_plan")
async def new_plan_for_function_ws(
    settings: SettingsDep,
    llm: LlmDependency,
    sql_session: WsSqlSessionDep,
    checkpointer: WsAsyncCheckpointerDep,
    boto_session: BotoSessionDep,
    websocket: WebSocket,
    fut_id: Annotated[
        int, "The ID of the FunctionSpec for which to generate a TestPlan"
    ],
):
    await websocket.accept()
    await websocket.send_json({"message": "Socket Connected"})
    try:
        steps_service = StepsService()
        sys_msg = await steps_service.build_system_message(llm, sql_session)
        func_service: FunctionSpecService = FunctionSpecService(sql_session, llm)
        fut: FunctionSpec = await func_service.find(function_spec_id=fut_id)
        dut: DeviceUnderTest = fut.device_spec.device_under_test

        toc_entry_service = DeviceSpecTocEntryService(sql_session)
        page_service: DeviceSpecPageService = DeviceSpecPageService(
            settings, sql_session, boto_session, toc_entry_service
        )
        pages = await page_service.fetch_fully_loaded_pages_for_function_spec(fut)
        fut_overview, fut_title = await get_overview_and_title_from_function_spec(fut)
        human_msg = prompts.steps_generator_human_message(
            dut_name=dut.name,
            fut_name=fut_title,
            fut_overview=fut_overview,
            page_data=pages,
        )
        logger.info(
            "Here's the human message we will send.",
            formatted_human_msg=human_msg.content,
        )

        await _handle_steps_generator_common_core(
            checkpointer,
            human_msg,
            sys_msg,
            fut,
            llm,
            sql_session,
            websocket,
        )
    except WebSocketDisconnect:
        logger.info("Client closed connection. I think.")
    except KeyError as ke:
        logger.exception("Missing parameter.")
        raise WebSocketException(1008, f"Missing parameter: {str(ke)}")
    except NotFoundException as nfe:
        logger.exception("Couldn't find referenced object.")
        raise WebSocketException(1008, f"Bad parameter. Details: {str(nfe)}")
    except Exception as e:  # noqa
        logger.exception("Unknown Exception")
        raise WebSocketException(1008, getattr(e, "message", repr(e)))
    finally:
        try:
            await websocket.close()
        except Exception:  # noqa
            logger.debug("Websocket was already closed, or something", exc_info=True)
