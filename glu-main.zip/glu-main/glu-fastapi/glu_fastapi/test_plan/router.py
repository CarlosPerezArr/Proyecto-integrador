from typing import Any, List, Annotated, Tuple
from typing import Annotated, Any
from fastapi import APIRouter, Path, Response


from fastapi import APIRouter, status, Query, Path
import structlog
from langchain_core.language_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage
from langgraph.checkpoint.base import BaseCheckpointSaver
from sqlmodel import select, Session

from ..copilot.services import ToolsService
from glu_fastapi.external_services import LlmDependency
from glu_fastapi.ai.models import AiMemory
from glu_fastapi.database.checkpointers import HttpAsyncCheckpointerDep
from glu_fastapi.copilot.models import ToolPickerResponse, ToolList
from glu_fastapi.database.session import SqlSessionDep
from glu_fastapi.exceptions import NotFoundException
from glu_fastapi.lab_bench.models import (
    TestBench,
    TestBenchRead,
    TestBenchReadWithDeviceInfo,
)
from glu_fastapi.lab_bench.services import TestBenchDeviceService
from glu_fastapi.langgraph_utils import (
    get_poc_bot,
    build_copilot_graph_with_structured_output,
    config_for_picking_tools,
    run_graph,
)
from glu_fastapi.test_plan.models import (
    TestScriptUpdate,
    TestPlan,
    TestPlanRead,
    TestPlanCreate,
)
from glu_fastapi.test_plan.services import TestPlanService

logger = structlog.get_logger()
router = APIRouter()


@router.get("validation_poc", response_model=AIMessage)
async def prove_it(
    llm: LlmDependency,
) -> Any:
    bot = get_poc_bot(llm)
    # 'bot' here is actually a runnable created by encode | real_graph | decode
    results = bot.invoke({"messages": [("user", "Does P = NP?")]})
    logger.error("WTF BRO!", results=results)
    return results


@router.get("/plans", response_model=List[TestPlanRead])
async def list_test_plans(
    sql_session: SqlSessionDep,
    offset: int = 0,
    limit: int = Query(default=20, le=20),
) -> Any:
    """List all the test plans."""
    test_plans = sql_session.exec(select(TestPlan).offset(offset).limit(limit)).all()
    return test_plans


@router.post(
    "/plans",
    response_model=TestPlanRead,
    status_code=status.HTTP_201_CREATED,
)
async def create_test_plan(
    test_plan_data: TestPlanCreate,
    sql_session: SqlSessionDep,
) -> Any:
    """Create a new test plan."""
    db_test_plan = TestPlan.model_validate(test_plan_data)
    sql_session.add(db_test_plan)
    sql_session.flush()
    return db_test_plan


@router.get(
    "/plans/{test_plan_id}",
    response_model=TestPlanRead,
)
async def view_test_plan(
    sql_session: SqlSessionDep,
    test_plan_id: Annotated[int, Path(title="The ID of the TestPlan to fetch.")],
) -> Any:
    """Retrieve a single ``TestPlan``."""
    service = TestPlanService(sql_session)
    return await service.find(test_plan_id)


@router.put(
    "/plans/{test_plan_id}",
    response_model=TestPlanRead,
)
async def update_test_script(
    test_script_id: Annotated[int, Path(title="The ID of the TestScript to update.")],
    script_data: TestScriptUpdate,
    sql_session: SqlSessionDep,
    function_spec_id: Annotated[
        int, Path(title="The ID of the FunctionSpec to update the test plan for.")
    ],
    test_bench_id: Annotated[
        int | None, "The ID of the TestBench we previously picked for this TestPlan"
    ] = None,
    _user_feedback: Annotated[
        str | None, "What the user wants to say to the LLM."
    ] = None,
    _user_annotations: Annotated[
        str, "Annotated feedback from the user on the existing."
    ] = None,
) -> Any:
    tools_service = ToolsService()
    system_message = await tools_service.build_system_message(llm, sql_session)
    logger.info(
        "Here's the formatted system message we will send.",
        formatted_sys_msg=system_message.content,
    )

    tp_service: TestPlanService = TestPlanService(sql_session)
    tp = await tp_service.find(test_plan_id=test_plan_id)
    tools_service = ToolsService()
    human_message = await tools_service.build_human_message(sql_session, tp)
    logger.info(
        "Here's the human message we will send.",
        formatted_human_msg=human_message.content,
    )

    return await _handle_tool_picker_graph(
        # checkpointer,
        human_message,
        system_message,
        tp,
        # llm,
        sql_session,
    )


@router.get(
    "/test_plans/{test_plan_id}/test_benches",
    response_model=List[TestBenchReadWithDeviceInfo,],
)
async def list_test_benches_for_test_plan(
    sql_session: SqlSessionDep,
    test_plan_id: Annotated[int, "The ID of the TestPlan to fetch TestBenches for."],
) -> Any:
    """List all the TestBenches associated with a given TestPlan."""
    tp_service = TestPlanService(sql_session)
    tp = await tp_service.find(test_plan_id)
    return tp.test_benches


async def _handle_tool_picker_graph(
    checkpointer: BaseCheckpointSaver,
    formatted_human_msg: BaseMessage,
    formatted_sys_msg: BaseMessage,
    tp: TestPlan,
    llm: BaseChatModel,
    sql_session: Session,
) -> TestBenchRead:
    graph = await build_copilot_graph_with_structured_output(
        llm,
        checkpointer,
        [ToolPickerResponse],
    )
    my_config = await config_for_picking_tools(tp)
    graph_input = {
        "messages": [formatted_sys_msg, formatted_human_msg],
    }
    last_msg = await run_graph(graph, graph_input, my_config)
    # Grab the info we need from the interrupted graph.
    tools_service = ToolsService()
    tool_picker_response: ToolPickerResponse = tools_service.handle_llm_response(
        last_msg
    )
    logger.debug(
        "Great success!",
        present_tools=tool_picker_response.present_tools,
        missing_tools=tool_picker_response.missing_tools,
        extracted_notes=tool_picker_response.new_user_notes,
        description=tool_picker_response.description,
    )

    tbd_service = TestBenchDeviceService(sql_session)
    db_test_bench = TestBench()
    for device in tool_picker_response.present_tools:
        tbd = await tbd_service.find_matching_test_bench_device(device)
        db_test_bench.test_bench_devices.append(tbd)
    sql_session.add(db_test_bench)

    if tool_picker_response.new_user_notes is not None:
        ai_memory = AiMemory(notes=tool_picker_response.new_user_notes)
        sql_session.add(ai_memory)

    sql_session.flush()
    sql_session.refresh(db_test_bench)
    return db_test_bench
