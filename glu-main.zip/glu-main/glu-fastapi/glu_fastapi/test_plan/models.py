from typing import Optional, Union, List, TYPE_CHECKING

from pydantic import BaseModel
from sqlalchemy import Column, Integer, ForeignKey
from sqlmodel import Field, Relationship

from glu_fastapi.cross_functional_links import TestPlanTestBenchLink
from glu_fastapi.per_tenant_models import BaseTable


if TYPE_CHECKING:
    from glu_fastapi.lab_bench.models import TestBench


class TestPlanBase(BaseTable):
    """A Markdown test plan document."""

    # Let's use up to 128k.
    full_text: str = Field(max_length=131_072)
    function_spec_id: int = Field(
        sa_column=Column(
            Integer,
            ForeignKey(
                "functionspec.id", name="fk__testplan__functionspec", ondelete="CASCADE"
            ),
            index=True,
            nullable=False,
        )
    )


class TestPlanForLlm(BaseModel):
    """Stripped down version of ``TestPlan`` for use w/ the LLM."""

    full_text: Optional[str] = Field(
        default=None,
        description="A GitHub-flavored Markdown document describing how to test the device in question.",
    )


class TestPlan(TestPlanBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    function_spec: Union["FunctionSpec"] = Relationship(  # noqa: F821
        back_populates="test_plan"
    )
    test_benches: List["TestBench"] = Relationship(
        back_populates="test_plans", link_model=TestPlanTestBenchLink
    )


class TestPlanCreate(TestPlanBase):
    pass


class TestPlanUpdate(TestPlanBase):
    full_text: Optional[str] = Field(None, description="Full text of the test plan")


class TestPlanRead(TestPlanBase):
    id: int


class TestScriptBase(BaseTable):
    """A Python test script."""

    # Let's use up to 128k.
    full_text: str = Field(max_length=131_072)
    function_spec_id: int = Field(
        sa_column=Column(
            Integer,
            ForeignKey(
                "functionspec.id",
                name="fk__testscript__functionspec",
                ondelete="CASCADE",
            ),
            index=True,
            nullable=False,
        )
    )


class TestScript(TestScriptBase, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    function_spec: Union["FunctionSpec"] = Relationship(  # noqa: F821
        back_populates="test_script"
    )


class TestScriptCreate(TestScriptBase):
    pass


class TestScriptUpdate(TestScriptBase):
    full_text: Optional[str] = Field(None, description="Script text of the test script")


class TestScriptRead(TestScriptBase):
    id: int
