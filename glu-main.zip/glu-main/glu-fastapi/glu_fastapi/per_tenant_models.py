"""Models for GLU.

These are built using SQLModel (by the author of FastAPI, it merges SQLAlchemy with
Pydantic). If you're not familiar with SQLModel, the tutorial_ is actually really
excellent. In particular, it might seem confusing that all these ``id`` columns are
defined as ``primary_key`` and also ``Optional``: the ``Optional`` bit is for Pydantic
(because new model objects won't have IDs yet when we're using auto-ids), whereas the
``primary_key`` bit in the ``Field`` call is for SQLAlchemy, so that it knows that's our
PK, it can't be ``null``, etc.

.. _tutorial:: https://sqlmodel.tiangolo.com/tutorial/
"""

from datetime import datetime
from typing import Optional

from sqlalchemy import DateTime, func
from sqlmodel import Field, SQLModel

OPENAI_DIMENSIONALITY = 1536


class BaseTable(SQLModel):
    """Common columns for (almost?) all our tables."""

    created_at: datetime | None = Field(
        default=None,
        sa_type=DateTime(timezone=True),
        sa_column_kwargs={"server_default": func.now(), "nullable": False},
    )
    updated_at: datetime | None = Field(
        default=None,
        sa_type=DateTime(timezone=True),
        sa_column_kwargs={"onupdate": func.now(), "nullable": True},
    )


class CommonDevice(BaseTable):
    """Common device attributes for ``DeviceUnderTest`` and ``TestBenchDevice``."""

    name: str = Field(index=True)
    description: Optional[str] = None
    # NOTE: We'll probably want to pull this into its own, full-fledged model at some point.
    manufacturer: Optional[str] = None
