"""CLI commands for GLU."""

from typing import Annotated
import typer
from rich import print
from langgraph.checkpoint.postgres import PostgresSaver
from psycopg import Connection
from sqlmodel import Session, select
from sqlalchemy.schema import CreateSchema, DropSchema
from glu_fastapi.shared_models import Tenant
from glu_fastapi.database import get_engine
from glu_fastapi.config import glu_settings


app = typer.Typer(name="GLU")
engine = get_engine(glu_settings())


@app.command()
def list_tenants():
    """List the ``Tenant`` records in the DB."""
    with Session(engine) as session:
        tenants = session.exec(select(Tenant)).all()
        print("Tenants:\n", tenants)


@app.command()
def load_lab_equipment(
    schema: Annotated[
        str,
        typer.Option(
            ...,
            "--schema",
            show_default=False,
            prompt=True,
            help="The name of the Postgres schema into which we should load the lab equipment data.",
        ),
    ],
):
    """Load data out of a CSV from Rick into ``TestBenchDevice`` records."""

    import csv
    import re
    import structlog
    from glu_fastapi.lab_bench.models import TestBenchDevice

    logger = structlog.get_logger()
    ivi_stripper = re.compile(r"(?P<ivi_prefix>ivi-*_*)?(?P<actual>.+)", re.IGNORECASE)

    host_to_schema = {None: schema}
    logger.debug("Setting up schema translation for tenant.", mapping=host_to_schema)
    engine.update_execution_options(schema_translate_map=host_to_schema)

    with open("data_fixtures/bench_tools.csv", newline="") as tools_csv:
        tool_reader = csv.reader(tools_csv, delimiter=",")
        with Session(engine) as session:
            try:
                for row in tool_reader:
                    manufacturer = row[0].strip()
                    raw_category = row[1].strip()
                    category = ivi_stripper.match(raw_category).group("actual")
                    name_or_names = row[2]
                    ivi_tags = row[4:]
                    for name in name_or_names.split(","):
                        logger.debug(
                            "Parsed a row",
                            manufacturer=manufacturer,
                            raw_category=raw_category,
                            category=category,
                            name=name,
                            ivi_tags=ivi_tags,
                        )
                        device = TestBenchDevice(
                            manufacturer=manufacturer,
                            name=name.strip(),
                            category=category,
                            ivi_tags=ivi_tags,
                        )
                        session.add(device)
            except Exception as e:
                session.rollback()
                raise e
            else:
                session.commit()


@app.command()
def create_tenant(
    name: Annotated[
        str,
        typer.Option(
            ...,
            "--name",
            show_default=False,
            prompt=True,
            help="The name of the new Tenant.",
        ),
    ],
    schema: Annotated[
        str,
        typer.Option(
            ...,
            "--schema",
            show_default=False,
            prompt=True,
            help="The name of the Postgres schema to contain the new Tenant's data.",
        ),
    ],
    host: Annotated[
        str,
        typer.Option(
            ...,
            "--host",
            show_default=False,
            prompt=True,
            help="The host customers will use when accessing the new Tenant, e.g., psl.api.glutest.ai",
        ),
    ],
    org_id: Annotated[
        str,
        typer.Option(
            ...,
            "--org-id",
            show_default=False,
            prompt=True,
            help="The auth0 Organization ID that matches the new Tenant.",
        ),
    ],
):
    """Create a new ``Tenant`` in the DB, including the Postgres ``schema``.

    .. NOTE:: This will **NOT** create a new ``Organization`` in Auth0, but there needs to be one corresponding to the
              new ``Tenant``.
    """
    with Session(engine) as session:
        try:
            t = Tenant(name=name, their_schema=schema, host=host, org_id=org_id)
            session.add(t)
            create_schema_stmt = CreateSchema(schema, if_not_exists=True)
            session.execute(create_schema_stmt)
        except Exception as e:
            session.rollback()
            raise e
        else:
            session.commit()


@app.command()
def destroy_tenant(
    name: Annotated[
        str,
        typer.Option(
            ...,
            "--name",
            show_default=False,
            prompt=True,
            help="The name of Tenant to destroy.",
        ),
    ],
):
    """Delete a ``Tenant`` from the DB, including the Postgres ``schema``.

    .. NOTE:: This will **NOT** delete ``Organization`` in Auth0, but you should manually clean it up, as well.
    """
    with Session(engine) as session:
        try:
            select_stmt = select(Tenant).where(Tenant.name == name)
            t = session.execute(select_stmt).first()
            if t is None:
                print(f"No Tenant with that name ({name}).")
                raise typer.Exit()

            # NOTE: I'm fairly sure this shouldn't be necessary; I think we're supposed to be getting a ``Tenant``
            #       object directly, not a SQLAlchemy row 😒.
            t = t[0]
            print(f"Found one? {t} is a {type(t)}")
            session.delete(t)
            drop_schema_stmt = DropSchema(t.their_schema, cascade=True, if_exists=True)
            session.execute(drop_schema_stmt)
        except Exception as e:
            session.rollback()
            raise e
        else:
            session.commit()


@app.command()
def setup_checkpointer_for_tenant(
    name: Annotated[
        str,
        typer.Option(
            ...,
            "--name",
            show_default=False,
            prompt=True,
            help="The name of Tenant to modify.",
        ),
    ],
):
    """Set up the Postgres machinery for the LangGraph Checkpointer system inside the named ``Tenant``'s ``schema``."""
    s = glu_settings()
    with Connection.connect(conninfo=s.psycopg_url) as conn:
        # Fetch the proper schema name and set the search path to it.
        schema_name = conn.execute(
            "SELECT their_schema FROM shared.tenant WHERE name = %s",
            (name,),
        ).fetchone()[0]

    # Now that we've done the stuff specific to our app, fire the one-time setup for the checkpointer.
    schema_specific_conn_string = (
        f"{s.psycopg_url} options='-c search_path={schema_name}'"
    )
    with Connection.connect(
        conninfo=schema_specific_conn_string,
        autocommit=True,
        prepare_threshold=0,
    ) as autocommitting_conn:
        checkpointer = PostgresSaver(autocommitting_conn)
        try:
            checkpointer.setup()
        except Exception as e:
            print(e)


if __name__ == "__main__":
    app()
