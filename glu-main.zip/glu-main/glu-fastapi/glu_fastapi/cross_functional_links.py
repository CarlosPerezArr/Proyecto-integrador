from typing import Optional
from sqlmodel import Field, SQLModel


class TestBenchTestPlanLink(SQLModel, table=True):
    """Links a TestBench to a TestPlan."""

    __tablename__ = "test_bench_test_plan_link"

    test_bench_id: Optional[int] = Field(
        default=None, foreign_key="test_bench.id", primary_key=True
    )
    test_plan_id: Optional[int] = Field(
        default=None, foreign_key="test_plan.id", primary_key=True
    )


class TestBenchDeviceTestPlanLink(SQLModel, table=True):
    """Links a TestBenchDevice to a TestPlan."""

    __tablename__ = "test_bench_device_test_plan_link"

    test_bench_device_id: Optional[int] = Field(
        default=None, foreign_key="test_bench_device.id", primary_key=True
    )
    test_plan_id: Optional[int] = Field(
        default=None, foreign_key="test_plan.id", primary_key=True
    )


class TestPlanFunctionSpecLink(SQLModel, table=True):
    """Links a TestPlan to a FunctionSpec."""

    __tablename__ = "test_plan_function_spec_link"

    test_plan_id: Optional[int] = Field(
        default=None, foreign_key="test_plan.id", primary_key=True
    )
    function_spec_id: Optional[int] = Field(
        default=None, foreign_key="function_spec.id", primary_key=True
    )
