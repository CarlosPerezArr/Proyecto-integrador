import asyncio
from typing import List

import aiofiles
from pypdfium2 import PdfDocument
from structlog import get_logger

from .models import Section, TableOfContents, SectionHolder
from .models_implementation import (
    Feature,
    FeaturesResponse,
    SectionReference,
    FeatureReference,
)
from .services import BookwormService
from langchain.chat_models.base import BaseChatModel


logger = get_logger()


class CreateTestPlanService(BookwormService):
    def __init__(
        self,
        llm_client: BaseChatModel,
        max_concurrency: int = 50,
        file_handler=None,
        pdf_handler=None,
    ):
        self.llm_client: BaseChatModel = llm_client
        self._limiter = asyncio.Semaphore(max_concurrency)
        self.file_handler = file_handler or aiofiles
        self.pdf_handler = pdf_handler or PdfDocument

    async def get_test_features(
        self,
        sections: List[SectionHolder],
        table_of_contents: List[TableOfContents],
        existing_features: List[Feature] = [],
    ) -> List[Feature]:
        if len(sections) == 0:
            return []

        mapping = {}
        holder: SectionHolder
        for holder in sections:
            mapping[holder.id] = holder.section

        # assume that we will always have a current page
        content = []

        toc_items = []
        for toc_item in table_of_contents:
            toc_items.append(toc_item.title)

        if len(toc_items) > 0:
            tocs = "\n".join(toc_items)
            content.append(
                {
                    "type": "text",
                    "text": "#Table of Contents Item\nThese are for CONTEXT only, do not create features from the Table of Contents list.",
                }
            )
            content.append(
                {
                    "type": "text",
                    "text": f"{tocs}",
                }
            )

        content.append(
            {
                "type": "text",
                "text": "#Sections to Review",
            }
        )
        for i, holder in enumerate(sections):
            section: Section = holder.section
            content.append(
                {
                    "type": "text",
                    "text": f"Section #{holder.id}: {section.title}\n{section.content}",
                }
            )

        if len(existing_features) > 0:
            existing_feature_text = ""

            for existing_feature in existing_features:
                existing_feature_text += f"## Title: {existing_feature.title}\n### Objective: {existing_feature.content}\n\n"

            content.append(
                {
                    "type": "text",
                    "text": "# Existing Features\nReview both the title and objective of these and DO NOT REPEAT and DO NOT USE DUPLICATE CONTENT EVEN WITH A DIFFERENT NAME.",
                }
            )
            content.append(
                {
                    "type": "text",
                    "text": f"{existing_feature_text}",
                }
            )

        response: FeaturesResponse = await self._call_llm(
            prompt=parse_features_prompt,
            response_format=FeaturesResponse,
            content=content,
        )

        features = []
        feature: FeatureReference
        for feature in response.features:

            required: List[Section] = []
            context: List[Section] = []
            section: SectionReference
            for section in feature.required or []:
                if mapping.get(section.id) is not None:
                    required.append(mapping.get(section.id))
            for section in feature.context or []:
                if mapping.get(section.id) is not None:
                    context.append(mapping.get(section.id))
            feature_title = feature.name
            feature_content = feature.content
            page_number = 0
            if len(required) > 0 and required[0] is not None:
                page_number = required[0].page_number
            elif len(context) > 0 and context[0] is not None:
                page_number = context[0].page_number

            if len(required) < 1:
                logger.warn(
                    "We have a feature without any required sections?", feature=feature
                )

            # remove dupes from context, they should prioritize being in required
            context = list(set(context) - set(required))

            feat = Feature(
                title=feature_title,
                content=feature_content,
                required_sections=required,
                context_sections=context,
                page_number=page_number,
            )
            features.append(feat)

        features = sorted(features)
        return features


parse_features_prompt = """
You are an experienced hardware test developer with 30 years of experience. Your job is to interpret feature specifications and test plans for hardware in development/pre-production. You will work with a test engineer to develop a robust sequence of test steps using the equipment they have available.

Below is a partial list of sections from the specification document for a device under test. Come up with a list of 1) features, 2) characteristics, 3) specific test procedures, 4) varifiable results, or 5) similar items of the device that you should write test plans for. This includes how the device interacts with other devices and services. Your list will serve as the outline for a new test plan document. Do not include anything in the list that is not a feature or characteristic of the device that you intend to test. Related tests are ok. Repeated features are not ok. You need to recognize when similar names are actually overlapping features and then ONLY include unique features. Each section may have more than one feature to test, carefully analyze each section.

Categorize and name the feature/characteristic/result/test appropriately for what it is testing. Don't include section numbers in your list.

Use the Table of Contents as a tiny hint as to what the author thinks is important in this document. Features they need to be present in the sections you are analyzing, not just the Table of Contents. You should expand outside the Table of Contents for your feature list when appropriate.

Try to standardize naming. Do not combine the features. It is ok to have related features but do not create duplicates. FEATURES SHOULD REMAIN SEPARATE AND INDEPENDENT.

If there are no logical features, etc., please return an empty list in features. But be detailed and inclusive.

IMPORTANT:
- Do not include features like "verify that the right hardware was used" in construction of the device, rather that the device is functioning correctly with the included hardware
- A feature MUST have at least one required section from the original document sections.
- Only return new features, you should not repeat existing features. If a feature already exists in the list of existing features (you can tell by the name and description), skip it.
- If the CONTENT for the section is not here or on the following page(s), just the title, do not include a section
- Follow a common pattern when naming features, where appropriate
- Include features like verification and validation of:
    * Error handling, or identifying behavior not working
    * Data management
    * Data cleanup/clearing settings
    * Localization/language
    * Regionalized behavior
    * Compliance and certification
"""
