import asyncio
from asyncio import gather
from pathlib import Path
import tempfile
from typing import List
import base64
import shutil

import aiofiles
import backoff
import openai
from pypdfium2 import PdfPage, PdfDocument
from structlog import get_logger

from .task_group_error_handler import TaskGroupErrorHandler
from .models import (
    UnstructuredDocument,
    Page,
    Section,
    TableOfContents,
    PageContent,
    TableOfContentsResponse,
    RelatedSectionsResponse,
    RelatedSection,
)
from langchain_openai import ChatOpenAI

from langchain.schema import HumanMessage, SystemMessage
from typing import Type, TypeVar

from pydantic import BaseModel


logger = get_logger()

# after testing, these seem to give the most consistent results for our tests
prefix_pages: int = 2
suffix_pages: int = 2


class PrioritySemaphore:
    def __init__(self, value: int):
        self._queue = asyncio.PriorityQueue()
        self._sem = asyncio.Semaphore(value)

    async def acquire(self, priority: int = 0):
        await self._queue.put((priority, asyncio.current_task()))
        while (await self._queue.get())[1] != asyncio.current_task():
            await asyncio.sleep(0)
        return await self._sem.acquire()

    def release(self):
        self._sem.release()

    async def __aenter__(self):
        await self.acquire()

    async def __aexit__(self, exc_type, exc, tb):
        self.release()


class BookwormService:
    semaphore: PrioritySemaphore = PrioritySemaphore(40)

    def __init__(
        self,
        llm_client: ChatOpenAI,
        max_concurrency: int = 40,
        file_handler=None,
        pdf_handler=None,
    ):
        self.llm_client: ChatOpenAI = llm_client
        self.file_handler = file_handler or aiofiles
        self.pdf_handler = pdf_handler or PdfDocument
        self.semaphore = PrioritySemaphore(value=max_concurrency)

    tokens_request = 0
    tokens_response = 0
    tokens_price = 0

    async def process_bytes(
        self, data: bytes, document: UnstructuredDocument = None
    ) -> UnstructuredDocument:

        if document is None:
            document = UnstructuredDocument(summary="", pages=[])
        pdf = self.pdf_handler(data)
        document = await self.process_pdf(pdf=pdf, document=document)
        return document

    async def process_pdf(
        self, pdf: PdfDocument, document: UnstructuredDocument = None
    ) -> UnstructuredDocument:
        if document is None:
            document = UnstructuredDocument()
        num_pages = len(pdf)
        logger.debug("Processing a document.", num_pages=num_pages)

        temporary_directory = tempfile.mkdtemp()
        try:
            # Do your operations
            page_paths = await self.save_pages(
                temporary_directory=temporary_directory, pdf=pdf
            )
            pages = await self.pass_parse_pages(page_paths=page_paths)
            await self.add_related_sections(document=document)
        finally:
            # Clean up when you're done
            shutil.rmtree(temporary_directory)
        document.pages = pages

        return document

    async def add_related_sections(self, document: UnstructuredDocument) -> List:
        sections = document.get_sections_in_document()
        related_list: List[RelatedSection] = await self.get_related_sections(
            sections=sections
        )
        for related in related_list:
            if related.section_id == -1:
                continue
            section: RelatedSection = sections[related.section_id]
            # FIXME: .required is not a thing on RelatedSection. The actual code is using a SectionRelations instead of a RelatedSection. Update the typo annotation? Or are we mid-stream on a refactor or something?
            for required in related.required:
                section.related_required.append(sections[required.section_id])
            # FIXME: .context is not a thing on RelatedSection. The actual code is using a SectionRelations instead of a RelatedSection. Update the typo annotation? Or are we mid-stream on a refactor or something?
            for context in related.context:
                section.related_context.append(sections[context.section_id])

        return related_list

    async def save_pages(self, temporary_directory, pdf: PdfDocument) -> List[Path]:
        file_tasks = []
        error_handler = TaskGroupErrorHandler()

        def handle_value_error(e: Exception):
            raise e

        async with asyncio.TaskGroup() as group:
            for page_num, page in enumerate(pdf):
                file_tasks.append(
                    group.create_task(
                        error_handler.run_with_error_handling(
                            self.save_page(
                                temporary_directory,
                                page_num,
                                page,
                            ),
                            error_handler=handle_value_error,
                            task_name=f"Process Page - Page {page_num}",
                        )
                    )
                )
        # this now returns just the saved pages, we aren't doing the LLM processing yet
        page_paths = [t.result() for t in file_tasks if t.done() and not t.cancelled()]

        logger.debug("Files saved")

        return page_paths

    async def pass_parse_pages(self, page_paths: List[Path]) -> List[Page]:
        page_tasks = []

        error_handler = TaskGroupErrorHandler()

        def handle_value_error(e: Exception):
            raise e

        async with asyncio.TaskGroup() as group:
            for i, page in enumerate(page_paths):
                page_tasks.append(
                    group.create_task(
                        error_handler.run_with_error_handling(
                            self.pass_parse_page(page_paths, i),
                            error_handler=handle_value_error,
                            task_name=f"Parse Page - Page {i}",
                        )
                    )
                )

        # this now does the LLM processing per page
        page_results = [
            t.result() for t in page_tasks if t.done() and not t.cancelled()
        ]

        return page_results

    async def pass_parse_page(self, page_paths: List[Path], page_num: int) -> Page:
        async with asyncio.TaskGroup() as tg:
            page_task = tg.create_task(
                self.pass_parse_page_sections(page_paths, page_num)
            )
            toc_task = tg.create_task(self.pass_parse_page_toc(page_paths[page_num]))

        page = page_task.result()
        toc = toc_task.result()

        page.table_of_contents = toc
        return page

    async def pass_parse_page_sections(
        self, page_paths: List[Path], page_num: int
    ) -> Page | None:
        # assume that we will always have a current page
        content = []

        range = self._get_page_range(
            page_num, prefix_pages, suffix_pages, len(page_paths)
        )
        for i in range:
            if i == page_num:
                text = f"This is the current page, page number {i}. This is the page that you should parse. Only return sections and their headings and chart/figure/table labels that are present on this page. This includes sections that are at the top of the page or that constitute the whole page. There is a STRONG chance that sections continue across pages. Make sure you include specific values/numbers/other information from the preceding/following pages as required."
            elif i == page_num + 1:
                text = f"This is a page for context, page number {i}. Include any content from sections that start on the previous page (page #{i-1}) in the sections. Never include sections that start on this page."
            else:
                text = f"This is a page for context, page number {i}. Do not return sections or figure/table labels from this page."

            path = page_paths[i]
            try:
                image = await self._encode_image(path)
                content.append(
                    {
                        "type": "text",
                        "text": text,
                    }
                )
                content.append(
                    {
                        "type": "image_url",
                        "image_url": {
                            "url": f"data:image/jpeg;base64,{image}",
                            "detail": "high",
                        },
                    }
                )
            except Exception:
                logger.warn(f"Unable to parse image on page {i}")
                pass

        response: PageContent = await self._call_llm(
            prompt=parse_page_headings_prompt,
            response_format=PageContent,
            content=content,
            priority=10,
        )

        if not response:  # Check for empty string first
            return None

        logger.debug("Sections", sections=response.sections)
        sections = []
        for section in response.sections or []:

            sections.append(
                Section(
                    title=section.title,
                    content=section.content,
                    starts=section.starts,
                    page_number=page_num,
                    page_number_last=section.page_number_last,
                )
            )

        toc = []
        for table_item in response.table_of_contents or []:

            toc.append(
                TableOfContents(
                    title=table_item.title,
                    section=table_item.section,
                    page=table_item.page,
                )
            )

        return Page(
            local_file=page_paths[page_num],
            sections=sections,
            table_of_contents=toc,
            summary=response.summary,
            page=page_num,
        )

    async def pass_parse_page_toc(self, path: Path) -> List[TableOfContents]:
        content = [
            {
                "type": "text",
                "text": "This is the page that may contain a table of contents",
            },
            {
                "type": "image_url",
                "image_url": {
                    "url": f"data:image/jpeg;base64,{await self._encode_image(path)}",
                    "detail": "high",
                },
            },
        ]

        response: TableOfContentsResponse = await self._call_llm(
            prompt=parse_table_of_contents_prompt,
            response_format=TableOfContentsResponse,
            content=content,
            priority=7,
        )

        if not response:  # Check for empty string first
            return []

        logger.debug("TOC entries", entries=response.entries)
        toc = [
            TableOfContents(title=entry.title, section=entry.section, page=entry.page)
            for entry in response.entries
        ]
        return toc

    @backoff.on_exception(
        backoff.expo, openai.RateLimitError, max_tries=3, max_time=180
    )
    async def save_page(
        self,
        page_images_go_here: str,
        page_num: int,
        page: PdfPage,
    ) -> Path:
        async with self.semaphore:
            path_for_page = await self._save_page_image(
                page, page_images_go_here, page_num
            )
            return path_for_page

    async def _save_page_image(
        self, page: PdfPage, directory: str, page_num: int
    ) -> Path:
        path_for_page = Path(directory) / f"page_{page_num:03d}.jpg"
        image = page.render(scale=4).to_pil()
        image.save(path_for_page)
        return path_for_page

    async def get_related_sections(
        self, sections: List[Section]
    ) -> List[RelatedSection]:
        per_loop = 5
        tasks = []
        results = []

        # TODO: Consider the task pool thing I use somewhere else.

        # Create tasks for each batch
        for i in range(0, len(sections), per_loop):
            section_window = sections[i : i + per_loop]
            task = self._process_section_batch(i, section_window, sections)
            tasks.append(task)

        # Run all tasks concurrently and gather results
        try:
            batch_results = await gather(*tasks)
            # Flatten results list and filter out empty results
            batch: RelatedSectionsResponse
            for batch in batch_results:
                if batch:  # Only extend if batch is not empty
                    results.extend(batch.sections)
        except Exception as e:
            import traceback

            err = traceback.format_exc()
            print(err)
            logger.error(f"Error processing sections in parallel: {str(e)}")
            return []

        return results

    async def _process_section_batch(
        self, start_idx: int, section_window: List[Section], sections: List[Section]
    ) -> RelatedSectionsResponse:

        content = [
            {
                "type": "text",
                "text": "Below are ALL the sections from this document, use these sections only for input.",
            }
        ]

        # Add the full context sections
        for j, section in enumerate(sections):
            content.extend(
                [
                    {
                        "type": "text",
                        "text": f"#This is section #{j}, it is just here to choose from.",
                    },
                    {
                        "type": "text",
                        "text": f"##{section.title}\nPage #{section.page_number}\n{section.content}",
                    },
                ]
            )

        # Add the sections to analyze
        content.append(
            {
                "type": "text",
                "text": "Below are the sections I need you to figure out related sections for. ONLY RETURN RESULTS FOR THESE.",
            }
        )

        for j, section in enumerate(section_window):
            content.extend(
                [
                    {
                        "type": "text",
                        "text": f"#This is section #{j + start_idx}, help me find required and context sections for it.",
                    },
                    {
                        "type": "text",
                        "text": f"##{section.title}\nPage #{section.page_number}\n{section.content}",
                    },
                ]
            )

        response: RelatedSectionsResponse = await self._call_llm(
            prompt=get_related_sections_prompt,
            response_format=RelatedSectionsResponse,
            content=content,
            priority=15,
        )

        return response

    def _get_page_range(
        self, current_page: int, prefix: int, suffix: int, total_pages: int
    ):
        min_page = max(0, current_page - prefix) + 1  # Don't go below page 1
        max_page = min(
            total_pages - 1, current_page + suffix
        )  # Don't exceed total pages

        return range(min_page, max_page)

    # TODO: Verify if this should be ASCII or base64.
    async def _encode_image(self, image_path: Path) -> str:
        async with aiofiles.open(image_path, "rb") as image_file:
            return base64.b64encode(await image_file.read()).decode("ascii")

    ResponseType = TypeVar("ResponseType", bound=BaseModel)

    async def _call_llm(
        self,
        prompt: str,
        response_format: Type[ResponseType],
        content: list,
        priority: int = 5,
    ) -> ResponseType:
        await self.semaphore.acquire(priority)
        try:
            messages = [SystemMessage(content=prompt), HumanMessage(content=content)]

            structured_llm = self.llm_client.with_structured_output(response_format)

            response = await structured_llm.ainvoke(input=messages)

            return response
        finally:
            self.semaphore.release()


# Prompts
# FIXME: Extract to prompt file.
parse_table_of_contents_prompt = """
You are a helpful document indexer. You have been asked to index a document. Please do not miss any of the indexing we need to do. Err on the side of inclusion. If there are sub items (e.g. 1.1 or 4.5.a) for the table of contents, explicitly include them as their own section.

Please look at the following document. If there is a table of contents, please list the sections and their page numbers.

If there is no table of contents on this page, return an empty array (list).

IMPORTANT:
- DO NOT include error messages. If there is no table of contents, return an empty string.
- DO NOT include the headings in the JSON - there may be other pages to process later and they'll be appended to your result
- Only respond with the JSON values for the table of contents. Your answer will be fed into an API so any additional text will break the parser.
- Make sure your response includes ALL required fields for the JSON, otherwise the API will break.
"""


parse_page_headings_prompt = """
You are a helpful document parser. You have been asked to parse a document. BE VERY DISCERNING ABOUT THIS. REVIEW ALL THE CONTENT CAREFULLY AND CONSIDER THE IMPLICATIONS BEFORE MAKING A DECISION.

Divide this page up into high-level logical sections. Divide into logical sections based on the layout AND content (DEEPLY UNDERSTAND THE CONTENT TO MAKE THIS ASSESSMENT). Use whitespace, borders, headings, labels, section content as some of your possible indicators that a logical section started/ended. There are other ways to identify logical sections, be creative. If this section is ONLY a reference to a later page/section in the document (with no content), do not include it.

Analyze whether any part of the page is part of or a complete Table of Contents, Section Outline, or Table of Tables. These sections MUST BE ADDED to the "table_of_contents", DO NOT INCLUDE THEM IN "sections". If a section is listed to start on a different page, this means it belongs in table of contents. Use information from previous and following pages to decide. To identify a table of contents, look for a structured list with section titles or headings paired with corresponding page numbers, often aligned on the right. Additionally, it typically features hierarchical numbering or formatting that outlines the document's organization and helps with navigation.

# IMPORTANT VALUES EXTRACTION
For each section, carefully identify and structure important numerical values and requirements:
- Temperature ranges (with units)
- Time durations and intervals
- Rates and frequencies
- Physical measurements
- Counts and quantities
- Performance requirements
- Operational constraints
- Testing parameters
Format these in a structured JSON object under "important_values" with appropriate nesting and clear labeling of units and constraints.

Please list all the distinct document sections/subsections in a JSON array. Individual table/graph/chart/image/etc. each count as their own logical section. Check if tables/graphs/etc. start on the previous page (you can use table headings to figure this out).

# IMPORTANT
- If a section starts on a previous page, include it in the sections list, but set "starts" to false
- Always include specific values/figures, these must be exact! Include things like times, temperatures, axis, ramp time, degrees, units, degrees/minute, voltage, etc.
- ALWAYS PUT CONTENT IN important_values. ALWAYS!
- Tables and diagrams and images may also span pages. CHECK IF THE TABLE/DIAGRAM/IMAGE IS A CONTINUATION OF THE PREVIOUS PAGE.
- If a section, table, diagram, etc. continues on the next page(s), include ALL THE information from those pages in the relevant logical section.
- For each logical section - include all detailed information from that specific section. TAKE AS MUCH SPACE AS YOU NEED.
- Lean towards more logical sections than less, but only if they make sense.
- Remember what I said about ignoring Table of Contents, Section Outline, and Table of Tables content.
- ITEMS SHOULD ONLY GO INTO ONE OF "table_of_contents" (highest priority if a match for Table of Contents/Section Outline/Table of Tables), "sections," or "not_included" (lowest priorty) PICK THE BEST OPTION!

# EXAMPLE
The output should be a JSON object with these fields:
{
    "table_of_contents": [...],
    "sections": [
        {
            "title": "section title",
            "content": "full section content",
            "starts": true/false,
            "page_number": X,
            "page_number_last": Y,
            "important_values": {
                // Structured representation of numerical values and requirements
                // Example:
                "temperatureRange": {
                    "required": {
                        "minimum": 0,
                        "maximum": 150,
                        "units": "Fahrenheit"
                    },
                    // Additional nested structures as needed
                }
            }
        },
        ...
    ],
    "not_included": [...]
}
"""


get_related_sections_prompt = """
You are a helpful document parser. I need your help parsing a document.

Tell me all the other sections in this document that are DIRECTLY related to a set of sections. Use clues like content, proximity, etc. Be specific and detailed, explain why we need the sections you claim. Which are sections required to actually understand the section and which are sections required for more general knowledge (context) around this topic? Err on the side of more information.

Review all the sections provided and see which should belong to each category, either required or context (only include sections that are part of one category or the other). Do this for each of the sections we are trying to parse.

IMPORTANT:
- DO NOT include error messages. If there are no relevant required or context sections, return an empty array.
- DO NOT include the headings in the JSON - there may be other pages to process later and they'll be appended to your result
- Only respond with the JSON values dictated. Your answer will be fed into an API so any additional text will break the parser.
"""
