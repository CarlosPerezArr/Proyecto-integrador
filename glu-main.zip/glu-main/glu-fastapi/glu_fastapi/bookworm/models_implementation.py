from typing import List, Set, Optional
import json
from pydantic import BaseModel, Field
from .models import UnstructuredDocument, DocumentItem, Section


class SectionReference(BaseModel):
    """Reference to a section in the document."""

    id: int = Field(description="Section identifier")
    name: str = Field(description="Section name")


class RejectedSection(BaseModel):
    """A section that was rejected from feature extraction."""

    name: str = Field(description="The name of the section")
    reason: str = Field(
        description="The reason why this was not included in the list of features"
    )
    to_include: str = Field(
        alias="prompt_changes",
        description="Required changes to the request itself (not the section content) to include this item",
    )


class Feature(DocumentItem):
    """A feature described in the specification document."""

    title: str = Field(description="Title of the document item")

    required_sections: List[Section] = Field(
        default_factory=list, description="Sections that are required for this feature"
    )
    context_sections: List[Section] = Field(
        default_factory=list,
        description="Sections that provide context for this feature",
    )

    def to_json(self, visited_sections: Optional[Set[int]] = None) -> dict:
        """Convert feature to JSON, handling circular references."""
        if visited_sections is None:
            visited_sections = set()

        return {
            "title": self.title,
            "content": self.content,
            "page_number": self.page_number,
            "required_sections": [
                section.to_json(visited_sections)
                for section in self.required_sections
                if id(section) not in visited_sections
            ],
            "context_sections": [
                section.to_json(visited_sections)
                for section in self.context_sections
                if id(section) not in visited_sections
            ],
        }

    # FIXME: Look into whether we can just use the built-in Pydantic stuff
    #        instead of hand-rolling these two methods.
    @classmethod
    def from_json_str(cls, json_str: str) -> "Feature":
        """Create Feature from JSON string."""
        data = json.loads(json_str)
        return cls.from_json(data=data)

    @classmethod
    def from_json(cls, data: dict) -> "Feature":
        """Create Feature from JSON dict."""
        return cls(
            title=data["title"],
            content=data["content"],
            page_number=data["page_number"],
            required_sections=[Section.from_json(s) for s in data["required_sections"]],
            context_sections=[Section.from_json(s) for s in data["context_sections"]],
        )

    def get_all_page_numbers(self) -> List[int]:
        """Get all page numbers recursively from required and context sections."""

        def get_section_pages(section: Section, visited: Set[int]) -> Set[int]:
            if id(section) in visited:
                return set()

            visited.add(id(section))
            pages = set(range(section.page_number, section.page_number_last + 1))

            for req in section.related_required:
                pages.update(get_section_pages(req, visited))
            for ctx in section.related_context:
                pages.update(get_section_pages(ctx, visited))

            return pages

        required_pages = set()
        context_pages = set()
        visited = set()

        for section in self.required_sections:
            required_pages.update(get_section_pages(section, visited))

        visited.clear()
        for section in self.context_sections:
            context_pages.update(get_section_pages(section, visited))

        context_pages = context_pages - required_pages
        return sorted(list(required_pages)) + sorted(list(context_pages))

    def __lt__(self, other: "Feature") -> bool:
        """Compare features by title."""
        if not isinstance(other, Feature):
            return NotImplemented
        return self.title < other.title

    class Config:
        """Pydantic config."""

        arbitrary_types_allowed = True
        validate_assignment = True


class FeatureReference(BaseModel):
    """A feature to be tested from the specification document."""

    name: str = Field(
        description="A unique name in the format: Category > Function > Sub-function (if any). Standardize this as much as you can across features."
    )
    required: List[SectionReference] = Field(
        description="List of sections that are required information required for testing"
    )
    context: List[SectionReference] = Field(
        description="List of sections that are context, but not required information required for testing"
    )
    content: str = Field(
        description="Detailed information about the feature that we're going to test and the tests we should conduct. "
        "This should include SPECIFIC details about implementation. Specific numbers, measurements, data, etc."
    )
    content: str = Field(
        justification="Justfication as to why this feature is distinct enough from the others already created to include it."
    )


class FeatureDocument(UnstructuredDocument):
    """Document containing features and their related sections."""

    features: List[Feature] = Field(
        default_factory=list, description="List of features described in the document"
    )


class FeaturesResponse(BaseModel):
    """Complete response for feature extraction."""

    rejected_sections: List[RejectedSection] = Field(
        default_factory=list,
        description="List of sections that were rejected from feature extraction",
    )
    features: List[FeatureReference] = Field(
        description="List of extracted features, testable characteristics, testable functionality, or defined tests"
    )
