from typing import Dict, List, Optional, Any
from pathlib import Path
from pydantic import BaseModel, Field, field_validator
from enum import Enum


class DocumentItem(BaseModel):
    """Base class for items that appear in the specification document."""

    page_number: int = Field(description="The page number where this item appears")
    title: str = Field(description="Title of the document item")
    content: str = Field(
        description="Detailed information about the content related to this heading or label. If there is something important in this section, include this explicitly in the summary. This should include SPECIFIC details about implementation. Specific numbers, measurements, data, requirements, etc. If this spans across multiple pages, include the information from the following pages. Include a list of all the units, values, etc. in this form:\n parameter1 = value1\n parameter2 = value2"
    )

    @field_validator("page_number")
    @classmethod
    def validate_page_number(cls, v):
        """Ensures page number is positive."""
        if v < 0:
            raise ValueError("Page number must be positive")
        return v


class Section(DocumentItem):
    """A section of the specification document with hierarchical relationships."""

    title: str = Field(
        description="section's heading or chart/figure/table's heading/label. DO NOT INCLUDE TABLE OF CONTENTS ITEMS."
    )
    starts: bool = Field(
        default=False,
        description="boolean representing whether this section starts on the current page or is a continuation. If the whole section (or subsection) is on this page, this should be true. Even if it's a subsection of another section",
    )
    page_number_last: int = Field(
        default=0,
        description="Page number that the section ends, it could be the same page it starts on",
    )
    related_required: List["Section"] = Field(
        default_factory=list,
        description="List of sections that are required prerequisites",
    )
    related_context: List["Section"] = Field(
        default_factory=list,
        description="List of sections that provide helpful context",
    )
    subsection_of: Optional[str] = Field(
        None, description="Title of the parent section if this is a subsection"
    )

    important_values: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "A structured representation of the section's critical numerical specifications, "
            "operational requirements, and parameters. This includes but is not limited to: "
            "temperature ranges, time durations, physical measurements, counts, rates, "
            "frequencies, and performance thresholds. Each value should be stored with its "
            "units, applicable constraints (minimum/maximum/target), and any associated "
            "operational or testing requirements. Values should be organized in nested "
            "dictionaries by category (e.g., 'temperatureRange', 'cycleTesting', etc.) "
            "with clear hierarchical relationships between related specifications."
        ),
    )

    def to_json(self, visited: Optional[set] = None) -> dict:
        """Convert section to a JSON-serializable dict, handling circular references."""
        if visited is None:
            visited = set()

        if id(self) in visited:
            return {
                "type": "section_reference",
                "title": self.title,
                "page_number": self.page_number,
                "page_number_last": self.page_number_last,
            }

        visited.add(id(self))

        return {
            "type": "section",
            "page_number": self.page_number,
            "page_number_last": self.page_number_last,
            "title": self.title,
            "content": self.content,
            "starts": self.starts,
            "important_values": self.important_values,
            "related_required": [s.to_json(visited) for s in self.related_required],
            "related_context": [s.to_json(visited) for s in self.related_context],
        }

    @classmethod
    def from_json(
        cls, data: dict, sections_map: Optional[Dict[tuple, "Section"]] = None
    ) -> "Section":
        """Create a Section from a JSON-serializable dict, handling circular references."""
        if sections_map is None:
            sections_map = {}

        if data["type"] == "section_reference":
            key = (data["page_number"], data["title"])
            return sections_map[key]

        key = (data["page_number"], data["title"])
        section = cls(
            page_number=data["page_number"],
            page_number_last=data["page_number_last"],
            title=data["title"],
            content=data["content"],
            starts=data["starts"],
            important_values=data.get("important_values", {}),
            related_required=[],
            related_context=[],
        )
        sections_map[key] = section

        section.related_required = [
            cls.from_json(s, sections_map) for s in data["related_required"]
        ]
        section.related_context = [
            cls.from_json(s, sections_map) for s in data["related_context"]
        ]

        return section

    def model_dump(self, **kwargs):
        """Convert model to dictionary."""
        return self.model_dump_json(**kwargs)

    def __hash__(self):
        """Make Section hashable based on page number and title."""
        return hash((self.page_number, self.title))

    def __eq__(self, other):
        """Define equality based on page number and title."""
        if not isinstance(other, Section):
            return False
        return (self.page_number, self.title) == (other.page_number, other.title)


class TableOfContents(BaseModel):
    """Represents an entry in the table of contents."""

    title: str = Field(description="Title of the entry")
    section: str = Field(description="Section name or number")
    page: str = Field(description="Page reference")


class TableOfContentsResponse(BaseModel):
    """Response containing a list of table of contents entries."""

    entries: List[TableOfContents] = Field(
        description="List of sections in the table of contents"
    )


class Page(BaseModel):
    """Represents a single page in the document with its contents and metadata."""

    local_file: Path = Field(description="Path to the local file containing this page")
    sections: List[Section] = Field(
        description="List of sections appearing on this page"
    )
    table_of_contents: List[TableOfContents] = Field(
        description="Table of contents entries on this page"
    )
    summary: str = Field(description="Brief summary of the page content")
    page: int = Field(description="Page number")

    @field_validator("local_file", mode="before")
    @classmethod
    def convert_to_path(cls, v):
        """Convert string paths to Path objects."""
        if isinstance(v, str):
            return Path(v)
        return v

    @field_validator("sections")
    @classmethod
    def validate_section_order(cls, v):
        """Ensure sections are in ascending page number order."""
        if any(v[i].page_number > v[i + 1].page_number for i in range(len(v) - 1)):
            raise ValueError("Sections must be in page number order")
        return v

    def get_sections_starting_on_page(self) -> List[Section]:
        """Return list of sections that start on this page."""
        return [section for section in self.sections if section.starts]


class UnstructuredDocument(BaseModel):
    """Represents an entire document with its pages and structural information."""

    summary: str = Field(description="Overall document summary")
    pages: List[Page] = Field(description="List of pages in the document")

    def get_sections_in_document(self) -> List[Section]:
        """Return all sections that start in this document."""
        return [
            section
            for page in self.pages
            for section in page.get_sections_starting_on_page()
        ]

    def get_table_of_contents(self) -> List[TableOfContents]:
        """Return complete table of contents for the document."""
        return [toc for page in self.pages for toc in page.table_of_contents]


class SectionHolder(BaseModel):
    """Container for a section with an identifier."""

    id: int = Field(description="Unique identifier for this section holder")
    section: Section = Field(description="The section being held")


class ExcludedContentType(str, Enum):
    BIBLIOGRAPHY = "bibliography"
    APPENDIX = "appendix"
    INDEX = "index"
    SIGNATURE_BLOCK = "signature_block"
    TABLE_OF_CONTENTS = "table_of_contents"
    OUTLINE = "outline"
    TABLE_OF_TABLES = "table_of_tables"
    OTHER = "other"


class RelatedSection(BaseModel):
    title: str = Field(description="The title of the section")
    section_id: int = Field(description="The number of the section", default=-1)
    justification: str = Field(description="The justification for the section")


class SectionRelations(BaseModel):
    section_id: int = Field(description="The unique identifier for the section")
    section_title: str = Field(description="The title for the section")
    required: List[RelatedSection] = Field(default_factory=list)
    context: List[RelatedSection] = Field(default_factory=list)


class RelatedSectionsResponse(BaseModel):
    sections: List[SectionRelations]


class ExcludedContent(BaseModel):
    title: str = Field(description="Content that was excluded")
    reason: str = Field(description="Why this content was not included as a section")
    type: Optional[ExcludedContentType]
    subsection_of: Optional[str] = Field(
        None,
        description="Title of the parent section if this excluded content was a subsection",
    )


# All the sections on a page
class PageContent(BaseModel):
    summary: str = Field(
        description="A summary of the entire page with SPECIFIC details about implementation"
    )
    table_of_contents: Optional[List[TableOfContents]] = Field(default_factory=list)
    sections: Optional[List[Section]] = Field(default_factory=list)
    not_included: Optional[List[ExcludedContent]] = Field(default_factory=list)
