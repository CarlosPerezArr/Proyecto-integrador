from typing import Callable, Coroutine, Any
from structlog import get_logger

logger = get_logger()


class TaskGroupErrorHandler:
    """Helper class to manage error handling within TaskGroup contexts"""

    def __init__(self):
        self.errors = []
        self.logger = get_logger()

    async def run_with_error_handling(
        self,
        coro: Coroutine,
        error_handler: Callable[[Exception], Any] | None = None,
        task_name: str | None = None,
    ):
        """
        Runs a coroutine with error handling inside a TaskGroup

        Args:
            coro: The coroutine to execute
            error_handler: Optional custom error handler function
            task_name: Optional name for logging purposes
        """
        try:
            result = await coro
            return result
        except Exception as e:
            logger.error(str(e), exc_info=True)
            self.errors.append(e)
            self.logger.error(f"Task {task_name or 'unnamed'} failed: {str(e)}")
            if error_handler:
                return error_handler(e)
            raise
