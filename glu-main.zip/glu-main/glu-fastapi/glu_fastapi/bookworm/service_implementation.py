# take the call from the other service
# create out unstructured document model
# save files to S3
# save files to DB
# take unstructured doc and get the features to test
# find related sections for each

from langchain.chat_models.base import BaseChatModel
from langchain.embeddings.base import Embeddings
import aioboto3
from fastapi import WebSocket, status
from pathlib import Path
import aiofiles
from .services import Page
from glu_fastapi.auth import User
from glu_fastapi.config import Settings
from structlog import get_logger
from glu_fastapi.under_test.models import (
    DeviceSpecPage,
    DeviceSpec,
)
import json

from pypdfium2 import PdfDocument
import asyncio
from .models import UnstructuredDocument, Section, TableOfContents, SectionHolder
from .models_implementation import FeatureDocument, Feature
from .task_group_error_handler import TaskGroupErrorHandler

from glu_fastapi.websocket_utils import ServerEvent, ServerEventType

from glu_fastapi.websocket_utils import SocketResponse

from .service_testplan import CreateTestPlanService


from typing import List


import structlog
from sqlmodel import Session, select

from glu_fastapi.exceptions import NotFoundException
from glu_fastapi.under_test.models import (
    FunctionSpec,
    DeviceSpecTocEntry,
)

logger = structlog.get_logger()

# Import Session from sqlalchemy.orm

logger = get_logger()


class DocumentProcessedEvent(ServerEvent):
    event_type: ServerEventType = ServerEventType.document_processed
    devicespec_id: int


class PageProcessedEvent(ServerEvent):
    event_type: ServerEventType = ServerEventType.page_processed
    page_number: int
    page_count: int


class FeaturesExtractedEvent(ServerEvent):
    event_type: ServerEventType = ServerEventType.features_extracted


class FeatureExtractedEvent(ServerEvent):
    event_type: ServerEventType = ServerEventType.feature_extracted
    current_window: int
    window_count: int


class ImplBookwormService(CreateTestPlanService):
    def __init__(
        self,
        current_user: User,
        boto_session: aioboto3.Session,
        llm_client: BaseChatModel,
        settings: Settings,
        websocket: WebSocket,
        spec: DeviceSpec,
        session: Session,  # Add session parameter
        max_concurrency: int = 40,
        s3_client=None,
        file_handler=None,
        pdf_handler=None,
        embedding_client: Embeddings = None,
    ):
        self.current_user: User = current_user
        self.boto_session: aioboto3.Session = boto_session
        self.llm_client: BaseChatModel = llm_client
        self.settings: Settings = settings
        self.websocket: WebSocket = websocket
        self.spec: DeviceSpec = spec
        self.session: Session = session  # Store the session
        self._s3_path_root = f"{self.current_user.org_id}/device_specs/{spec.id}"
        self._limiter = asyncio.Semaphore(max_concurrency)
        self.s3_client = s3_client
        self.file_handler = file_handler or aiofiles
        self.pdf_handler = pdf_handler or PdfDocument
        self.embedding_client: Embeddings = embedding_client

    section_feature_pagination = 5
    error_handler = TaskGroupErrorHandler()

    async def parse_pdf(
        self, data: bytes, document: FeatureDocument = None
    ) -> DeviceSpec:
        if document is None:
            document = FeatureDocument(pages=[], summary="")

        # these can be done in parallel
        async with asyncio.TaskGroup() as tg:
            logger.debug("Saving doc to S3")
            tg.create_task(self.save_doc_to_s3(data))

            logger.debug("Starting to parse document")
            parse_task = tg.create_task(self.process_bytes(data))

        document = parse_task.result()

        await self.save_document_to_spec(document=document)

        return self.spec

    async def save_document_to_spec(self, document: FeatureDocument) -> None:

        def toc_handle_error(e: Exception):
            raise e

        def extract_handle_error(e: Exception):
            raise e

        # these can be done in parallel
        async with asyncio.TaskGroup() as tg:
            tg.create_task(
                self.error_handler.run_with_error_handling(
                    self.save_document_toc(document=document),
                    error_handler=toc_handle_error,
                    task_name="Save Document TOC",
                )
            )
            features_task = tg.create_task(
                self.error_handler.run_with_error_handling(
                    self.extract_features(document=document),
                    error_handler=extract_handle_error,
                    task_name="Extract Document Features",
                )
            )

        features = features_task.result()
        await self.save_features_to_function_specs(features)
        await self._send_websocket(server_event=FeaturesExtractedEvent())

        self.session.flush()  # Flush the session to persist changes

    async def save_document_toc(self, document: UnstructuredDocument) -> None:
        for page in document.pages:
            for entry in page.table_of_contents:

                target_page_num = None
                try:
                    target_page_num = int(entry.page)
                except IndexError:
                    logger.warn(
                        "There was no page number.",
                        intermediate_entry=entry.page,
                    )
                    target_page_num = None
                except ValueError:
                    logger.warn(
                        "Tried to parse a target page number, but failed.",
                        page_num=page.page,
                        supposed_target_page_num=entry.page,
                    )

                toc_entry = DeviceSpecTocEntry(
                    section_title=entry.title,
                    section_number=entry.section,
                    section_page_number=target_page_num,
                    toc_page_number=page.page,
                    device_spec=self.spec,
                )
                self.session.add(toc_entry)  # Add to session
                self.spec.table_of_contents.append(toc_entry)

    async def _get_content_embeddings(self, content: str) -> List[float]:

        # TODO: use a generic embeddings agent, do dynamic injection like w/ LLM client
        # While we're at it, store embeddings on the headers so we can do semantic search against them later.
        list_of_embeddings = await self.embedding_client.aembed_documents(
            texts=[content]
        )
        if len(list_of_embeddings) < 1:
            return None

        if len(list_of_embeddings) > 1:
            logger.warn("More than one embedding, what?!")

        logger.debug(
            "We got content embeddings",
            file=self.spec.filename,
            content=content,
        )
        return list_of_embeddings[0]

    async def extract_features(self, document: FeatureDocument) -> List["Feature"]:
        """Ask the LLM to identify features for testing, and save the answers."""

        sections = document.get_sections_in_document()
        return await self.parse_sections_for_features(
            sections=sections, table_of_contents=document.get_table_of_contents()
        )

    async def parse_sections_for_features(
        self,
        sections: List["Section"],
        table_of_contents: List["TableOfContents"] = [],
        existing_features: List["Feature"] = [],
    ) -> List["Feature"]:
        if len(sections) == 0:
            return []

        def feature_handle_error(e: Exception):
            raise e

        def split_array(arr, max_length):
            if len(arr) <= max_length:
                return [arr]

            mid = len(arr) // 2
            left = arr[:mid]
            right = arr[mid:]

            return split_array(left, max_length) + split_array(right, max_length)

        count = 0
        max_length = 5 * self.section_feature_pagination
        sub_arrays = split_array(sections, max_length=max_length)
        window_count = max(len(sub_arrays), 1)

        async def get_features(sub_sections: List[Section]):
            nonlocal count
            sub_features = await self.parse_section_block_for_features(
                sections=sub_sections,
                table_of_contents=table_of_contents,
                existing_features=existing_features,
            )
            features.extend(sub_features)
            count += 1
            await self._send_websocket(
                FeatureExtractedEvent(current_window=count, window_count=window_count)
            )

        features = []

        async with asyncio.TaskGroup() as tg:
            for arr in sub_arrays:
                tg.create_task(
                    self.error_handler.run_with_error_handling(
                        get_features(sub_sections=arr),
                        error_handler=feature_handle_error,
                        task_name="Save Document TOC",
                    )
                )

        def merge_features(features: List[Feature]) -> List[Feature]:
            feature_dict: dict[int, Feature] = {}
            feature: Feature
            for feature in features:
                if feature.title in feature_dict:
                    # Merge attributes with existing feature
                    existing = feature_dict[feature.title]
                    existing.required_sections.extend(feature.required_sections)
                    existing.context_sections.extend(feature.context_sections)
                    # Remove duplicates from lists
                    new_required = list(set(existing.required_sections))
                    existing.required_sections.clear()
                    existing.required_sections.extend(new_required)
                    new_context = list(set(existing.context_sections))
                    existing.context_sections.clear()
                    existing.context_sections.extend(new_context)
                else:
                    feature_dict[feature.title] = feature

            return list(feature_dict.values())

        features = merge_features(features=features)

        return features

    async def parse_section_block_for_features(
        self,
        sections: List["Section"],
        table_of_contents: List["TableOfContents"] = [],
        existing_features: List["Feature"] = [],
    ) -> List["Feature"]:
        holders: List[SectionHolder] = []

        section: Section
        for i, section in enumerate(sections):
            holders.append(SectionHolder(id=i, section=section))

        created_features = []
        section_block = []
        section_size = self.section_feature_pagination

        count = 0

        p1 = -section_size
        p2 = section_size

        while p1 < len(holders):

            p1_real = max(0, p1)
            p2_real = min(p2, len(holders))

            section_block = holders[p1_real:p2_real]

            features = await self.get_test_features(
                sections=section_block,
                table_of_contents=table_of_contents,
                existing_features=existing_features,
            )
            created_features.extend(features)
            created_features = sorted(created_features)
            existing_features.extend(features)
            existing_features = sorted(existing_features)
            existing_features.sort(key=lambda x: x.title)
            p1 += section_size
            p2 += section_size
            count += 1

        created_features = sorted(created_features)
        return created_features

    async def save_features_to_function_specs(
        self, features: List["Feature"]
    ) -> List["FunctionSpec"]:
        # Fetch the DeviceSpec to ensure it exists
        device_spec = self.session.exec(
            select(DeviceSpec).where(DeviceSpec.id == self.spec.id)
        ).one_or_none()
        if device_spec is None:
            raise NotFoundException(f"No such DeviceSpec(id=#{self.spec.id}).")

        created_function_specs = []
        features = sorted(features)

        for feature in features:
            function_spec = FunctionSpec(
                name=feature.title.strip(),
                # we will use this if we can't overload the original_text field with JSON, which is my preferred method for now
                # original_text = get_full_text_function_from_sections(feature)
                original_text=json.dumps(feature.to_json()),
                device_spec_id=self.spec.id,
            )
            created_function_specs.append(function_spec)
            self.session.add(function_spec)

        return created_function_specs

    # we will use this if we can't overload the original_text field with JSON, which is my preferred method for now
    # def get_full_text_function_from_sections(feature: Feature) -> str:
    #     string = ""
    #     if(feature.required_sections.count > 0):
    #         string = string + "#Required Sections:\nThese sections were identified as required to define this feature test.\n"
    #         for section in feature.required_sections:
    #             string = string + f"\n##{section.title}\n{section.content}\n"
    #     if(feature.context_sections.count > 0):
    #         string = string + "#Context Sections:\nThese sections were identified as useful, but not required, context for this feature test.\n"
    #         for section in feature.context_sections:
    #             string = string + f"\n##{section.title}\n{section.content}\n"

    #     return string

    async def save_doc_to_s3(self, data: bytes):
        s3_path = self.s3_path_for_specfile()

        async with self.boto_session.client("s3") as s3:
            await s3.put_object(
                Body=data,
                Bucket=self.settings.glu_bucket,
                Key=s3_path,
                ContentType="application/pdf",
            )

        s3_url = f"s3://{self.settings.glu_bucket}/{s3_path}"
        self.spec.s3_key = s3_url
        logger.debug("Uploaded the complete spec to S3", where_its_at=s3_url)
        self.session.add(self.spec)  # Add spec to session if not already
        self.session.flush()  # Flush the session to persist changes

    def s3_path_for_specfile(self) -> str:
        s3_path = f"{self._s3_path_root}/{self.spec.filename}"
        logger.debug("Calculated s3 path for spec", s3_path=s3_path)
        return s3_path

    async def pass_parse_pages(self, page_paths: List[Path]) -> List[Page]:
        await self._send_websocket(
            server_event=PageProcessedEvent(page_number=0, page_count=len(page_paths))
        )
        return await super().pass_parse_pages(page_paths=page_paths)

    async def pass_parse_page(self, page_paths: List[Path], page_num: int) -> Page:
        page = await super().pass_parse_page(page_paths=page_paths, page_num=page_num)

        async with asyncio.TaskGroup() as tg:

            s3_task = tg.create_task(
                self._save_to_s3(page_num=page.page, path=page.local_file)
            )

            sections = "\n\n".join(
                f"{section.title}\n{section.content}"
                for section in page.get_sections_starting_on_page()
            )
            embeddings_task = tg.create_task(
                self._get_content_embeddings(content=sections)
            )

        # Get needed results after all complete
        s3_url = s3_task.result()
        embeddings = embeddings_task.result()

        await self._send_websocket(
            server_event=PageProcessedEvent(
                page_number=page_num, page_count=len(page_paths)
            )
        )

        db_page = DeviceSpecPage(
            device_spec=self.spec,
            page_number=page_num,
            s3_key=s3_url,
            heading_embeddings=embeddings,
        )

        self.session.add(db_page)  # Add to session

        await self._send_websocket(
            server_event=PageProcessedEvent(
                page_number=page_num, page_count=len(page_paths)
            )
        )
        return page

    async def _save_to_s3(self, page_num: int, path: Path) -> str:

        # save page file to S3
        s3_path = self.s3_path_for_page(page_num)
        s3_url = f"s3://{self.settings.glu_bucket}/{s3_path}"
        await self._upload_page_to_s3(path, s3_path)

        return s3_url

    def s3_path_for_page(self, page_num: int) -> str:
        s3_path = f"{self._s3_path_root}/pages/{page_num}.jpg"
        logger.debug("Calculated s3 path for page in spec", s3_path=s3_path)
        return s3_path

    async def _upload_page_to_s3(self, file_path: Path, s3_path: str):
        # Upload to S3; keep handle
        if self.boto_session is None:
            return

        async with self.boto_session.client("s3") as s3:
            async with aiofiles.open(file_path, "rb") as image_of_page:
                await s3.upload_fileobj(
                    image_of_page, self.settings.glu_bucket, s3_path
                )

    async def _send_websocket(self, server_event: ServerEvent):
        if self.websocket is not None:
            await self.websocket.send_text(
                SocketResponse(
                    is_error=False,
                    code=status.HTTP_200_OK,
                    payload=server_event.model_dump(),
                ).model_dump_json()
            )
