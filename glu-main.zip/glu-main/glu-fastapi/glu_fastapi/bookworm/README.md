# BookwormService Documentation

## Overview

The BookwormService is a core component of our document processing system, designed to handle PDF documents containing device specifications. This service has been refactored to improve testability and maintainability.

## Class Structure

The `BookwormService` class has been refactored to use dependency injection and smaller, more focused methods. Here's an overview of its structure:

### Public Methods

- `__init__(self, current_user, boto_session, openai_client, settings, websocket, spec, function_spec_service, max_concurrency=10, s3_client=None, file_handler=None, pdf_handler=None, embeddings_service=None)`: Initializes the service with necessary dependencies.
- `process_bytes(self, data: bytes) -> DeviceSpec`: Processes raw PDF data.
- `process_pdf(self, pdf: PdfDocument, spec: DeviceSpec)`: Handles the PDF processing workflow.
- `save_doc_to_s3(self, data: bytes)`: Saves the document to S3 storage.
- `s3_path_for_specfile(self) -> str`: Generates the S3 path for the specification file.
- `s3_path_for_page(self, page_num: int) -> str`: Generates the S3 path for a specific page.
- `process_page(self, spec: DeviceSpec, page_images_go_here: str, page_num: int, num_pages: int, page: PdfPage) -> DeviceSpecPage`: Processes an individual page of the PDF.

### Protected Methods

- `_create_s3_client(self)`: Creates an S3 client.
- `_extract_and_save_function_specs(self)`: Extracts and saves function specifications.
- `_ask_llm_about_page(self, page_on_disk: Path, prompt: str) -> List[str]`: Interacts with the language model to analyze a page.
- `_encode_image(self, image_path: Path) -> str`: Encodes an image to base64.

## Usage Example
python
from services import BookwormService

# Initialize dependencies (user, boto_session, openai_client, settings, websocket, spec, function_spec_service)

service = BookwormService(user, boto_session, openai_client, settings, websocket, spec, function_spec_service)

# Process a PDF file
with open('document.pdf', 'rb') as pdf_file:
    pdf_data = pdf_file.read()
    processed_spec = await service.process_bytes(pdf_data)

# The processed_spec object now contains the extracted information
```

## Testing

The BookwormService now has comprehensive unit and integration tests.

### Running Unit Tests

To run the unit tests:

```
pytest tests/test_bookworm_service.py
```

These tests cover individual methods of the BookwormService class, using mocks to isolate the functionality being tested.

### Running Integration Tests

To run the integration tests:

```
pytest tests/test_bookworm_service_integration.py
```

These tests cover the interaction between different components of the BookwormService, including PDF processing, S3 interactions, OpenAI API calls, and WebSocket communications.

### Test Setup

Both unit and integration tests use pytest fixtures to set up mock objects for dependencies such as the user, AWS Boto session, OpenAI client, and WebSocket connection. These fixtures are defined in the respective test files.

For example, to mock the S3 client in a test:

```python
@pytest.fixture
def mock_s3_client():
    return AsyncMock()

@pytest.mark.asyncio
async def test_save_doc_to_s3(bookworm_service, mock_s3_client):
    bookworm_service.s3_client = mock_s3_client
    await bookworm_service.save_doc_to_s3(b'test data')
    mock_s3_client.put_object.assert_called_once()
```

This approach allows for isolated testing of the BookwormService's methods without relying on external services.

## Conclusion

The refactored BookwormService provides a more modular and testable structure for processing PDF documents. By using dependency injection and breaking down complex methods, we've improved the maintainability and reliability of the service. The comprehensive test suite ensures that changes to the service can be made with confidence, knowing that both individual components and their interactions are thoroughly tested.
