from typing import List
from pathlib import Path
import os
import aiofiles
from ..models import Page, Section

from ..models import SectionHolder


def get_elroy_name() -> str:
    return "elroy_mini_6E.pdf"


def get_complex_name() -> str:
    return "Complex Test Spec.pdf"


def get_9500C_name() -> str:
    return "SRS-9500C.pdf"


async def get_complex_test_doc() -> bytes:
    return await _get_pdf_file(get_complex_name())


async def get_elroy_spec_doc() -> bytes:
    return await _get_pdf_file(get_elroy_name())


async def get_9500C_spec_doc() -> bytes:
    return await _get_pdf_file(get_9500C_name())


async def _get_pdf_file(file_name: str) -> bytes:
    current_dir = os.path.dirname(__file__)
    relative_path = os.path.join(current_dir, "pdfs", file_name)

    async with aiofiles.open(relative_path, "rb") as pdf_file:
        pdf_data = await pdf_file.read()

    return pdf_data


def get_complex_test_pages() -> List[Path]:
    current_dir = os.path.dirname(__file__)
    relative_path = Path(current_dir) / "pages"
    paths = relative_path.glob("Complex Test Spec_*.jpeg")
    return sorted(paths, key=lambda p: int(p.stem.split("_")[-1]))


def get_elroy_test_pages() -> List[Path]:
    current_dir = os.path.dirname(__file__)
    relative_path = Path(current_dir) / "pages"
    paths = relative_path.glob("elroy_mini_6E_*.jpeg")
    return sorted(paths, key=lambda p: int(p.stem.split("_")[-1]))


def get_9500C_test_pages() -> List[Path]:
    current_dir = os.path.dirname(__file__)
    relative_path = Path(current_dir) / "pages"
    paths = relative_path.glob("SRS-9500C_*.jpeg")
    return sorted(paths, key=lambda p: int(p.stem.split("_")[-1]))


def get_toc_and_sections(pages: List[Page]):
    # Combine sections from all pages
    sections_that_start = []
    for result in pages:
        sections_that_start.extend(result.get_sections_starting_on_page())

    table_of_contents = []
    for result in pages:
        table_of_contents.extend(result.table_of_contents)

    return table_of_contents, sections_that_start


def get_section_holders(sections: List[Section]) -> List[SectionHolder]:
    result: List[SectionHolder] = []
    for i, section in enumerate(sections):
        result.append(SectionHolder(id=i, section=section))
    return result


# Utility function to clear caches for specific test cases
async def clear_test_cache(cached_page, service, paths, page_numbers):
    """
    Clear cache for specific page numbers before running tests
    """
    for page_num in page_numbers:
        await cached_page(page_num, service, paths, clear=True)
