import pytest


from ..services import BookwormService
from .common import (
    get_9500C_test_pages,
    get_complex_test_pages,
    get_elroy_test_pages,
    get_toc_and_sections,
    get_elroy_name,
)

from ..models import UnstructuredDocument
import asyncio


"""
@pytest.mark.asyncio
async def test_unstructured_document():

    # Test data
    current_dir = os.path.dirname(__file__)
    relative_path = os.path.join(current_dir, "pdfs", "elroy_mini_6E.pdf")

    async with aiofiles.open(relative_path, "rb") as pdf_file:
        pdf_data = await pdf_file.read()

    # Call the method
    result = await service.process_bytes(pdf_data)
"""

# TODO make sure that some of the text values coming back are correct. E.g. that titles have the correct names.


@pytest.mark.asyncio
async def test_section_get_section_full_page_title_one_page(
    bookworm_service: BookwormService,
):
    # Test data
    paths = get_elroy_test_pages()
    print(paths[23])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 23)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    # This can either come back as one item (all combined, so check for "comment"),
    # two items (combined header + test details, comments) or three (separate).
    # Both are technically correct depending on how it was parsed by the LLM
    assert start_count in [2, 3] or (
        start_count == 1 and sections[0].content.lower().index("comment") > -1
    )
    assert continue_count == 0


@pytest.mark.asyncio
async def test_section_get_section_full_page_title_span_2_pages(
    bookworm_service: BookwormService,
):
    # Test data
    paths = get_elroy_test_pages()
    print(paths[19])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 19)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count in [1, 2]
    assert continue_count == 0


@pytest.mark.asyncio
async def test_section_ignore_table_of_contents_page(bookworm_service: BookwormService):

    # Test data
    paths = get_elroy_test_pages()
    print(paths[0])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 0)
    sections = result.sections
    assert len(sections) == 0


@pytest.mark.asyncio
async def test_section_verify_table_of_contents(bookworm_service: BookwormService):

    # Test data
    paths = get_elroy_test_pages()
    print(paths[0])

    # Call the method
    result = await bookworm_service.pass_parse_page(paths, 0)

    assert len(result.table_of_contents) == 19


@pytest.mark.asyncio
async def test_section_count_multiple_sections_and_diagrams(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_9500C_test_pages()

    # Call the method
    result = await bookworm_service.pass_parse_pages(paths[13:20])
    split = get_toc_and_sections(result)
    # toc = split[0]
    sections = split[1]

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count in [12, 13, 14, 15]
    assert continue_count == 0


@pytest.mark.asyncio
async def test_section_count_multiple_sections(bookworm_service: BookwormService):

    # Test data
    paths = get_complex_test_pages()

    # Call the method
    result = await bookworm_service.pass_parse_pages(paths[15:18])
    split = get_toc_and_sections(result)
    # toc = split[0]
    sections = split[1]

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count in [7]
    assert continue_count == 0


@pytest.mark.asyncio
async def test_table_of_contents_different_headers_fonts(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_9500C_test_pages()
    print(paths[5])

    # Call the method
    result1 = await bookworm_service.pass_parse_page_toc(paths[5])

    assert len(result1) > 0
    assert len(result1) == 36


@pytest.mark.asyncio
async def test_section_count_two_images(bookworm_service: BookwormService):

    # Test data
    paths = get_9500C_test_pages()
    print(paths[12])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 12)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count == 2
    assert continue_count == 0


@pytest.mark.asyncio
async def test_section_count_one_diagram(bookworm_service: BookwormService):

    # Test data
    paths = get_9500C_test_pages()
    print(paths[15])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 15)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count == 1
    assert continue_count == 0


@pytest.mark.asyncio
async def test_section_count_table_of_contents(bookworm_service: BookwormService):

    # Test data
    paths = get_complex_test_pages()

    # Call the method
    result = await bookworm_service.pass_parse_pages(paths[0:5])
    split = get_toc_and_sections(result)
    # toc = split[0]
    sections = split[1]

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count in [5, 6]
    assert continue_count == 0


@pytest.mark.asyncio
async def test_section_count_table_only_continued(bookworm_service: BookwormService):

    # Test data
    paths = get_complex_test_pages()
    print(paths[9])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 9)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count == 1
    assert continue_count == 0


@pytest.mark.asyncio
async def test_section_count_table_only_previous_continue(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_complex_test_pages()
    print(paths[10])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 10)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count == 0
    assert continue_count == 1


@pytest.mark.asyncio
async def test_section_count_multiple_items_extra_header_no_continue(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_complex_test_pages()
    print(paths[5])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 5)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count == 9


@pytest.mark.asyncio
async def test_section_count_multiple_items_and_previous_continue(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_complex_test_pages()
    print(paths[6])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 6)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count == 4


@pytest.mark.asyncio
async def test_section_count_jira_item(bookworm_service: BookwormService):

    # Test data
    paths = get_elroy_test_pages()
    print(paths[1])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 1)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count == 1
    assert continue_count == 0


@pytest.mark.asyncio
async def test_section_count_jira_has_continue(bookworm_service: BookwormService):

    # Test data
    paths = get_elroy_test_pages()
    print(paths[7])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 7)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    # This can either come back as one item (combined header + test details) or two (separate) so accept both.
    # Both are technically correct depending on how it was parsed by the LLM
    assert start_count in [1, 2]
    assert continue_count == 0


@pytest.mark.asyncio
async def test_section_count_jira_continued(bookworm_service: BookwormService):

    # Test data
    paths = get_elroy_test_pages()
    print(paths[8])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 8)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count == 1


@pytest.mark.asyncio
async def test_section_count_multiple_no_previous_continue(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_complex_test_pages()
    print(paths[16])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 16)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count == 4
    assert continue_count == 0


@pytest.mark.asyncio
async def test_section_count_one_item_no_continue(bookworm_service: BookwormService):

    # Test data
    paths = get_complex_test_pages()
    print(paths[13])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 13)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count == 1
    assert continue_count == 0


@pytest.mark.asyncio
async def test_section_count_end_of_doc_and_previous_section_continue(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_complex_test_pages()
    print(paths[25])

    # Call the method
    result = await bookworm_service.pass_parse_page_sections(paths, 25)
    sections = result.sections

    start_count = 0
    continue_count = 0
    for section in sections:
        if section.starts:
            start_count += 1
        else:
            continue_count += 1

    assert start_count == 1
    assert continue_count == 1


@pytest.mark.asyncio
async def test_table_of_contents_length_first_page_toc(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_complex_test_pages()
    print(paths[2])

    # Call the method
    result1 = await bookworm_service.pass_parse_page_toc(paths[2])

    assert len(result1) > 0
    assert len(result1) == 42


@pytest.mark.asyncio
async def test_table_of_contents_length_first_page_toc_multiple(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_complex_test_pages()
    print(paths[2])

    # Call the method
    result1 = await bookworm_service.pass_parse_page(page_paths=paths, page_num=2)

    assert len(result1.table_of_contents) > 0
    assert len(result1.table_of_contents) == 42


@pytest.mark.asyncio
async def test_table_of_contents_length_second_page_toc(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_complex_test_pages()
    print(paths[3])

    result2 = await bookworm_service.pass_parse_page_toc(paths[3])

    assert len(result2) > 0
    assert len(result2) == 48


@pytest.mark.asyncio
async def test_table_of_contents_length_second_page_toc_multiple(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_complex_test_pages()
    print(paths[3])

    # Call the method
    result1 = await bookworm_service.pass_parse_page(page_paths=paths, page_num=3)

    assert len(result1.table_of_contents) > 0
    assert len(result1.table_of_contents) == 48


@pytest.mark.asyncio
async def test_table_of_contents_length_generated_toc(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_elroy_test_pages()
    print(paths[0])

    result2 = await bookworm_service.pass_parse_page_toc(paths[0])

    assert len(result2) > 0
    assert len(result2) == 19


@pytest.mark.asyncio
async def test_table_of_contents_multi_page_one_toc_page(
    bookworm_service: BookwormService,
):

    # Test data
    paths = get_elroy_test_pages()
    print(paths[0])

    # Call the method
    pages = await bookworm_service.pass_parse_pages(paths[0:5])
    result = get_toc_and_sections(pages=pages)
    assert len(result[0]) == 19


@pytest.mark.asyncio
async def test_table_of_contents_none(bookworm_service: BookwormService):

    # Test data
    paths = get_complex_test_pages()
    print(paths[0])

    # Call the method
    result = await bookworm_service.pass_parse_page_toc(paths[0])
    assert len(result) == 0


@pytest.mark.asyncio
async def test_table_of_contents_multi_page_none(bookworm_service: BookwormService):

    # Test data
    paths = get_elroy_test_pages()
    print(paths[0])

    # Call the method
    pages = await bookworm_service.pass_parse_pages(paths[1:14])
    result = get_toc_and_sections(pages=pages)
    assert len(result[0]) == 0


@pytest.mark.asyncio
async def test_sections_get_related_elroy(
    bookworm_service: BookwormService, cached_page
):

    paths = get_elroy_test_pages()

    # Fetch all pages in parallel using cached results
    page_results = await asyncio.gather(
        *[
            cached_page(i, get_elroy_name(), bookworm_service, paths)
            for i in range(0, 30)
        ]
    )

    document = UnstructuredDocument(summary="", pages=page_results)

    results = await bookworm_service.add_related_sections(document=document)

    assert len(results) in [
        len(document.get_sections_in_document()),
        len(document.get_sections_in_document()) - 1,
    ]


@pytest.mark.asyncio
# async def test_sections_get_related_complex_spec(
#     bookworm_service: BookwormService, cached_page
# ):

#     paths = get_complex_test_pages()

#     # Fetch all pages in parallel using cached results
#     page_results = await asyncio.gather(
#         *[
#             cached_page(i, get_complex_name(), bookworm_service, paths)
#             for i in range(0, 69)
#         ]
#     )
#     document = UnstructuredDocument(summary="", pages=page_results)

#     results = await bookworm_service.add_related_sections(document=document)

#     assert len(results) == len(document.get_sections_in_document())


@pytest.mark.asyncio
async def test_sections_get_sections_from_complex_spec(
    bookworm_service: BookwormService, cached_page
):

    paths = get_complex_test_pages()

    page_results = await bookworm_service.pass_parse_pages(paths[11:14])

    document = UnstructuredDocument(summary="", pages=page_results)
    sections = document.get_sections_in_document()
    assert len(sections) == 6
