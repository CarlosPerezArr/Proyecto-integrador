import pytest
from typing import Union
import aioboto3
from glu_fastapi.config import Settings
from glu_fastapi.auth import User
from sqlalchemy.orm import Session
from glu_fastapi.under_test.models import DeviceSpec
from ..service_implementation import ImplBookwormService
from langchain.chat_models.base import BaseChatModel
from langchain_core.embeddings import Embeddings

from tests.test_api import get_testing_user

glu_settings = Settings()


class MockSession:
    def __init__(self):
        self._added = []

    def add(self, obj):
        self._added.append(obj)

    def flush(self):
        pass

    def commit(self):
        pass


class MockChatCompletion:
    def __init__(self):
        self.choices = [MockChoice()]


class MockChoice:
    def __init__(self):
        self.message = MockMessage()


class MockMessage:
    def __init__(self):
        self.content = "Mock response"


@pytest.fixture
def mock_session():
    return MockSession()


def get_test_service(
    device_spec: DeviceSpec = None,
    session: Union[Session, None] = None,
    user: User = None,
    llm_client: Union[BaseChatModel, None] = None,
    boto_session: Union[aioboto3.Session, None] = None,
    settings: Union[Settings, None] = None,
    websocket=None,
    embedding_client: Union[Embeddings, None] = None,
) -> ImplBookwormService:
    """
    Creates a test service with flexible dependency injection.

    Args:
        session: Real SQLAlchemy session or mock session
        user: Real User object or mock user
        openai_client: Real OpenAI client or mock
        boto_session: Real boto3 session or mock
        settings: Real settings or mock settings
        websocket: Real websocket or mock
        spec: Real DeviceSpec or mock
    """

    return ImplBookwormService(
        current_user=user or get_testing_user(),
        boto_session=boto_session or None,
        llm_client=llm_client,
        settings=settings or glu_settings,  # Now using MockSettings as default
        websocket=websocket,
        spec=device_spec,  # Use global device_spec if none provided
        session=session,
        embedding_client=embedding_client,
    )
