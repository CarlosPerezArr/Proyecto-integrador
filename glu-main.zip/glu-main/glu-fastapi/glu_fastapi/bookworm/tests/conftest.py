# conftest.py
from dotenv import load_dotenv
import pickle
from pathlib import Path
import pytest

import os
import sys
import shutil

from ..services import BookwormService
from ..service_testplan import CreateTestPlanService
from langchain.chat_models.base import BaseChatModel
from langchain.embeddings.base import Embeddings
from glu_fastapi.external_services import get_llm_chat_service, get_embeddings_service
from .mocks import get_test_service
from tests.test_api import device_spec, testing_sqlsession, device_under_test  # noqa


from sqlmodel import Session
from glu_fastapi.under_test.models import (
    DeviceSpec,
)


def pytest_configure(config):
    print("Loading configuration")
    # Check if file exists, assumes you're at the glu level for your workspace
    if Path("glu-fastapi/.env").exists():
        print(".env file exists")
    else:
        print("No .env file, you'll want to fix that")
    """Load env variables before running tests"""
    load_dotenv("glu-fastapi/.env")

    """Create cache directory if it doesn't exist"""
    config.cache_dir = Path(".pytest_cache/pages")
    config.cache_dir.mkdir(parents=True, exist_ok=True)

    print(f"Current working directory: {os.getcwd()}")
    print(f"Env ENVIRONMENT: {os.getenv('ENVIRONMENT')}")
    print(f"Python path: {sys.path}")


def clear_all_cache():
    """Utility function to clear all page caches"""
    cache_dir = Path(".pytest_cache/pages")
    if cache_dir.exists():
        shutil.rmtree(cache_dir)
        cache_dir.mkdir(parents=True, exist_ok=True)


@pytest.fixture
def fresh_cache():
    """Fixture that ensures a clean cache before test"""
    clear_all_cache()
    yield


@pytest.fixture
def cached_page():
    """Fixture that provides cached page sections with page-level granularity"""

    async def _cached_page(
        page_number: int, file_name: str, service, paths, clear: bool = False
    ) -> dict:
        """
        Args:
            page_number: The specific page to cache
            service: TestPlanService instance
            paths: Path information for parsing
            clear: If True, clears this page's cache before computing
        """
        cache_file = (
            Path(".pytest_cache/pages") / f"{file_name}_page_{page_number}.pickle"
        )

        if clear and cache_file.exists():
            cache_file.unlink()  # noqa: ASYNC101

        if cache_file.exists():
            with open(cache_file, "rb") as f:  # noqa: ASYNC101
                return pickle.load(f)

        result = await service.pass_parse_page(paths, page_number)

        with open(cache_file, "wb") as f:  # noqa: ASYNC101
            pickle.dump(result, f)  # noqa: ASYNC101

        return result

    return _cached_page


# For testing, create an actual instance or mock
@pytest.fixture(scope="module")
def mock_llm() -> BaseChatModel:
    """Create a LLM for testing."""
    return get_llm_chat_service()


# For testing, create an actual instance or mock
@pytest.fixture(scope="module")
def mock_embeddings() -> Embeddings:
    """Create an embeddings for testing."""
    return get_embeddings_service()


@pytest.fixture(scope="function")
def bookworm_service(mock_llm: BaseChatModel) -> BookwormService:
    """Create BookwormService with mock LLM."""
    return BookwormService(llm_client=mock_llm)


@pytest.fixture(scope="function")
def create_test_plan_service(mock_llm: BaseChatModel) -> CreateTestPlanService:
    """Create BookwormService with mock LLM."""
    return CreateTestPlanService(llm_client=mock_llm)


@pytest.fixture(scope="function")
def impl_bookworm_service(
    mock_llm: BaseChatModel,
    device_spec: DeviceSpec,  # noqa
    testing_sqlsession: Session,  # noqa
    mock_embeddings: Embeddings,
):
    return get_test_service(
        device_spec=device_spec,
        session=testing_sqlsession,
        llm_client=mock_llm,
        embedding_client=mock_embeddings,
    )
