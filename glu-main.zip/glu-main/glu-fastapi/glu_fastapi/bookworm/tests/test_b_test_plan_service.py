import pytest
from ..service_testplan import CreateTestPlanService
from .common import (
    get_9500C_test_pages,
    get_complex_test_pages,
    get_complex_name,
    get_9500C_name,
    get_toc_and_sections,
    get_section_holders,
)

from glu_fastapi.external_services import LlmDependency
import asyncio


def get_test_plan_service() -> CreateTestPlanService:
    return CreateTestPlanService(LlmDependency())


@pytest.mark.asyncio
async def test_section_count_multiple_pages_with_multiple_sections(
    create_test_plan_service,
    cached_page,
):
    service = create_test_plan_service
    paths = get_complex_test_pages()

    # Fetch all pages in parallel using cached results
    page_results = await asyncio.gather(
        *[cached_page(i, get_complex_name(), service, paths) for i in range(11, 14)]
    )

    # get both toc and sections
    toc_and_sections = get_toc_and_sections(page_results)
    table_of_contents = toc_and_sections[0]
    sections_that_start = get_section_holders(sections=toc_and_sections[1])

    results = await service.get_test_features(
        sections=sections_that_start, table_of_contents=table_of_contents
    )

    assert len(results) in [6, 7, 8]


@pytest.mark.asyncio
async def test_section_count_multiple_pages_with_continuation_and_diagrams_images(
    create_test_plan_service,
    cached_page,
):
    service = create_test_plan_service
    paths = get_9500C_test_pages()

    # Fetch all pages in parallel using cached results
    page_results = await asyncio.gather(
        *[cached_page(i, get_9500C_name(), service, paths) for i in range(13, 20)]
    )

    # get both toc and sections
    toc_and_sections = get_toc_and_sections(page_results)
    table_of_contents = toc_and_sections[0]
    sections_that_start = get_section_holders(sections=toc_and_sections[1])

    results = await service.get_test_features(
        sections=sections_that_start, table_of_contents=table_of_contents
    )

    assert len(results) in [15, 16, 17, 18]


@pytest.mark.asyncio
async def test_section_count_multiple_pages_with_many_tests(
    create_test_plan_service,
    cached_page,
):
    service = create_test_plan_service
    paths = get_complex_test_pages()

    # Fetch all pages in parallel using asyncio.gather
    page_results = await asyncio.gather(
        *[cached_page(i, get_complex_name(), service, paths) for i in range(5, 10)]
    )

    # get both toc and sections
    toc_and_sections = get_toc_and_sections(page_results)
    table_of_contents = toc_and_sections[0]
    sections_that_start = get_section_holders(sections=toc_and_sections[1])

    results = await service.get_test_features(
        sections=sections_that_start, table_of_contents=table_of_contents
    )

    assert len(results) >= 9


@pytest.mark.asyncio
async def test_section_count_multiple_pages_with_continuation(
    create_test_plan_service,
    cached_page,
):
    service = create_test_plan_service
    paths = get_complex_test_pages()

    # Fetch all pages in parallel using cached results
    page_results = await asyncio.gather(
        *[cached_page(i, get_complex_name(), service, paths) for i in range(15, 18)]
    )

    # get both toc and sections
    toc_and_sections = get_toc_and_sections(page_results)
    table_of_contents = toc_and_sections[0]
    sections_that_start = get_section_holders(sections=toc_and_sections[1])

    results = await service.get_test_features(
        sections=sections_that_start, table_of_contents=table_of_contents
    )

    assert len(results) == 7


@pytest.mark.asyncio
async def test_section_count_multiple_items_extra_content_no_continue(
    create_test_plan_service,
    cached_page,
):
    service = create_test_plan_service
    paths = get_complex_test_pages()
    print(paths[5])

    # Single page fetch using cache
    page_results = await cached_page(5, get_complex_name(), service, paths)
    # get both toc and sections
    toc_and_sections = get_toc_and_sections([page_results])
    table_of_contents = toc_and_sections[0]
    sections_that_start = get_section_holders(sections=toc_and_sections[1])

    results = await service.get_test_features(
        sections=sections_that_start, table_of_contents=table_of_contents
    )

    assert len(results) >= 7


@pytest.mark.asyncio
async def test_section_count_one_item(
    create_test_plan_service,
    cached_page,
):
    service = create_test_plan_service
    paths = get_complex_test_pages()
    print(paths[13])

    # Single page fetch using cache
    page_results = await cached_page(13, get_complex_name(), service, paths)
    # get both toc and sections
    toc_and_sections = get_toc_and_sections([page_results])
    table_of_contents = toc_and_sections[0]
    sections_that_start = get_section_holders(sections=toc_and_sections[1])

    results = await service.get_test_features(
        sections=sections_that_start, table_of_contents=table_of_contents
    )

    # I would argue this can be broken down into multiple features, we need to make sure we have minimum 1
    assert len(results) == 4


@pytest.mark.asyncio
async def test_section_count_multiple_items_with_continuation(
    create_test_plan_service,
    cached_page,
):
    service = create_test_plan_service
    paths = get_complex_test_pages()
    print(paths[16])

    # Single page fetch using cache
    page_results = await cached_page(16, get_complex_name(), service, paths)
    # get both toc and sections
    toc_and_sections = get_toc_and_sections([page_results])
    table_of_contents = toc_and_sections[0]
    sections_that_start = get_section_holders(sections=toc_and_sections[1])

    results = await service.get_test_features(
        sections=sections_that_start, table_of_contents=table_of_contents
    )

    assert len(results) == 4
