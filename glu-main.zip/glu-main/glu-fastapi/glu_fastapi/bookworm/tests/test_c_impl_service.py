import pytest

import asyncio

from .common import (
    get_9500C_test_pages,
    get_elroy_test_pages,
    get_9500C_name,
    get_elroy_name,
    get_complex_name,
    get_complex_test_pages,
    get_toc_and_sections,
)
from structlog import get_logger


logger = get_logger()


@pytest.mark.asyncio
async def test_elroy_feature_list(cached_page, impl_bookworm_service):

    paths = get_elroy_test_pages()

    # Fetch all pages in parallel using cached results
    page_results = await asyncio.gather(
        *[
            cached_page(i, get_elroy_name(), impl_bookworm_service, paths)
            for i in range(0, 30)
        ]
    )

    # get both toc and sections
    toc_and_sections = get_toc_and_sections(page_results)
    table_of_contents = toc_and_sections[0]
    sections_that_start = toc_and_sections[1]

    results = await impl_bookworm_service.parse_sections_for_features(
        sections=sections_that_start,
        table_of_contents=table_of_contents,
        existing_features=[],
    )

    assert len(results) > 19


@pytest.mark.asyncio
async def test_complex_test_spec_toc_only(cached_page, impl_bookworm_service):
    paths = get_complex_test_pages()

    # Fetch all pages in parallel using cached results
    page_results = await asyncio.gather(
        *[
            cached_page(i, get_complex_name(), impl_bookworm_service, paths)
            for i in range(0, 5)
        ]
    )

    # get both toc and sections
    toc_and_sections = get_toc_and_sections(page_results)
    table_of_contents = toc_and_sections[0]
    sections_that_start = toc_and_sections[1]

    results = await impl_bookworm_service.parse_sections_for_features(
        sections=sections_that_start,
        table_of_contents=table_of_contents,
        existing_features=[],
    )

    assert len(results) == 0


@pytest.mark.asyncio
async def test_complex_test_spec_partial_feature_list(
    cached_page, impl_bookworm_service
):

    paths = get_complex_test_pages()

    # Fetch all pages in parallel using cached results
    page_results = await asyncio.gather(
        *[
            cached_page(i, get_complex_name(), impl_bookworm_service, paths)
            for i in range(0, 5)
        ]
    )

    page_results.extend(
        await asyncio.gather(
            *[
                cached_page(i, get_complex_name(), impl_bookworm_service, paths)
                for i in range(25, 35)
            ]
        )
    )

    # get both toc and sections
    toc_and_sections = get_toc_and_sections(page_results)
    table_of_contents = toc_and_sections[0]
    sections_that_start = toc_and_sections[1]

    results = await impl_bookworm_service.parse_sections_for_features(
        sections=sections_that_start,
        table_of_contents=table_of_contents,
        existing_features=[],
    )

    assert len(results) >= 17


@pytest.mark.asyncio
async def test_complex_test_spec_feature_list(cached_page, impl_bookworm_service):
    paths = get_complex_test_pages()

    # Fetch all pages in parallel using cached results
    page_results = await asyncio.gather(
        *[
            cached_page(i, get_complex_name(), impl_bookworm_service, paths)
            for i in range(0, 69)
        ]
    )

    # get both toc and sections
    toc_and_sections = get_toc_and_sections(page_results)
    table_of_contents = toc_and_sections[0]
    sections_that_start = toc_and_sections[1]

    results = await impl_bookworm_service.parse_sections_for_features(
        sections=sections_that_start,
        table_of_contents=table_of_contents,
        existing_features=[],
    )

    assert len(results) == 89


@pytest.mark.asyncio
async def test_elroy_feature_list_doubled_avoid_duplicates(
    cached_page, impl_bookworm_service
):
    paths = get_elroy_test_pages()

    # Fetch all pages in parallel using cached results
    page_results = await asyncio.gather(
        *[
            cached_page(i, get_elroy_name(), impl_bookworm_service, paths)
            for i in range(0, 30)
        ]
    )

    # get both toc and sections
    toc_and_sections = get_toc_and_sections(page_results)
    table_of_contents = toc_and_sections[0]
    sections_that_start = toc_and_sections[1]

    results = await impl_bookworm_service.parse_sections_for_features(
        sections=sections_that_start,
        table_of_contents=table_of_contents,
        existing_features=[],
    )
    # send the same values again, but let it know we've already done these through existing_features
    results.append(
        await impl_bookworm_service.parse_sections_for_features(
            sections=sections_that_start,
            table_of_contents=table_of_contents,
            existing_features=results,
        )
    )

    assert len(results) > 19
    assert len(results) < 26


@pytest.mark.asyncio
async def test_section_count_multiple_pages_with_continuation_and_diagrams_images(
    cached_page, impl_bookworm_service
):

    paths = get_9500C_test_pages()

    # Fetch all pages in parallel using cached results
    page_results = await asyncio.gather(
        *[
            cached_page(i, get_9500C_name(), impl_bookworm_service, paths)
            for i in range(13, 20)
        ]
    )

    # Combine sections from all pages
    # get both toc and sections
    toc_and_sections = get_toc_and_sections(page_results)
    table_of_contents = toc_and_sections[0]
    sections_that_start = toc_and_sections[1]

    results = await impl_bookworm_service.parse_sections_for_features(
        sections=sections_that_start,
        table_of_contents=table_of_contents,
        existing_features=[],
    )

    assert len(results) >= 14


@pytest.mark.asyncio
async def test_get_embeddings_normal(mock_embeddings):
    content = """
14.1 RUN1 Test
The UTR is required to have access to the “RUN1” net. This net is internal to the PCB and is not available on a
connector pin.
The UTR applies 115VACRMS 60Hz at P1-2.
The UTR requests the UUT to turn OFF the RUN1_C output on SPI_CS6 and the RUN2_DOG_FOOD output on
SPI_CS9.
The UTR verifies that LED6 “SAFE1” is illuminated.
The UTR verifies that the voltage at the “RUN1” net is <1VAC RMS.
The UTR requests the UUT to turn ON the RUN1_C output on SPI_CS6.
100mseconds after the output is ON, the UTR verifies that the voltage at the “RUN1” net is <1VAC RMS.
The UTR requests the UUT to turn OFF the RUN1_C output on SPI_CS6 and turn ON the RUN2_DOG_FOOD
signal on SPI_CS9.
100mseconds later, the UTR verifies that the voltage at the “RUN1” net is <1VAC RMS.
The UTR requests the UUT to turn ON the RUN1_C output on SPI_CS6 and turn ON the RUN2_DOG_FOOD
signal on SPI_CS9.
100mseconds after the outputs are set, the UTR verifies that the voltage at the “RUN1” net is >110VAC RMS.
The UTR requests the UUT to turn OFF the RUN1_C output on SPI_CS6.
100mseconds after the RUN1_C output is OFF, the UTR verifies that the voltage at the “RUN1” net is <1VAC
RMS.
The UTR requests the UUT to turn ON the RUN1_C output on SPI_CS6.
100mseconds after the RUN1_C output is ON, the UTR verifies that the voltage at the “RUN1” net is >110VAC
RMS.
The UTR requests the UUT to turn OFF the RUN2_DOG_FOOD output on SPI_CS9.
100mseconds after the RUN2_DOG_FOOD output is OFF, the UTR verifies that the voltage at the “RUN1” net is
<1VAC RMS.
"""

    results = await mock_embeddings.aembed_documents(texts=[content])

    assert len(results[0]) == 1536


@pytest.mark.asyncio
async def test_get_embeddings_empty(mock_embeddings):

    content = ""

    results = await mock_embeddings.aembed_documents(texts=[content])

    assert len(results[0]) == 1536
