"""Collect the factory methods for all the prompts used by ``glu_fastapi``."""

from functools import cache
from typing import Optional, List, Dict, Collection, Any

import structlog
from jinja2 import Environment, PackageLoader, Template, select_autoescape
from langchain_core.messages import HumanMessage, SystemMessage

from glu_fastapi.under_test.models import DeviceSpecPageReadWithRemoteUrl

logger = structlog.get_logger()
env = Environment(
    loader=PackageLoader("glu_fastapi", "prompts"),
    autoescape=select_autoescape(),
)


@cache
def _load_template(template_name: str) -> Template:
    """Load up the named template and return it."""
    return env.get_template(template_name)


def _build_common_human_message_parts_for_steps_based_processes(
    dut_name: str,
    fut_name: str,
    fut_overview: str,
    page_data: Collection[DeviceSpecPageReadWithRemoteUrl],
) -> List[Dict[str, str | Dict[str, str]]]:
    # Get the text we use at the front.
    template = _load_template("steps_generator_human_message.txt.j2")
    text = template.render(
        dut_name=dut_name,
        fut_name=fut_name,
        fut_overview=fut_overview,
    )

    # Initialize the accumulator with aforementioned text.
    # content=[
    #     {"type": "text", "text": "describe the weather in this image"},
    #     {"type": "image_url", "image_url": {"url": image_url}},
    # ]
    parts: List[Dict[str, str | Dict[str, str]]] = [
        {
            "type": "text",
            "text": text,
        },
    ]

    # Add to the accumulator for each image we're sending.
    for page in page_data:
        image_prompt_part = {
            "type": "image_url",
            "image_url": {
                "url": page.presigned_s3_url,
            },
        }
        parts.append(image_prompt_part)

    return parts


def tool_picker_system_message(
    user_notes: str,
    tool_call_function: str,
    response_formatting_instructions: str,
) -> SystemMessage:
    template = _load_template("tool_picker_system_message.txt.j2")
    message_text = template.render(
        user_notes=user_notes,
        tool_call_function=tool_call_function,
        response_formatting_instructions=response_formatting_instructions,
    )
    return SystemMessage(content=message_text)


def tool_picker_two_point_oh_human_message(
    dut_name: str,
    fut_name: str,
    fut_overview: str,
    current_version_of_the_steps: str,
    tool_list_schema: dict[str, Any],
    available_tools_json_string: str,
) -> HumanMessage:
    """Build the ``HumanMessage`` we send for the tool selection flow."""
    template = _load_template("tool_picker_two_point_oh_human_message.txt.j2")
    message_text = template.render(
        dut_name=dut_name,
        fut_name=fut_name,
        fut_overview=fut_overview,
        current_version_of_the_steps=current_version_of_the_steps,
        tool_list_schema=str(tool_list_schema),
        available_tools=available_tools_json_string,
    )
    return HumanMessage(content=message_text)


def steps_generator_system_message(
    user_notes: str,
    tool_call_function: str,
    response_formatting_instructions: str,
) -> SystemMessage:
    template = _load_template("steps_generator_system_message.txt.j2")
    message_text = template.render(
        user_notes=user_notes,
        tool_call_function=tool_call_function,
        response_formatting_instructions=response_formatting_instructions,
    )
    return SystemMessage(content=message_text)


def steps_generator_human_message(
    dut_name: str,
    fut_name: str,
    fut_overview: str,
    page_data: Collection[DeviceSpecPageReadWithRemoteUrl],
) -> HumanMessage:
    """Build the ``HumanMessage`` we send for the test step creation flow.

    .. note::
        This is a multimodal prompt! I *THINK* this is portable across OpenAI and
        Claude, but the langchain docs are quite specific that the onus is on us
        to test multimodal prompts if we switch models.
    """
    parts = _build_common_human_message_parts_for_steps_based_processes(
        dut_name,
        fut_name,
        fut_overview,
        page_data,
    )
    return HumanMessage(content=parts)


def steps_user_feedback_human_message(
    general_feedback: str | None,
    annotated_feedback: str | None,
) -> HumanMessage:
    """Build the ``HumanMessage`` we send to add human feedback to the conversation during the editing flow.

    This is the standalone prompt used in **subsequent** iterations of the feedback loop, not the initial message.
    """
    template = _load_template("steps_user_feedback_human_message.txt.j2")
    message_text = template.render(
        user_feedback=general_feedback,
        annotated_content=annotated_feedback,
    )
    return HumanMessage(content=message_text)


def steps_editor_human_message(
    dut_name: str,
    fut_name: str,
    fut_overview: str,
    page_data: Collection[DeviceSpecPageReadWithRemoteUrl],
    current_version_of_the_steps: str,
    user_feedback: Optional[str] = None,
    annotated_content: Optional[str] = None,
) -> HumanMessage:
    """Build the ``HumanMessage`` we send as part of the step-editing flow.

    This is the **initial** prompt for the process. This prompt includes the
    previously saved version of the steps, the relevant bits of the spec
    (as images), etc. Since we include the whole conversation history with each
    request to the model, there's no need to repeat the information in individual
    messages in the conversation. Accordingly, there is a standalone feedback
    prompt that does not include all this initial data. Use that one for
    subsequent passes through the loop.

    .. note::
        This is a multimodal prompt! I *THINK* this is portable across OpenAI and
        Claude, but the langchain docs are quite specific that the onus is on us
        to test multimodal prompts if we switch models.
    """
    parts = _build_common_human_message_parts_for_steps_based_processes(
        dut_name,
        fut_name,
        fut_overview,
        page_data,
    )

    # 3) The text portion that is 'edit steps'-specific.
    edit_steps_specific_text_template = _load_template(
        "steps_editor_human_message.txt.j2"
    )
    edit_specific_text = edit_steps_specific_text_template.render(
        current_version_of_the_steps=current_version_of_the_steps,
        user_feedback=user_feedback,
        annotated_content=annotated_content,
    )
    parts.append({"type": "text", "text": edit_specific_text})

    human_msg = HumanMessage(content=parts)
    return human_msg


def test_bench_tool_extractor() -> SystemMessage:
    template = _load_template("test_bench_tool_extractor.txt.j2")
    message_text = template.render()
    return SystemMessage(content=message_text)
