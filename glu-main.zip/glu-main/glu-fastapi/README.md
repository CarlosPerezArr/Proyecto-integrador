# GLUE

This is the Python backend for the Glue project. Render runs Python
projects on 3.11, so be sure you use 3.11 in local
development. It leverages modern Python libraries ([Poetry][1], [FastAPI][2],
and [SQLModel][3] most prominently) to expose a JSON-based API for doing CRUD operations against a PostgresQL (for
production/local dev) or SQLite (for local dev/testing) database.

Glue is a multi-tenant system and it leverages [Postgtresql schemas][7] to
achieve data isolation for each customer. On the auth side of things, it
leverages [Auth0 Organizations][8] to maintain the same level of isolation.
There is a 1:1 mapping between a customer's Auth0 Organization and their
Postgres schema.

## Getting Started

1. **Environment Management**

   1. Make sure you have Python 3.11 installed. [pyenv][5] is useful for
      managing different Python versions.
   2. Ensure you have Poetry installed. If not, follow the [installation instructions](https://python-poetry.org/docs/#installation).
   3. Tell `poetry` to use Python 3.11 for this project: `poetry env use 3.11`. See [the relevant docs](https://python-poetry.org/docs/managing-environments/) for more details.

2. **Clone the Repository**

    If you haven't already, clone the repository to your local machine: `git clone git@github.com:PioneerSquareLabs/glu.git`

3. **Install Dependencies**

    Navigate to the project's root directory (where `pyproject.toml` is
    located) and run `poetry install`.

    While not technically necessary, now is
    also a good time to install
    [`pre-commit`](https://pre-commit.com/) so the configured hooks can
    automatically format code, identify security concerns, etc. I prefer to
    manage `pre-commit` with `pipx` (available via `brew install pipx` if
    you're on a Mac). Once installed, navigate to the root of the git
    repository and run `pre-commit install`. After that, each commit should
    take care of enforcing a consistent formatting style, spotting certain
    classes of bugs, etc.

4. **Environment Variables**

   The FastAPI application expects certain environment variables to be defined. During development, you can define a
   `.env` file in the `glu_fastapi/glu_fastapi` directory and
   the [FastAPI `Settings` framework](https://fastapi.tiangolo.com/advanced/settings/) will
   automatically detect it and supply them for you.

   It should have the following entries:

    ```
    SQLALCHEMY_URL="<your_database_url>"
    TEST_SQLALCHEMY_URL="<url_for_your_testdb>"
    AWS_ACCESS_KEY_ID="<your_aws_key>"
    AWS_SECRET_ACCESS_KEY="<your_aws_secret>"
    AWS_DEFAULT_REGION="us-west-2"
    OPENAI_API_KEY="<your_openai_key>"
    AUTH0_DOMAIN="glutest.us.auth0.com"
    AUTH0_API_AUDIENCE="https://api.glutest.ai"
    AUTH0_ISSUER="https://glutest.us.auth0.com/"
    AUTH0_ALGORITHMS="RS256"
    AUTH0_CLIENT_ID="<your_auth0_client_id>"
    AUTH0_CLIENT_SECRET="<your_auth0_client_secret>"
    HOSTING_ENV="development"
    ```

5. **Database Migrations**

   The system uses [Alembic][4] to manage database migrations. If you need to
   create a new migration, I recommend reading the documentation fairly thoroughly. If you just need to bootstrap a
   local database for development, you can alter the `sqlalchemy.url` setting in `alembic.ini` to point to your new DB
   and then run the following from the command line: `poetry run -x tenant="development3" alembic upgrade head`.
    Pay attention to the `-x tenant="<foo>"` part. That is non-standard for
    Alembic, and it is used to tell Alembic which Postgres schema you want
    it to operate against.


6. **Running Locally**

     To really get everything working, you will need to run both the api and
     the frontend behind `ngrok` tunnels. The information below will get
     things going on the tenant that Hank usually uses (so expect to hear
     from him if you're hogging it 😉).

    ###### API

    1. Run the code

    ```
    $ cd glu_fastapi
    $ poetry run uvicorn main:app --reload --host 0.0.0.0 --port 3001
    ```

    2. Run the ngrok tunnel

    ```
    $ ngrok http 3001 --domain=api3.glu.ngrok.dev --config ~/.ngrok2/psl.yml
    ```

    **NOTE**: This presumes you have configured an ngrok account in `~/.ngrok2/psl.yml`.
              See [the relevant docs](https://ngrok.com/docs/ngrok-agent/config/)
              for more details.

    ###### Frontend

    1. Run the code

    ```
    $ cd $GLUE_HOME/glu-nextjs
    $ npm run dev
    ```

    2. Run the ngrok tunnel

    ```
    $ ngrok http 3000 --domain=web3.glu.ngrok.dev --config ~/.ngrok2/psl.yml
    ```

7. **Check the Application**

    Once the application is running, you will need to log in. If you go to
    https://web3.glu.ngrok.dev, you should be prompted to log in. Once you
    have logged in, you can access the FastAPI auto-generated documentation at
    https://api3.glu.ngrok.dev/docs to see all available endpoints and
    functionalities.

8. **Testing**

   To run the test suite, you must ensure you have a properly configured Postgres DB. Assuming you have a setup similar
   to the one created by Homebrew, you can use SQL files in `setup_scripts`:

   ```
   $ psql postgres -f glu_fastapi/setup_scripts/init_test_user_and_db.sql
   $ psql -d glu_test -f glu_fastapi/setup_scripts/init_extensions.sql
   ```

   **NOTE**: Order matters, since the second script creates the [`vector` extension][6] inside the database created by
             the first script.

[1]: https://python-poetry.org
[2]: https://fastapi.tiangolo.com
[3]: https://sqlmodel.tiangolo.com
[4]: https://alembic.sqlalchemy.org/en/latest/
[5]: https://github.com/pyenv/pyenv
[6]:https://github.com/pgvector/pgvector
[7]: https://www.postgresql.org/docs/current/ddl-schemas.html
[8]: https://auth0.com/docs/manage-users/organizations

9. **Trouble Shooting**
UndefinedTable: relation "checkpoints" does not exist <- this is the new langgraph, run the following command
poetry run python commands.py setup-checkpointer-for-tenant --name development2

10. **Release Process**

```
$ git checkout main
$ git pull
$ git checkout develop
$ git pull
$ git flow release start 2025.01.03.0
$ vim glu-next/package.json  # Replace the previous release number with our new one.
$ vim glu-fastapi/pyproject.toml  # Replace the previous release number with our new one.
$ git commit -a -m "Bump version to 2025.01.03.0"
# Assuming you got an error because our precommit hooks reformatted some files or whatever, just keep running that command.
$ git flow release finish 2025.01.03.0
$ git push
$ git checkout main
$ git push
$ git push --tags
$ git checkout develop
$ git pull
```
