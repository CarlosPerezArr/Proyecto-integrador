# GLU Project Deployment and Infrastructure Documentation

## Table of Contents
1. [Introduction](#introduction)
2. [Local Development Setup](#local-development-setup)
3. [Environment Variables](#environment-variables)
4. [Database Setup](#database-setup)
5. [Hosting Environments](#hosting-environments)
6. [Deployment Process](#deployment-process)
7. [Infrastructure Configuration](#infrastructure-configuration)
8. [Troubleshooting](#troubleshooting)

## Introduction

This document provides comprehensive instructions for deploying and managing the infrastructure of the GLU project. It covers both the Next.js frontend (glu-next) and the FastAPI backend (glu-fastapi), detailing the steps required for local development, staging, and production environments.

## Local Development Setup

### Before you Start

Get the following information:

1. ngrok account ("You've been invited to join FOO.glu.ngrok.dev's glutest account")
   * This may be incorrectly phrased. It's really an account with our instance, not with ngrok directly
1. An ngrok auth token
1. environment variables to define in `glu-next/.env`
1. environment variables to define in `glu-fastapi/glu_fastapi/.env`

## Setup ngrok

```bash
# install + configure
brew install ngrok
ngrok config add-authtoken $NGROK_AUTHTOKEN

# start these in separate windows
ngrok http 3000 --domain=web2.glu.ngrok.dev
ngrok http 3001 --domain=api2.glu.ngrok.dev
```

### Frontend (glu-next)

1. Ensure you have [Node.js](https://nodejs.org/) installed (version specified in `glu-next/package.json`).
2. Clone the repository: `git clone git@github.com:PioneerSquareLabs/glu.git`
3. Navigate to the frontend directory: `cd glu-next`
4. Install dependencies: `npm install`
5. Create a `.env` file in the `glu-next` directory with the necessary environment variables (see [Environment Variables](#environment-variables) section).
6. Run the development server: `npm run dev`
7. Access the application at `http://localhost:3000`

### Backend (glu-fastapi)

1. Ensure you have Python 3.11 installed. [pyenv](https://github.com/pyenv/pyenv) is recommended for managing Python versions.
2. Navigate to the backend directory: `cd glu-fastapi`
3. Install Poetry if not already installed: `pip install poetry`
4. Set up the Python environment: `poetry env use 3.11`
5. Install dependencies: `poetry install`
6. Create a `.env` file in the `glu_fastapi/glu_fastapi` directory with the necessary environment variables.
7. Run the FastAPI server: `poetry run uvicorn main:app --reload --host 0.0.0.0 --port 3001`
8. Access the API at `http://localhost:3001`

## Environment Variables

### Frontend (glu-next)

Create a `.env` file in the `glu-next` directory with the following variables:

```
AUTH0_ALGORITHMS=
AUTH0_API_AUDIENCE=
AUTH0_CLIENT_ID=
AUTH0_CLIENT_SECRET=
AUTH0_DOMAIN=
AUTH0_ISSUER=
NEXT_PUBLIC_MIXPANEL_TOKEN=
NEXT_PUBLIC_API_URL=
NEXT_PUBLIC_API_WEBSOCKET_URL=
OPENAI_API_KEY=
SENTRY_AUTH_TOKEN=
SQLALCHEMY_URL=
```

### Backend (glu-fastapi)

Create a `.env` file in the `glu_fastapi/glu_fastapi` directory with the following variables:

```
SQLALCHEMY_URL=
TEST_SQLALCHEMY_URL=
AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_DEFAULT_REGION=
OPENAI_API_KEY=
UNSTRUCTUREDIO_API_KEY=
UNSTRUCTUREDIO_SERVER_URL=
AUTH0_DOMAIN=
AUTH0_API_AUDIENCE=
AUTH0_ISSUER=
AUTH0_ALGORITHMS=
AUTH0_CLIENT_ID=
AUTH0_CLIENT_SECRET=
HOSTING_ENV=
MIXPANEL_TOKEN=
```

Ensure that sensitive information is properly secured and not committed to version control.

## Database Setup

The GLU project uses PostgreSQL as its primary database. For local development, you can use SQLite.

### Local Development

1. For SQLite, no additional setup is required. The database file will be created automatically.
2. For PostgreSQL:
   - Install PostgreSQL on your local machine.
   - Create a new database for the project.
   - Update the `SQLALCHEMY_URL` in your `.env` file with the PostgreSQL connection string.

### Production

1. Set up a managed PostgreSQL instance (e.g., AWS RDS, Google Cloud SQL).
2. Create a database for the project.
3. Update the `SQLALCHEMY_URL` in your production environment variables with the connection string.

### Migrations

The project uses Alembic for database migrations. To run migrations:

1. Navigate to the `glu-fastapi` directory.
2. Run: `poetry run -x tenant="development3" alembic upgrade head`

Replace `"development3"` with the appropriate tenant name for your environment.

## Hosting Environments

The GLU project supports three main environments:

1. Development (Local)
2. Staging
3. Production

Each environment should have its own set of environment variables and database instances.

## Deployment Process

### Frontend (glu-next)

1. Build the Next.js application: `npm run build`
2. For production, use a Node.js hosting service (e.g., Vercel, Netlify) or deploy to a server running Node.js.
3. Set the environment variables for the production environment.
4. Start the server: `npm start`

### Backend (glu-fastapi)

1. Ensure all dependencies are installed: `poetry install`
2. Set the environment variables for the production environment.
3. Run database migrations: `poetry run -x tenant="production" alembic upgrade head`
4. Start the FastAPI server using a production-grade ASGI server like Uvicorn or Gunicorn.

Example using Gunicorn:
```
gunicorn main:app --workers 4 --worker-class uvicorn.workers.UvicornWorker --bind 0.0.0.0:8000
```

## Infrastructure Configuration

### AWS Setup (if applicable)

1. Set up an AWS account and create an IAM user with appropriate permissions.
2. Configure AWS CLI with the credentials.
3. Create an S3 bucket for file storage.
4. Set up AWS RDS for PostgreSQL if using AWS for database hosting.

### Auth0 Configuration

1. Set up an Auth0 account and create a new application.
2. Configure the application settings in Auth0 dashboard.
3. Add the Auth0 domain, client ID, and client secret to your environment variables.

### Sentry Setup

1. Create a Sentry account and set up a new project.
2. Add the Sentry DSN to your environment variables.
3. Configure Sentry in both frontend and backend applications.

## Troubleshooting

- **Database Connection Issues**: Ensure the `SQLALCHEMY_URL` is correctly set and the database server is accessible.
- **Auth0 Authentication Errors**: Verify that all Auth0-related environment variables are correctly set and match the Auth0 dashboard settings.
- **API Connection Errors**: Check that the `NEXT_PUBLIC_API_URL` and `NEXT_PUBLIC_API_WEBSOCKET_URL` are correctly pointing to your backend server.
- **Deployment Failures**: Review the deployment logs for any error messages. Ensure all required environment variables are set in the production environment.

For any persistent issues, consult the project's technical support team or refer to the individual documentation for Next.js, FastAPI, and other integrated services.
