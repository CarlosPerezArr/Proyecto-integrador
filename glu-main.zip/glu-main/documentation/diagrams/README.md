# Architecture Diagrams for Glue
