# GLU Platform Documentation

## Introduction

Welcome to the documentation for the GLU Platform. This comprehensive suite of documents provides detailed information about various aspects of the GLU Platform, a sophisticated software ecosystem designed to streamline the management and testing of devices and their specifications.

The GLU Platform combines a Next.js frontend with a FastAPI backend, creating a seamless interface for users to interact with laboratory equipment, manage device specifications, and execute test plans. It supports a multi-tenant architecture, allowing multiple organizations to operate independently within the same application environment.

## Table of Contents

1. [User Guide](user_guide.md)
   - A comprehensive manual designed to assist users in navigating and utilizing the features of the GLU platform.

2. [Deployment Documentation](deployment.md)
   - Detailed instructions for deploying and managing the infrastructure of the GLU project, covering both the Next.js frontend and FastAPI backend.

3. [AI Integration Documentation](ai_integration.md)
   - Outlines the AI integration within the GLU project, describing key components such as ChatOpenAI and OpenAIEmbeddings, and the process of generating test plans and scripts.

4. [Backend Documentation](backend.md)
   - Provides an overview of the backend system built with FastAPI, detailing its key components, functionalities, and architecture.

5. [Frontend Documentation](frontend.md)
   - Offers an overview of the frontend architecture, key components, and technologies used in the GLU project, which is built with Next.js.

6. [Database Documentation](database.md)
   - Outlines the architecture and design of the database system used for managing device testing, specifications, and user interactions.

7. [GLU Architecture Diagram](diagrams/glu_architecture.plantuml)
   - A PlantUML diagram illustrating the architecture of the GLU platform, showing various components and their interactions.

## How to Use This Documentation

1. **Start with the User Guide**: If you're new to the GLU Platform, begin with the [User Guide](user_guide.md). It provides a comprehensive overview of the platform's features and how to use them effectively.

2. **For Technical Implementation**: Developers and system administrators should refer to the [Deployment Documentation](deployment.md), [Backend Documentation](backend.md), and [Frontend Documentation](frontend.md) for detailed technical information.

3. **Understanding AI Features**: To learn about the AI capabilities of the GLU Platform, consult the [AI Integration Documentation](ai_integration.md).

4. **Database Structure**: For information on data management and structure, refer to the [Database Documentation](database.md).

5. **Visual Overview**: To get a high-level understanding of the system architecture, review the [GLU Architecture Diagram](diagrams/glu_architecture.plantuml).

We recommend reading through each document thoroughly to gain a comprehensive understanding of the GLU Platform. If you have any questions or need further clarification, please don't hesitate to reach out to our support team.

Thank you for using the GLU Platform!
