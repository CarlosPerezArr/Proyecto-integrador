# GLU Project Database Documentation

## Overview

The GLU (Glue) project utilizes a robust database system to manage various aspects of device testing, specifications, and user interactions. The project is designed to work with both PostgreSQL and SQLite databases, providing flexibility for different deployment scenarios. A key feature of the database design is its support for multi-tenancy, allowing multiple organizations to use the platform while maintaining data isolation.

## Database Systems

### PostgreSQL
PostgreSQL is the primary database system used in production environments. It offers advanced features, robust performance, and excellent support for concurrent operations.

### SQLite
SQLite is used primarily for development and testing purposes. It's a lightweight, file-based database that doesn't require a separate server process.

## Multi-Tenancy Approach

The GLU project implements a schema-based multi-tenancy approach. This means that each tenant (organization) has its own schema within the database, ensuring data isolation and security.

### Shared Schema
The `shared` schema contains tables that are common across all tenants, such as the `Tenant` table itself.

### Tenant-Specific Schemas
Each tenant has its own schema, which contains all the tenant-specific tables. This approach allows for efficient data isolation without the need for separate databases for each tenant.

## Database Schema

### Shared Models (shared_models.py)

#### Tenant
- Table: `tenant`
- Schema: `shared`
- Fields:
  - `id`: Integer, Primary Key
  - `name`: String, Unique
  - `their_schema`: String, Unique
  - `host`: String, Unique, Indexed
  - `org_id`: String, Unique, Indexed (nullable)

### Per-Tenant Models (per_tenant_models.py)

#### BaseTable
An abstract base class that provides common timestamp fields for most tables:
- `created_at`: DateTime with timezone
- `updated_at`: DateTime with timezone (nullable)

#### CommonDevice
An abstract base class for common device attributes:
- `name`: String, Indexed
- `description`: String (nullable)
- `manufacturer`: String (nullable)

### Device Under Test Models (under_test/models.py)

#### DeviceUnderTest
- Inherits from: CommonDevice
- Fields:
  - `id`: Integer, Primary Key
- Relationships:
  - `device_specs`: One-to-Many with DeviceSpec

#### DeviceSpec
- Inherits from: BaseTable
- Fields:
  - `id`: Integer, Primary Key
  - `s3_key`: String (nullable)
  - `filename`: String
  - `device_under_test_id`: Integer, Foreign Key to DeviceUnderTest
- Relationships:
  - `device_under_test`: Many-to-One with DeviceUnderTest
  - `function_specs`: One-to-Many with FunctionSpec
  - `device_spec_chunks`: One-to-Many with DeviceSpecChunk
  - `table_of_contents`: One-to-Many with DeviceSpecTocEntry
  - `pages`: One-to-Many with DeviceSpecPage

#### FunctionSpec
- Inherits from: BaseTable
- Fields:
  - `id`: Integer, Primary Key
  - `name`: String, Indexed
  - `original_text`: String
  - `device_spec_id`: Integer, Foreign Key to DeviceSpec
- Relationships:
  - `device_spec`: Many-to-One with DeviceSpec
  - `test_plan`: One-to-One with TestPlan
  - `test_script`: One-to-One with TestScript
  - `ai_messages`: One-to-Many with AiMessage

#### DeviceSpecChunk
- Inherits from: BaseTable
- Fields:
  - `id`: Integer, Primary Key
  - `device_spec_id`: Integer, Foreign Key to DeviceSpec
  - `element_id`: String
  - `chunk_metadata`: JSON
  - `chunk_text`: String
  - `chunk_embeddings`: Vector(1536)
- Relationships:
  - `device_spec`: Many-to-One with DeviceSpec

#### DeviceSpecTocEntry
- Inherits from: BaseTable
- Fields:
  - `id`: Integer, Primary Key
  - `device_spec_id`: Integer, Foreign Key to DeviceSpec
  - `section_title`: String (nullable)
  - `section_number`: String (nullable)
  - `section_page_number`: Integer (nullable)
  - `toc_page_number`: Integer
- Relationships:
  - `device_spec`: Many-to-One with DeviceSpec

#### DeviceSpecPage
- Inherits from: BaseTable
- Fields:
  - `id`: Integer, Primary Key
  - `device_spec_id`: Integer, Foreign Key to DeviceSpec
  - `s3_key`: String
  - `page_number`: Integer
  - `headings_on_page`: JSON (List of strings)
  - `heading_embeddings`: Vector(1536)
- Relationships:
  - `device_spec`: Many-to-One with DeviceSpec

### Lab Bench Models (lab_bench/models.py)

#### TestBenchDevice
- Inherits from: CommonDevice
- Fields:
  - `id`: Integer, Primary Key
  - `category`: String, Indexed (nullable)
  - `ivi_tags`: JSON (List of strings)
- Relationships:
  - `test_benches`: Many-to-Many with TestBench through TestBenchTestBenchDeviceLink

#### TestBench
- Inherits from: BaseTable
- Fields:
  - `id`: Integer, Primary Key
  - `identifier`: String, Indexed
- Relationships:
  - `test_bench_devices`: Many-to-Many with TestBenchDevice through TestBenchTestBenchDeviceLink

#### TestBenchTestBenchDeviceLink
- Fields:
  - `test_bench_id`: Integer, Foreign Key to TestBench, Primary Key
  - `test_bench_device_id`: Integer, Foreign Key to TestBenchDevice, Primary Key

### AI Models (ai/models.py)

#### AiMessage
- Inherits from: BaseTable
- Fields:
  - `id`: Integer, Primary Key
  - `email`: String
  - `session_uuid`: UUID
  - `message_role`: Enum (System, User, Assistant)
  - `message_content`: String
  - `functionspec_id`: Integer, Foreign Key to FunctionSpec
  - `msg_embeddings`: Vector(1536) (nullable)
- Relationships:
  - `function_spec`: Many-to-One with FunctionSpec

#### AiMemory
- Inherits from: BaseTable
- Fields:
  - `id`: Integer, Primary Key
  - `notes`: String

### Test Plan Models (test_plan/models.py)

#### TestPlan
- Inherits from: BaseTable
- Fields:
  - `id`: Integer, Primary Key
  - `full_text`: String
  - `function_spec_id`: Integer, Foreign Key to FunctionSpec
- Relationships:
  - `function_spec`: One-to-One with FunctionSpec

#### TestScript
- Inherits from: BaseTable
- Fields:
  - `id`: Integer, Primary Key
  - `full_text`: String
  - `function_spec_id`: Integer, Foreign Key to FunctionSpec
- Relationships:
  - `function_spec`: One-to-One with FunctionSpec

## Database Configurations and Optimizations

1. **Indexing**: Several fields are indexed to improve query performance, particularly those used frequently in WHERE clauses or JOIN operations.

2. **Vector Support**: The database uses the `pgvector` extension to support vector operations, particularly for AI-related functionalities like embeddings.

3. **JSON Storage**: JSON fields are used to store flexible, schema-less data such as chunk metadata and IVI tags.

4. **Unique Constraints**: Unique constraints are applied to fields like `name` and `host` in the Tenant table to ensure data integrity.

5. **Cascading Deletes**: Many relationships are set up with cascading deletes to maintain referential integrity automatically.

6. **Gin Indexing**: GIN (Generalized Inverted Index) is used for efficient searching in JSON and array fields.

7. **HNSW Indexing**: HNSW (Hierarchical Navigable Small World) indexing is used for efficient similarity search in vector fields.

## Conclusion

The GLU project's database design efficiently supports multi-tenancy while providing a flexible and performant structure for managing devices, specifications, and test-related data. The use of inheritance in the models promotes code reuse and maintainability. The combination of relational data with JSON and vector fields allows for both structured and unstructured data to be stored and queried effectively, supporting the diverse needs of the application, from device management to AI-assisted testing.
