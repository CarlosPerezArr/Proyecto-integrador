# GLU Frontend Documentation

## Overview

The GLU (Glue) frontend is built using Next.js, a powerful React framework that enables server-side rendering and generates static websites for optimal performance. This document provides an in-depth look at the frontend architecture, key components, and technologies used in the GLU project.

## Table of Contents

1. [Next.js Framework](#nextjs-framework)
2. [Key Components](#key-components)
3. [Routing](#routing)
4. [State Management](#state-management)
5. [API Integration](#api-integration)
6. [Styling with Tailwind CSS](#styling-with-tailwind-css)
7. [Other Technologies and Libraries](#other-technologies-and-libraries)

## Next.js Framework

The GLU frontend leverages Next.js 13, which provides several benefits:

- **Server-Side Rendering (SSR)**: Improves initial page load time and SEO.
- **Static Site Generation (SSG)**: Allows for generating static pages at build time for even faster loading.
- **API Routes**: Enables the creation of API endpoints as part of the Next.js app.
- **File-based Routing**: Simplifies the creation and management of routes.
- **Built-in CSS Support**: Includes support for CSS Modules and Sass out of the box.

The project structure follows Next.js conventions, with the main application code located in the `app` directory.

## Key Components

The GLU frontend is composed of several reusable components that form the building blocks of the user interface. Some of the key components include:

### Layout (`app/layout.tsx`)

The `RootLayout` component serves as the main layout wrapper for the entire application. It includes:

- Global styles import
- Custom font setup (Inter and a local font)
- Metadata configuration
- Integration of the `ReactQueryProvider`
- Rendering of the `Header` and `Sidebar` components
typescript
export default function RootLayout({
  children
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} ${fraktion.variable} theme-dark`} data-theme="dark">
      <body>
        <ReactQueryProvider>
          <Header />
          <Sidebar>{children}</Sidebar>
        </ReactQueryProvider>
        {/* Development environment indicator */}
      </body>
    </html>
  );
}
```

### PageCard (`app/components/PageCard.tsx`)

The `PageCard` component is a versatile container used to structure content on pages. It accepts props for title, subtitle, header nodes, and children, allowing for flexible content rendering.

```typescript
const PageCard: React.FC<PageCardProps> = ({
  title = null,
  subTitle = null,
  headerNodes = null,
  children
}) => {
  return (
    <div className="h-screen px-16 flex flex-col items-center mt-8">
      <div className="w-full p-8 rounded shadow-xl flex flex-col gradient-box bg-base-100">
        {/* Render title, subtitle, header nodes, and children */}
      </div>
    </div>
  );
};
```

### TabBar (`app/components/TabBar.tsx`)

The `TabBar` component creates a tabbed interface, allowing users to switch between different views or sections within a page.

```typescript
const TabBar: React.FC<TabBarProps> = ({ tabs, selectedTab, onClick }) => {
  const [activeTab, setActiveTab] = useState(tabs[0]);

  // Handle tab clicks and render tabs
  // ...

  return (
    <div className="mt-4">
      <div className="flex justify-start border-b border-base-300 mx-">
        {/* Render tab buttons */}
      </div>
    </div>
  );
};
```

### ProgressBar (`app/components/ProgressBar.tsx`)

The `ProgressBar` component visualizes progress over time, useful for displaying the status of ongoing processes or tasks.

```typescript
const ProgressBar: React.FC<ProgressBarProps> = ({ durationSeconds, title, onComplete }) => {
  const [progressSeconds, setProgressSeconds] = useState<number>(0);
  const [progressPercentage, setProgressPercentage] = useState<number>(0);

  // Update progress logic
  // ...

  return (
    <div className="w-3/4 rounded bg-base-100 p-4">
      {/* Render progress bar and percentage */}
    </div>
  );
};
```

## Routing

GLU uses Next.js file-based routing system. The `app` directory structure defines the routes of the application. For example:

- `app/page.tsx`: The home page
- `app/projects/page.tsx`: The projects listing page
- `app/projects/[id]/page.tsx`: Individual project page with dynamic routing

The `app/page.tsx` file serves as the entry point for the application, currently set up to redirect users to the `/projects` route:

```typescript
export default function Home() {
  const router = useRouter();

  useEffect(() => {
    router.push('/projects');
  });

  // ...
}
```

## State Management

GLU utilizes React Query for efficient state management and data fetching. The `ReactQueryProvider` component (`app/react-query-provider.tsx`) sets up the React Query context for the entire application:

```typescript
export function ReactQueryProvider({ children }: React.PropsWithChildren) {
  const router = useRouter();
  const [client] = React.useState(
    new QueryClient({
      // Configuration options
    })
  );

  return (
    <QueryClientProvider client={client}>
      {children}
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
  );
}
```

This setup allows components to easily fetch, cache, and update data from the API using React Query hooks.

## API Integration

The frontend interacts with the backend API using a generated client based on the OpenAPI specification. The entry point for API interactions is located in `app/client/index.ts`:

```typescript
export { ApiError } from './core/ApiError';
export { CancelablePromise, CancelError } from './core/CancelablePromise';
export { OpenAPI } from './core/OpenAPI';
export * from './schemas.gen';
export * from './services.gen';
export * from './types.gen';
```

This setup provides type-safe API calls and error handling throughout the application.

## Styling with Tailwind CSS

GLU uses Tailwind CSS for styling, which provides a utility-first approach to CSS. Tailwind classes are used directly in the JSX to style components, promoting rapid development and consistency across the application.

The global styles are imported in the `app/layout.tsx` file:

```typescript
import '@/app/globals.css';
```

Custom Tailwind configurations and theme extensions can be found in the `tailwind.config.js` file at the root of the project.

## Other Technologies and Libraries

- **Gleap**: Used for bug reporting and user feedback, initialized in `app/page.tsx`.
- **Sentry**: Integrated for error tracking and performance monitoring.
- **Mixpanel**: Utilized for user event tracking and analytics.
- **Auth0**: Implemented for user authentication and authorization.

## Conclusion

The GLU frontend is built on a modern, performant stack with Next.js at its core. By leveraging reusable components, efficient state management with React Query, and utility-first styling with Tailwind CSS, the frontend provides a robust and maintainable codebase. The integration with various third-party services enhances the application's capabilities in error tracking, analytics, and user authentication.

Developers working on the GLU frontend should familiarize themselves with Next.js concepts, React Query for state management, and Tailwind CSS for styling. The modular component structure and type-safe API integration provide a solid foundation for building and extending the application's features.
