# GLU Backend Documentation

## Overview

The GLU backend, built with FastAPI, serves as the core of the GLU platform, providing a robust and scalable API for managing devices, specifications, and test plans. This document outlines the key components and functionalities of the backend system.

## Table of Contents

1. [FastAPI Framework](#fastapi-framework)
2. [Key Endpoints](#key-endpoints)
3. [Middleware](#middleware)
4. [Authentication](#authentication)
5. [Multi-tenancy](#multi-tenancy)
6. [External Service Integration](#external-service-integration)
7. [Database Management](#database-management)

## FastAPI Framework

The GLU backend is built using FastAPI, a modern, fast (high-performance) web framework for building APIs with Python 3.6+ based on standard Python type hints. FastAPI provides several advantages:

- Fast execution: On par with NodeJS and Go
- Fast to code: Increases development speed by about 200% to 300%
- Fewer bugs: Reduces about 40% of human (developer) induced errors
- Intuitive: Great editor support. Completion everywhere. Less time debugging
- Easy: Designed to be easy to use and learn. Less time reading docs
- Short: Minimizes code duplication. Multiple features from each parameter declaration
- Robust: Get production-ready code. With automatic interactive documentation
- Standards-based: Based on (and fully compatible with) the open standards for APIs: OpenAPI (previously known as Swagger) and JSON Schema

## Key Endpoints

The GLU backend provides several key endpoints for managing various aspects of the system:

### Device Management

- `GET /under_test/devices`: List all devices under test
- `POST /under_test/devices/`: Create a new device under test
- `GET /under_test/devices/{device_id}`: Retrieve details of a specific device
- `PUT /under_test/devices/{device_id}`: Update a specific device
- `DELETE /under_test/devices/{device_id}`: Delete a specific device

### Device Specifications

- `GET /under_test/devices/{device_id}/device_specs`: List specifications for a device
- `POST /under_test/devices/{device_id}/device_specs/`: Add a new specification to a device
- `GET /under_test/device_specs/{device_spec_id}`: Retrieve details of a specific device specification
- `DELETE /under_test/device_specs/{device_spec_id}`: Delete a specific device specification

### AI Integration

- `POST /ai/message/`: Create a log of a message sent in a conversation to AI
- `GET /ai/messages_in_session/{session_uuid}`: List AI messages in a given session
- `POST /ai/memories/`: Create an AI memory
- `GET /ai/memories`: Retrieve all AI memory records
- `POST /ai/memories/summarize`: Summarize all AI memory records

## Middleware

The GLU backend employs several middleware components to enhance functionality and security:

1. **CORS Middleware**: Handles Cross-Origin Resource Sharing (CORS) to allow or restrict access from different domains.

2. **Session Middleware**: Manages user sessions for maintaining state across requests.

3. **Structured Logging Middleware**: Provides detailed, structured logging for better observability and debugging.

4. **Correlation ID Middleware**: Adds a correlation ID to each request for tracing purposes.

5. **Trusted Host Middleware**: Ensures that requests are only processed from trusted hosts.

## Authentication

The GLU backend uses OAuth2 with Auth0 for secure authentication. Key features include:

- OAuth2 flow for user login and token generation
- JWT token validation for protected endpoints
- Role-based access control (RBAC) for fine-grained permissions
- Secure cookie handling for maintaining user sessions

## Multi-tenancy

The GLU backend implements a multi-tenant architecture, allowing multiple organizations to use the application while keeping their data isolated. Key aspects of the multi-tenancy approach include:

1. **Schema-based Separation**: Each tenant has its own database schema, ensuring complete data isolation.

2. **Tenant Identification**: Tenants are identified based on the request's host or organization ID.

3. **Dynamic Schema Selection**: The appropriate schema is selected at runtime based on the identified tenant.

4. **Shared vs. Tenant-Specific Models**: Some models (like Tenant) are shared across all tenants, while others are tenant-specific.

## External Service Integration

The GLU backend integrates with several external services to provide enhanced functionality:

### OpenAI Integration

- Used for generating embeddings and powering AI-assisted features
- Integrated through the `openai` Python library
- Configured with API keys stored securely in environment variables

### AWS Integration

- Utilized for file storage (S3) and potentially other AWS services
- Integrated using the `aioboto3` library for asynchronous operations
- Configured with AWS credentials and region settings

## Database Management

The GLU backend uses SQLModel, which combines the features of SQLAlchemy and Pydantic, for database operations. Key aspects include:

- Support for both PostgreSQL and SQLite databases
- Asynchronous database operations for improved performance
- Alembic for database migrations and schema management
- Multi-tenant database design with schema-based separation

In conclusion, the GLU backend provides a robust, scalable, and secure foundation for the GLU platform. Its use of modern technologies and best practices ensures high performance, maintainability, and extensibility for future enhancements.
